(() => {
  const SERVICE_VARIANTS = {
    giftWrap: 60042356359502,
    boxEngraving: 60042425958734,
    caseEngraving: 60043114021198,
    comboEngraving: 60043135844686,
    nfc: 60043171135822,
    shopper: 60043439178062,
  };

  const SERVICE_TYPES = {
    giftWrap: 'gift-wrap',
    boxEngraving: 'box-engraving',
    caseEngraving: 'case-engraving',
    comboEngraving: 'combo-engraving',
    nfc: 'nfc',
    shopper: 'shopper',
  };

  const cartUrl = () => (window.theme?.routes?.cart_url || '/cart');
  const addUrl = () => (window.theme?.routes?.cart_add_url || '/cart/add');
  const updateUrl = () => (window.theme?.routes?.cart_update_url || '/cart/update');

  const asString = (value) => (value == null ? '' : String(value));
  const propsOf = (item) => item?.properties || {};
  const prop = (item, name) => asString(propsOf(item)[name]);
  const isTrue = (value) => asString(value).toLowerCase() === 'true';
  const isYes = (value) => ['sì', 'si', 'yes', 'true'].includes(asString(value).trim().toLowerCase());
  const bundleIdOf = (item) => prop(item, '_petelia_bundle_id') || prop(item, '_petelia_group_id');
  const isPeteliaService = (item) => (
    isTrue(prop(item, '_petelia_extra_item')) ||
    isTrue(prop(item, '_petelia_service'))
  );
  const isPeteliaMain = (item) => (
    Boolean(bundleIdOf(item)) &&
    (isTrue(prop(item, '_petelia_main_item')) || !isPeteliaService(item))
  );

  const requiredServicesForMainItem = (item) => {
    const services = [];
    const hasBoxText = Boolean((prop(item, 'Incisione box') || prop(item, 'Testo incisione box')).trim()) ||
      isTrue(prop(item, '_petelia_requires_box_engraving')) ||
      isTrue(prop(item, '_petelia_requires_combo_engraving'));
    const hasCaseText = Boolean((prop(item, 'Incisione cassa') || prop(item, 'Testo incisione cassa')).trim()) ||
      isTrue(prop(item, '_petelia_requires_case_engraving')) ||
      isTrue(prop(item, '_petelia_requires_combo_engraving'));

    if (isYes(prop(item, 'Confezione regalo')) || isTrue(prop(item, '_petelia_requires_gift_wrap'))) {
      services.push({ variantId: SERVICE_VARIANTS.giftWrap, type: SERVICE_TYPES.giftWrap });
    }
    if (isYes(prop(item, 'Shopper Petelia')) || isTrue(prop(item, '_petelia_requires_shopper'))) {
      services.push({ variantId: SERVICE_VARIANTS.shopper, type: SERVICE_TYPES.shopper });
    }
    if (hasBoxText && hasCaseText) {
      services.push({ variantId: SERVICE_VARIANTS.comboEngraving, type: SERVICE_TYPES.comboEngraving });
    } else if (hasBoxText) {
      services.push({ variantId: SERVICE_VARIANTS.boxEngraving, type: SERVICE_TYPES.boxEngraving });
    } else if (hasCaseText) {
      services.push({ variantId: SERVICE_VARIANTS.caseEngraving, type: SERVICE_TYPES.caseEngraving });
    }
    if (Boolean((prop(item, 'Dedica NFC') || prop(item, 'Dedica NFC / link')).trim()) || isTrue(prop(item, '_petelia_requires_nfc'))) {
      services.push({ variantId: SERVICE_VARIANTS.nfc, type: SERVICE_TYPES.nfc });
    }
    return services;
  };

  const requestJson = async (url, options = {}) => {
    const response = await fetch(url, { credentials: 'same-origin', ...options });
    const data = await response.json();
    if (!response.ok || data?.status) {
      throw new Error(data?.description || data?.message || 'Errore durante l’aggiornamento del carrello.');
    }
    return data;
  };

  const fetchCart = () => requestJson(cartUrl() + '.js?_petelia=' + Date.now(), {
    cache: 'no-store',
    headers: { 'Accept': 'application/json' },
  });

  const getSectionsToRender = () => {
    const sections = ['mini-cart', 'cart-icon-bubble', 'mobile-cart-icon-bubble'];
    const mainCartItems = document.getElementById('main-cart-items');
    const mainCartFooter = document.getElementById('main-cart-footer');
    if (mainCartItems?.dataset?.id) sections.push(mainCartItems.dataset.id);
    if (mainCartFooter?.dataset?.id) sections.push(mainCartFooter.dataset.id);
    return [...new Set(sections.filter(Boolean))];
  };

  const getSectionInnerHTML = (html, selector) => new DOMParser()
    .parseFromString(html, 'text/html')
    .querySelector(selector)?.innerHTML;

  const renderSections = (parsedState) => {
    const sections = parsedState?.sections || {};

    const miniCart = document.getElementById('mini-cart');
    if (miniCart) {
      const html = sections['mini-cart'];
      const replacement = typeof html === 'string' ? getSectionInnerHTML(html, '.shopify-section') : null;
      if (replacement == null) throw new Error('Markup del carrello non disponibile.');
      miniCart.innerHTML = replacement;
      miniCart.classList.toggle('is-empty', parsedState.item_count === 0);
    }

    const cartIcon = document.getElementById('cart-icon-bubble');
    if (cartIcon && sections['cart-icon-bubble']) {
      const replacement = getSectionInnerHTML(sections['cart-icon-bubble'], '.shopify-section');
      if (replacement != null) cartIcon.innerHTML = replacement;
    }

    const mobileCartIcon = document.getElementById('mobile-cart-icon-bubble');
    if (mobileCartIcon && sections['mobile-cart-icon-bubble']) {
      const replacement = getSectionInnerHTML(sections['mobile-cart-icon-bubble'], '.shopify-section');
      if (replacement != null) mobileCartIcon.innerHTML = replacement;
    }

    const mainCartItems = document.getElementById('main-cart-items');
    const mainCartItemsSectionId = mainCartItems?.dataset?.id;
    if (mainCartItems && mainCartItemsSectionId && sections[mainCartItemsSectionId]) {
      const replacement = getSectionInnerHTML(sections[mainCartItemsSectionId], '.js-contents');
      const target = mainCartItems.querySelector('.js-contents') || mainCartItems;
      if (replacement != null && target) target.innerHTML = replacement;
      mainCartItems.classList.toggle('is-empty', parsedState.item_count === 0);
    }

    const mainCartFooter = document.getElementById('main-cart-footer');
    const mainCartFooterSectionId = mainCartFooter?.dataset?.id;
    if (mainCartFooter && mainCartFooterSectionId && sections[mainCartFooterSectionId]) {
      const replacement = getSectionInnerHTML(sections[mainCartFooterSectionId], '.js-contents');
      const target = mainCartFooter.querySelector('.js-contents') || mainCartFooter;
      if (replacement != null && target) target.innerHTML = replacement;
      mainCartFooter.classList.toggle('is-empty', parsedState.item_count === 0);
    }

    document.dispatchEvent(new CustomEvent('cart:updated', { detail: { cart: parsedState } }));
  };

  const updateItems = (updates, withSections = false) => {
    const body = { updates };
    if (withSections) {
      body.sections = getSectionsToRender();
      body.sections_url = window.PeteliaThemeContext?.sectionPath() || window.location.pathname;
    }
    return requestJson(updateUrl(), {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'Accept': 'application/json' },
      body: JSON.stringify(body),
    });
  };

  const addItems = (items) => requestJson(addUrl(), {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', 'Accept': 'application/json' },
    body: JSON.stringify({ items }),
  });

  let cartViewRefreshPromise = null;

  function refreshCartView() {
    if (cartViewRefreshPromise) return cartViewRefreshPromise;

    const sectionsUrl = cartUrl() +
      '?sections=' + getSectionsToRender().join(',') +
      '&sections_url=' + encodeURIComponent(window.location.pathname) +
      '&_petelia=' + Date.now();

    cartViewRefreshPromise = Promise.resolve(window.PeteliaCartNotes?.flush()).then(() => Promise.all([
      fetchCart(),
      fetch(window.PeteliaThemeContext?.url(sectionsUrl) || sectionsUrl, {
        credentials: 'same-origin',
        cache: 'no-store',
        headers: { 'Accept': 'application/json' },
      }).then((response) => {
        if (!response.ok) throw new Error('Impossibile aggiornare le sezioni del carrello.');
        return response.json();
      }),
    ]))
      .then(([cart, sections]) => {
        renderSections({ ...cart, sections });
        return cart;
      })
      .finally(() => {
        cartViewRefreshPromise = null;
      });

    return cartViewRefreshPromise;
  }
  let mutationQueue = Promise.resolve();
  function queueMutation(operation) {
    const result = mutationQueue.then(operation);
    mutationQueue = result.catch(() => {});
    return result;
  }

  function changeItem(reference, quantity) {
    return queueMutation(async () => {
      if (!Number.isInteger(Number(quantity)) || Number(quantity) < 0) throw new Error('Quantità non valida.');
      quantity = Number(quantity);
      await window.PeteliaCartNotes?.flush();
      const isCartPage = /\/cart\/?$/.test(window.location.pathname);
      const reloadCartPage = isCartPage && quantity === 0;
      if (!reloadCartPage && cartViewRefreshPromise) await cartViewRefreshPromise.catch(() => {});
      const cart = await fetchCart();
      const items = cart.items || [];
      let matches = [];
      if (reference.bundleId && !reference.service) {
        // Resolve the whole group using current keys, even after discounts changed them.
        matches = items.filter((item) => bundleIdOf(item) === reference.bundleId);
      } else {
        matches = items.filter((item) => item.key === reference.key);
      }
      // Never fall back to a position or variant id: it could identify another watch.
      if (!matches.length && quantity !== 0) {
        await refreshCartView();
        throw new Error('Il carrello è stato aggiornato. Riprova sulla riga aggiornata.');
      }
      if (reference.service && matches.some(isPeteliaService)) {
        throw new Error('Modifica la quantità dal prodotto principale.');
      }
      const updates = {};
      matches.forEach((item) => { updates[item.key] = quantity; });
      const updated = matches.length ? await updateItems(updates) : cart;
      // Shopify has saved the mutation: load authoritative HTML on the full cart page.
      if (reloadCartPage) {
        window.location.reload();
        return updated;
      }
      try { await refreshCartView(); }
      catch (error) {
        console.error('Petelia: modifica salvata, ricarico il carrello.', error);
        window.location.reload();
      }
      return updated;
    });
  }

  function removeGroup(bundleId) {
    if (!bundleId) return Promise.resolve(null);
    return changeItem({ bundleId, service: false }, 0);
  }

  async function cleanupOrphanServices(cart = null) {
    const currentCart = cart || await fetchCart();
    const items = currentCart.items || [];
    const mainBundles = new Set(items.filter(isPeteliaMain).map(bundleIdOf));
    const orphans = items.filter((item) => (
      isPeteliaService(item) &&
      bundleIdOf(item) &&
      !mainBundles.has(bundleIdOf(item))
    ));
    if (!orphans.length) return currentCart;

    const updates = {};
    orphans.forEach((item) => { updates[item.key] = 0; });
    await updateItems(updates);
    return fetchCart();
  }

  async function repairPeteliaCart() {
    await mutationQueue;
    await window.PeteliaCartNotes?.flush();
    let cart = await cleanupOrphanServices();
    const items = cart.items || [];
    const mainItems = items.filter(isPeteliaMain);
    const updates = {};
    const itemsToAdd = [];

    for (const main of mainItems) {
      const bundleId = bundleIdOf(main);
      const required = requiredServicesForMainItem(main);
      const groupServices = items.filter((item) => (
        isPeteliaService(item) && bundleIdOf(item) === bundleId
      ));
      const keptKeys = new Set();

      for (const requiredService of required) {
        const matches = groupServices.filter((item) => (
          Number(item.variant_id) === Number(requiredService.variantId)
        ));
        const matching = matches[0];

        if (!matching) {
          itemsToAdd.push({
            id: requiredService.variantId,
            quantity: main.quantity,
            properties: {
              '_petelia_bundle_id': bundleId,
              '_petelia_extra_item': 'true',
              '_petelia_service_type': requiredService.type,
            },
          });
        } else {
          keptKeys.add(matching.key);
          if (matching.quantity !== main.quantity) updates[matching.key] = main.quantity;
          matches.slice(1).forEach((duplicate) => { updates[duplicate.key] = 0; });
        }
      }

      groupServices.forEach((service) => {
        if (!keptKeys.has(service.key) && updates[service.key] === undefined) {
          updates[service.key] = 0;
        }
      });
    }

    if (Object.keys(updates).length) {
      await updateItems(updates);
      cart = await fetchCart();
    }
    if (itemsToAdd.length) {
      await addItems(itemsToAdd);
      cart = await fetchCart();
    }

    // Checkout only depends on cart data and successful writes, never section rendering.
    return cart;
  }

  const goToCheckout = () => {
    window.location.assign('/checkout');
  };

  async function guardCheckout(event) {
    const submitter = event.submitter || document.activeElement;
    const isCheckoutSubmit = submitter?.name === 'checkout' || submitter?.getAttribute?.('name') === 'checkout';
    if (!isCheckoutSubmit) return;

    event.preventDefault();
    event.stopPropagation();

    if (submitter) {
      submitter.setAttribute('aria-disabled', 'true');
      submitter.disabled = true;
    }

    try {
      await repairPeteliaCart();
      goToCheckout();
    } catch (error) {
      console.error('Petelia cart guard error:', error);
      alert('Non è stato possibile verificare le opzioni del carrello. Riprova tra qualche secondo.');
      if (submitter) {
        submitter.removeAttribute('aria-disabled');
        submitter.disabled = false;
      }
    }
  }

  function handleGroupedRemove(event) {
    const removeLink = event.target.closest('cart-remove-button, a.delete-product, a[href*="/cart/change"]');
    if (!removeLink) return;

    const line = removeLink.closest('[data-petelia-bundle-id]');
    if (!line) return;

    const bundleId = line.dataset.peteliaBundleId;
    const isService = line.dataset.peteliaServiceLine === 'true';
    const isLockedService = line.dataset.peteliaLockedExtra === 'true';

    if (isService) {
      if (!isLockedService) return;
      event.preventDefault();
      event.stopPropagation();
      alert('Questo extra è collegato al prodotto principale. Per rimuoverlo, rimuovi il prodotto principale dal carrello.');
      return;
    }

    event.preventDefault();
    event.stopPropagation();
    removeLink.setAttribute('aria-disabled', 'true');

    removeGroup(bundleId).catch((error) => {
      console.error('Petelia grouped remove error:', error);
      removeLink.removeAttribute('aria-disabled');
      alert('Non è stato possibile rimuovere il gruppo. Riprova tra qualche secondo.');
    });
  }

  document.addEventListener('click', handleGroupedRemove, true);

  document.addEventListener('submit', (event) => {
    const form = event.target;
    if (!(form instanceof HTMLFormElement)) return;
    if (form.id === 'cart' || form.action?.includes('/cart')) guardCheckout(event);
  }, true);

  document.addEventListener('click', (event) => {
    const target = event.target.closest('[name="checkout"], a[href="/checkout"]');
    if (!target || target.closest('form')) return;
    event.preventDefault();
    target.setAttribute('aria-disabled', 'true');
    repairPeteliaCart()
      .then(goToCheckout)
      .catch((error) => {
        console.error('Petelia cart guard error:', error);
        target.removeAttribute('aria-disabled');
        alert('Non è stato possibile verificare le opzioni del carrello. Riprova tra qualche secondo.');
      });
  }, true);

  window.addEventListener('pageshow', () => {
    document.querySelectorAll('[name="checkout"]').forEach((button) => {
      button.disabled = false;
      button.removeAttribute('aria-disabled');
    });
    refreshCartView().catch((error) => console.error('Petelia return refresh:', error));
  });

  window.PeteliaCartGuard = {
    repairPeteliaCart,
    cleanupOrphanServices,
    removeGroup,
    changeItem,
    refreshCartView,
  };
})();
