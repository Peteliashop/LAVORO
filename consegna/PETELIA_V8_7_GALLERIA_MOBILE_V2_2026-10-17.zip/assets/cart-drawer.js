class MiniCart extends HTMLElement {
  constructor() {
    super();
  }

  connectedCallback() {
    this.header = document.querySelector('sticky-header');
    this.drawer = document.querySelector('cart-drawer');
    this.details = this.drawer?.querySelector('details');
  }

  refreshFromShopify() {
    if (this.refreshPromise) return this.refreshPromise;

    this.setAttribute('aria-busy', 'true');
    this.refreshPromise = window.PeteliaCartGuard.refreshCartView()
      .then((cart) => {
        this.classList.toggle('is-empty', cart.item_count === 0);
        document.dispatchEvent(new CustomEvent('cartdrawer:opened', { detail: { cart } }));
        return cart;
      })
      .catch(async (error) => {
        console.error('Cart drawer refresh error:', error);
        try {
          await this.fetchMiniCartFallback();
        } catch (fallbackError) {
          console.error('Cart drawer fallback error:', fallbackError);
          this.renderLoadError();
        }
        return null;
      })
      .finally(() => {
        this.removeAttribute('aria-busy');
        this.classList.remove('loading', 'is-loading');
        this.querySelectorAll('.loading-overlay').forEach((overlay) => overlay.classList.add('hidden'));
        this.refreshPromise = null;
      });

    return this.refreshPromise;
  }
  open() {
    if (this.details?.hasAttribute('open')) {
      this.refreshFromShopify();
      return;
    }
    this.drawer.openMenuDrawer();
  }

  async fetchMiniCartFallback() {
    const response = await fetch(window.PeteliaThemeContext?.url(this.dataset.url) || this.dataset.url, {
      credentials: 'same-origin',
      cache: 'no-store',
      headers: { Accept: 'text/html' },
    });
    if (!response.ok) throw new Error('Fallback mini-cart non disponibile.');
    const html = await response.text();
    const contents = this.getSectionInnerHTML(html, '.shopify-section');
    if (contents == null) throw new Error('Markup mini-cart non disponibile.');
    this.innerHTML = contents;
  }

  renderLoadError() {
    this.textContent = 'Impossibile caricare il carrello. Apri la pagina carrello e riprova.';
  }

  renderContents(parsedState) {
    this.productId = parsedState.id;
    this.getSectionsToRender().forEach((section => {
      if (document.getElementById(section.id)) {
        document.getElementById(section.id).innerHTML =
          this.getSectionInnerHTML(parsedState.sections[section.id], section.selector);
      }
    }));

    this.open();
  }

  getSectionsToRender() {
    return [
      {
        id: 'mini-cart',
        section: 'mini-cart',
        selector: '.shopify-section'
      },
      {
        id: 'cart-icon-bubble',
        section: 'cart-icon-bubble',
        selector: '.shopify-section'
      },
      {
        id: 'mobile-cart-icon-bubble',
        section: 'mobile-cart-icon-bubble',
        selector: '.shopify-section'
      }
    ];
  }

  getSectionInnerHTML(html, selector = '.shopify-section') {
    return new DOMParser()
      .parseFromString(html, 'text/html')
      .querySelector(selector)?.innerHTML;
  }

  setActiveElement(element) {
    this.activeElement = element;
  }
}

customElements.define('mini-cart', MiniCart);
