if (!customElements.get('product-form')) {
  customElements.define(
    'product-form',
    class ProductForm extends HTMLElement {
      constructor() {
        super();

        this.form = this.querySelector('form');
        this.variantIdInput.disabled = false;
        this.form.addEventListener('submit', this.onSubmitHandler.bind(this));
        //this.cart = document.querySelector('cart-notification') || document.querySelector('cart-drawer');
        this.cart = document.querySelector('mini-cart');
        this.submitButton = this.querySelector('[type="submit"]');
        this.submitButtonText = this.submitButton.querySelector('span');

        if (document.querySelector('cart-drawer')) this.submitButton.setAttribute('aria-haspopup', 'dialog');

        this.hideErrors = this.dataset.hideErrors === 'true';
        this.peteliaGiftOptionsEnabled = this.dataset.peteliaGiftOptions === 'true';
        if (this.peteliaGiftOptionsEnabled) this.setupPeteliaGiftOptions();
      }

      setupPeteliaGiftOptions() {
        this.peteliaOptionsWrapper = this.querySelector('[data-petelia-options]');
        if (!this.peteliaOptionsWrapper) return;

        this.peteliaAccordion = this.querySelector('[data-petelia-accordion]');
        this.peteliaDynamicCheckout = this.querySelector('.shopify-payment-button');
        this.peteliaDynamicMessage = this.querySelector('[data-petelia-dynamic-message]');
        this.updatePeteliaDynamicCheckout = () => {
          if (!this.peteliaDynamicCheckout) return;
          const hasSelectedExtras = Array.from(
            this.peteliaOptionsWrapper.querySelectorAll('[data-petelia-option]')
          ).some((option) => option.checked);
          const canUseDynamicCheckout = !hasSelectedExtras;
          this.peteliaDynamicCheckout.hidden = !canUseDynamicCheckout;
          this.peteliaDynamicCheckout.setAttribute('aria-hidden', String(!canUseDynamicCheckout));
          if (this.peteliaDynamicMessage) {
            this.peteliaDynamicMessage.hidden = canUseDynamicCheckout;
          }
        };

        const caseInput = this.peteliaOptionsWrapper.querySelector('[data-petelia-input=case-engraving-text]');
        const caseCounter = this.peteliaOptionsWrapper.querySelector('[data-petelia-case-counter]');
        const updateCaseCounter = () => {
          if (caseInput) caseInput.maxLength = 25;
          if (caseCounter) caseCounter.textContent = `${caseInput?.value.length || 0}/25`;
        };
        caseInput?.addEventListener('input', updateCaseCounter);
        updateCaseCounter();

        const toggleField = (optionName, checked) => {
          const field = this.peteliaOptionsWrapper.querySelector(`[data-petelia-field="${optionName}"]`);
          if (!field) return;
          field.hidden = !checked;
          field.querySelectorAll('input, textarea, select').forEach((input) => {
            input.disabled = !checked;
            if (!checked) input.value = '';
          });
        };

        const money = (cents) => {
          const amount = Number(cents || 0) / 100;
          return new Intl.NumberFormat('it-IT', { style: 'currency', currency: 'EUR' }).format(amount);
        };

        const getPeteliaPreviewModal = () => {
          let modal = document.getElementById('petelia-extra-preview-modal');
          if (modal) return modal;

          modal = document.createElement('div');
          modal.id = 'petelia-extra-preview-modal';
          modal.className = 'petelia-preview-modal';
          modal.hidden = true;
          modal.setAttribute('aria-hidden', 'true');
          modal.innerHTML =
            '<div class="petelia-preview-modal__backdrop" data-petelia-preview-close></div>' +
            '<div class="petelia-preview-modal__dialog" role="dialog" aria-modal="true" aria-label="Anteprima servizio extra">' +
              '<button type="button" class="petelia-preview-modal__close" data-petelia-preview-close aria-label="Chiudi anteprima">×</button>' +
              '<img src="" alt="" data-petelia-preview-modal-image>' +
              '<strong data-petelia-preview-modal-title></strong>' +
              '<small data-petelia-preview-modal-price></small>' +
            '</div>';

          modal.closePeteliaPreview = () => {
            const returnFocus = modal.peteliaReturnFocus;
            modal.classList.remove('is-visible');
            modal.hidden = true;
            modal.setAttribute('aria-hidden', 'true');
            document.body.classList.remove('petelia-modal-open');

            const imageEl = modal.querySelector('[data-petelia-preview-modal-image]');
            if (imageEl) {
              imageEl.removeAttribute('src');
              imageEl.alt = '';
            }
            modal.querySelector('[data-petelia-preview-modal-title]').textContent = '';
            modal.querySelector('[data-petelia-preview-modal-price]').textContent = '';
            modal.peteliaReturnFocus = null;
            if (returnFocus?.isConnected) returnFocus.focus();
          };

          modal.addEventListener('click', (event) => {
            if (!event.target.closest('[data-petelia-preview-close]')) return;
            event.preventDefault();
            event.stopPropagation();
            modal.closePeteliaPreview();
          });

          modal.addEventListener('keydown', (event) => {
            if (event.key !== 'Escape') return;
            event.preventDefault();
            event.stopPropagation();
            modal.closePeteliaPreview();
          });

          window.addEventListener('pageshow', () => modal.closePeteliaPreview());
          document.body.appendChild(modal);
          return modal;
        };

        const openPeteliaPreviewModal = (image, title, price, trigger) => {
          if (!image || !title || !trigger) return;
          const modal = getPeteliaPreviewModal();
          const imageEl = modal.querySelector('[data-petelia-preview-modal-image]');
          const titleEl = modal.querySelector('[data-petelia-preview-modal-title]');
          const priceEl = modal.querySelector('[data-petelia-preview-modal-price]');

          imageEl.src = image;
          imageEl.alt = title;
          titleEl.textContent = title;
          priceEl.textContent = price ? '+ ' + price : '';
          modal.peteliaReturnFocus = trigger;
          modal.hidden = false;
          modal.setAttribute('aria-hidden', 'false');
          modal.classList.add('is-visible');
          document.body.classList.add('petelia-modal-open');
          modal.querySelector('[data-petelia-preview-close]')?.focus();
        };
        const showPeteliaOptionPreview = (source) => {
          if (!source) return;
          const preview = this.peteliaOptionsWrapper.querySelector('[data-petelia-preview]');
          if (!preview) return;

          const title = source.title || source.dataset?.peteliaPreviewTitle;
          const price = source.price || source.dataset?.peteliaPreviewPrice;
          const image = source.image || source.dataset?.peteliaPreviewImage;
          if (!title || !image) return;

          const imageEl = preview.querySelector('[data-petelia-preview-image]');
          const titleEl = preview.querySelector('[data-petelia-preview-title]');
          const priceEl = preview.querySelector('[data-petelia-preview-price]');

          if (imageEl) {
            imageEl.src = image;
            imageEl.alt = title;
          }
          if (titleEl) titleEl.textContent = title;
          if (priceEl) priceEl.textContent = price ? `Aggiunto · + ${price}` : 'Aggiunto';

          preview.hidden = false;
          preview.classList.remove('is-visible');
          void preview.offsetWidth;
          preview.classList.add('is-visible');

          clearTimeout(this.peteliaPreviewTimer);
          this.peteliaPreviewTimer = setTimeout(() => {
            preview.classList.remove('is-visible');
            setTimeout(() => {
              if (!preview.classList.contains('is-visible')) preview.hidden = true;
            }, 220);
          }, 3800);
        };

        this.peteliaOptionsWrapper.addEventListener('click', (event) => {
          const trigger = event.target.closest('[data-petelia-preview-trigger]');
          if (!trigger || !this.peteliaOptionsWrapper.contains(trigger)) return;
          event.preventDefault();
          event.stopPropagation();
          openPeteliaPreviewModal(
            trigger.dataset.peteliaPreviewImage,
            trigger.dataset.peteliaPreviewTitle,
            trigger.dataset.peteliaPreviewPrice,
            trigger
          );
        });

        const updateSummary = () => {
          const boxChecked = this.peteliaOptionsWrapper.querySelector('[data-petelia-option="box-engraving"]')?.checked;
          const caseChecked = this.peteliaOptionsWrapper.querySelector('[data-petelia-option="case-engraving"]')?.checked;
          const giftChecked = this.peteliaOptionsWrapper.querySelector('[data-petelia-option="gift-wrap"]')?.checked;
          const shopperChecked = this.peteliaOptionsWrapper.querySelector('[data-petelia-option="shopper"]')?.checked;
          const nfcChecked = this.peteliaOptionsWrapper.querySelector('[data-petelia-option="nfc"]')?.checked;
          const comboNotice = this.peteliaOptionsWrapper.querySelector('[data-petelia-combo]');
          if (comboNotice) comboNotice.hidden = !(boxChecked && caseChecked);

          const summary = this.peteliaOptionsWrapper.querySelector('[data-petelia-summary]');
          if (!summary) return;

          const basePrice = Number(this.peteliaOptionsWrapper.dataset.basePrice || 0);
          const prices = {
            giftWrap: Number(this.peteliaOptionsWrapper.dataset.priceGiftWrap || 0),
            shopper: Number(this.peteliaOptionsWrapper.dataset.priceShopper || 0),
            box: Number(this.peteliaOptionsWrapper.dataset.priceBoxEngraving || 0),
            case: Number(this.peteliaOptionsWrapper.dataset.priceCaseEngraving || 0),
            combo: Number(this.peteliaOptionsWrapper.dataset.priceComboEngraving || 0),
            nfc: Number(this.peteliaOptionsWrapper.dataset.priceNfc || 0),
          };

          const rows = [];
          let extrasTotal = 0;
          const pushRow = (label, cents) => {
            extrasTotal += cents;
            rows.push(`<div><span>${label}</span><strong>${money(cents)}</strong></div>`);
          };

          if (giftChecked) pushRow('Confezione regalo', prices.giftWrap);
          if (shopperChecked) pushRow('Shopper Petelia', prices.shopper);
          if (boxChecked && caseChecked) {
            pushRow('Offerta combo incisioni', prices.combo);
          } else {
            if (boxChecked) pushRow('Incisione box', prices.box);
            if (caseChecked) pushRow('Incisione cassa', prices.case);
          }
          if (nfcChecked) pushRow('Dedica NFC', prices.nfc);

          const existingDetails = summary.querySelector('details');
          const shouldOpen = existingDetails
            ? existingDetails.open
            : !window.matchMedia('(max-width: 749px)').matches;
          const total = money(basePrice + extrasTotal);
          summary.innerHTML = `
            <details${shouldOpen ? ' open' : ''}>
              <summary><span>Riepilogo</span><strong>${total}</strong></summary>
              <div class="petelia-gift-options__summary-body">
                <div><span>Prodotto</span><strong>${money(basePrice)}</strong></div>
                ${rows.length ? rows.join('') : '<div><span>Nessun extra selezionato</span><strong>€0,00</strong></div>'}
                <div class="petelia-gift-options__summary-total"><span>Totale</span><strong>${total}</strong></div>
              </div>
            </details>
          `;
        };

        const updateComboNotice = updateSummary;

        this.peteliaOptionsWrapper.addEventListener('change', (event) => {
          const target = event.target;
          if (!target.matches('[data-petelia-option]')) return;

          const optionName = target.dataset.peteliaOption;
          if (optionName === 'box-engraving' || optionName === 'case-engraving' || optionName === 'nfc') {
            toggleField(optionName, target.checked);
          }

          const boxChecked = this.peteliaOptionsWrapper.querySelector('[data-petelia-option="box-engraving"]')?.checked === true;
          const caseChecked = this.peteliaOptionsWrapper.querySelector('[data-petelia-option="case-engraving"]')?.checked === true;
          if (target.checked) {
            if ((optionName === 'box-engraving' || optionName === 'case-engraving') && boxChecked && caseChecked) {
              showPeteliaOptionPreview({
                title: this.peteliaOptionsWrapper.dataset.peteliaPreviewComboTitle,
                price: this.peteliaOptionsWrapper.dataset.peteliaPreviewComboPrice,
                image: this.peteliaOptionsWrapper.dataset.peteliaPreviewComboImage,
              });
            } else {
              showPeteliaOptionPreview(target);
            }
          }

          updateComboNotice();
          this.updatePeteliaDynamicCheckout();
        });

        ['box-engraving', 'case-engraving', 'nfc'].forEach((optionName) => {
          const checkbox = this.peteliaOptionsWrapper.querySelector(`[data-petelia-option="${optionName}"]`);
          toggleField(optionName, checkbox?.checked === true);
        });
        updateComboNotice();
        this.updatePeteliaDynamicCheckout();
      }

      onSubmitHandler(evt) {
        evt.preventDefault();
        if (this.submitButton.getAttribute('aria-disabled') === 'true') return;

        this.handleErrorMessage();

        if (this.peteliaGiftOptionsEnabled) {
          const validationError = this.validatePeteliaGiftOptions();
          if (validationError) {
            this.handleErrorMessage(validationError);
            if (this.peteliaAccordion) this.peteliaAccordion.open = true;
            this.peteliaOptionsWrapper
              ?.querySelector('[data-petelia-input=case-engraving-text]')
              ?.focus();
            return;
          }
        }

        this.submitButton.setAttribute('aria-disabled', true);
        this.submitButton.classList.add('loading');
        //this.querySelector('.loading__spinner').classList.remove('hidden');

        if (this.peteliaGiftOptionsEnabled) {
          this.onPeteliaGiftOptionsSubmit();
          return;
        }

        const config = fetchConfig('javascript');
        config.headers['X-Requested-With'] = 'XMLHttpRequest';
        delete config.headers['Content-Type'];

        const formData = new FormData(this.form);
        if (this.cart) {
          formData.append(
            'sections',
            this.cart.getSectionsToRender().map((section) => section.id)
          );
          formData.append('sections_url', window.PeteliaThemeContext?.sectionPath() || window.location.pathname);
          this.cart.setActiveElement(document.activeElement);
        }
        config.body = formData;

        fetch(`${theme.routes.cart_add_url}`, config)
          .then((response) => response.json())
          .then((response) => {
            if (response.status) {
              publish(PUB_SUB_EVENTS.cartError, {
                source: 'product-form',
                productVariantId: formData.get('id'),
                errors: response.errors || response.description,
                message: response.message,
              });
              this.handleErrorMessage(response.description);

              const soldOutMessage = this.submitButton.querySelector('.sold-out-message');
              if (!soldOutMessage) return;
              this.submitButton.setAttribute('aria-disabled', true);
              this.submitButtonText.classList.add('hidden');
              soldOutMessage.classList.remove('hidden');
              this.error = true;
              return;
            } else if (!this.cart) {
              window.location = theme.routes.cart_url;
              return;
            }

            if (!this.error)
              publish(PUB_SUB_EVENTS.cartUpdate, {
                source: 'product-form',
                productVariantId: formData.get('id'),
                cartData: response,
              });
            this.error = false;
            const quickAddModal = this.closest('quick-add-modal');
            if (quickAddModal) {
              document.body.addEventListener(
                'modalClosed',
                () => {
                  setTimeout(() => {
                    this.cart.renderContents(response);
                  });
                },
                { once: true }
              );
              quickAddModal.hide(true);
            } else {
              this.cart.renderContents(response);
            }
          })
          .catch((e) => {
            console.error(e);
          })
          .finally(() => {
            this.submitButton.classList.remove('loading');
            if (this.cart && this.cart.classList.contains('is-empty')) this.cart.classList.remove('is-empty');
            if (!this.error) this.submitButton.removeAttribute('aria-disabled');
            //this.querySelector('.loading__spinner').classList.add('hidden');
          });
      }

      onPeteliaGiftOptionsSubmit() {
        const formData = new FormData(this.form);
        const quantity = Math.max(parseInt(formData.get('quantity'), 10) || 1, 1);
        const variantId = Number(formData.get('id'));
        const options = this.collectPeteliaGiftOptions();
        const bundleId = `petelia-${Date.now()}-${Math.random().toString(36).slice(2, 10)}`;
        const properties = this.buildPeteliaMainProductProperties(options, bundleId);
        const items = [
          {
            id: variantId,
            quantity,
            properties,
          },
        ];

        this.buildPeteliaServiceItems(options, quantity, bundleId, variantId).forEach((item) => items.push(item));

        const sections = this.cart ? this.cart.getSectionsToRender().map((section) => section.id) : [];
        if (this.cart) this.cart.setActiveElement(document.activeElement);

        const body = JSON.stringify({
          items,
          sections,
          sections_url: window.PeteliaThemeContext?.sectionPath() || window.location.pathname,
        });

        fetch(`${theme.routes.cart_add_url}`, { ...fetchConfig('javascript'), body })
          .then((response) => response.json())
          .then((response) => {
            if (response.status) {
              publish(PUB_SUB_EVENTS.cartError, {
                source: 'product-form',
                productVariantId: variantId,
                errors: response.errors || response.description,
                message: response.message,
              });
              this.handleErrorMessage(response.description || response.message || 'Errore durante l’aggiunta al carrello.');
              this.error = true;
              return;
            }

            if (!this.cart) {
              window.location = theme.routes.cart_url;
              return;
            }

            publish(PUB_SUB_EVENTS.cartUpdate, {
              source: 'product-form',
              productVariantId: variantId,
              cartData: response,
            });
            this.error = false;

            const quickAddModal = this.closest('quick-add-modal');
            if (quickAddModal) {
              document.body.addEventListener(
                'modalClosed',
                () => {
                  setTimeout(() => {
                    this.cart.renderContents(response);
                  });
                },
                { once: true }
              );
              quickAddModal.hide(true);
            } else {
              this.cart.renderContents(response);
            }
          })
          .catch((e) => {
            console.error(e);
            this.handleErrorMessage('Errore durante l’aggiunta al carrello. Riprova tra qualche secondo.');
            this.error = true;
          })
          .finally(() => {
            this.submitButton.classList.remove('loading');
            if (this.cart && this.cart.classList.contains('is-empty')) this.cart.classList.remove('is-empty');
            if (!this.error) this.submitButton.removeAttribute('aria-disabled');
          });
      }

      validatePeteliaGiftOptions() {
        const options = this.collectPeteliaGiftOptions();
        if (options.caseEngraving && options.caseEngravingText.length > 25) {
          return 'L’incisione sulla cassa può contenere massimo 25 caratteri.';
        }
        return '';
      }

      collectPeteliaGiftOptions() {
        const wrapper = this.peteliaOptionsWrapper;
        const isChecked = (name) => wrapper?.querySelector(`[data-petelia-option="${name}"]`)?.checked === true;
        const getValue = (name) => wrapper?.querySelector(`[data-petelia-input="${name}"]`)?.value?.trim() || '';

        return {
          giftWrap: isChecked('gift-wrap'),
          shopper: isChecked('shopper'),
          boxEngraving: isChecked('box-engraving'),
          boxEngravingText: getValue('box-engraving-text'),
          caseEngraving: isChecked('case-engraving'),
          caseEngravingText: getValue('case-engraving-text'),
          nfc: isChecked('nfc'),
          nfcText: getValue('nfc-text'),
        };
      }

      buildPeteliaMainProductProperties(options, bundleId) {
        const properties = {};
        if (bundleId) properties['_petelia_bundle_id'] = bundleId;
        if (options.giftWrap) properties['Confezione regalo'] = 'Sì';
        if (options.shopper) properties['Shopper Petelia'] = 'Sì';
        // Non-empty placeholders preserve the selected service even when text is deferred.
        if (options.boxEngraving) properties['Incisione box'] = options.boxEngravingText || 'Da comunicare dopo l’ordine';
        if (options.caseEngraving) properties['Incisione cassa'] = options.caseEngravingText || 'Da comunicare dopo l’ordine';
        if (options.nfc) properties['Dedica NFC'] = options.nfcText || 'Da comunicare dopo l’ordine';
        return properties;
      }

      buildPeteliaServiceItems(options, quantity, bundleId, parentVariantId) {
        const serviceItems = [];
        const baseServiceProperties = {
          '_petelia_extra_item': 'true',
          '_petelia_bundle_id': bundleId || '',
        };
        const addService = (variantId, serviceType) => {
          const id = Number(variantId);
          if (!id) return;
          serviceItems.push({
            id,
            quantity,
            properties: {
              ...baseServiceProperties,
              '_petelia_service_type': serviceType,
            },
          });
        };

        if (options.giftWrap) addService(this.dataset.peteliaVariantGiftWrap, 'gift-wrap');
        if (options.shopper) addService(this.dataset.peteliaVariantShopper, 'shopper');

        if (options.boxEngraving && options.caseEngraving) {
          addService(this.dataset.peteliaVariantComboEngraving, 'combo-engraving');
        } else {
          if (options.boxEngraving) addService(this.dataset.peteliaVariantBoxEngraving, 'box-engraving');
          if (options.caseEngraving) addService(this.dataset.peteliaVariantCaseEngraving, 'case-engraving');
        }

        if (options.nfc) addService(this.dataset.peteliaVariantNfc, 'nfc');

        return serviceItems;
      }

      handleErrorMessage(errorMessage = false) {
        if (this.hideErrors) return;

        this.errorMessageWrapper =
          this.errorMessageWrapper || this.querySelector('.product-form__error-message-wrapper');
        if (!this.errorMessageWrapper) return;
        this.errorMessage = this.errorMessage || this.errorMessageWrapper.querySelector('.product-form__error-message');

        this.errorMessageWrapper.toggleAttribute('hidden', !errorMessage);

        if (errorMessage) {
          this.errorMessage.textContent = errorMessage;
        }
      }

      toggleSubmitButton(disable = true, text) {
        if (disable) {
          this.submitButton.setAttribute('disabled', 'disabled');
          if (text) this.submitButtonText.textContent = text;
        } else {
          this.submitButton.removeAttribute('disabled');
          this.submitButtonText.textContent = theme.variantStrings.addToCart;
        }
      }

      get variantIdInput() {
        return this.form.querySelector('[name=id]');
      }
    }
  );
}
