(() => {
  let pending = {};
  let running = null;
  let timer;
  function stage(target) {
    if (target.matches('cart-note [name="note"]')) pending.note = target.value;
    else if (target.matches('gift-note [name="attributes[gift-note]"]')) pending.attributes = { 'gift-note': target.value };
    else return;
    clearTimeout(timer);
    timer = setTimeout(() => flush().catch(console.error), 300);
  }
  function flush() {
    clearTimeout(timer);
    if (running) return running;
    running = (async () => {
      while (Object.keys(pending).length) {
        const body = pending;
        pending = {};
        try {
          const response = await fetch(window.theme?.routes?.cart_update_url || '/cart/update.js', {
            method: 'POST', credentials: 'same-origin',
            headers: { 'Content-Type': 'application/json', Accept: 'application/json' },
            body: JSON.stringify(body)
          });
          if (!response.ok) throw new Error('Impossibile salvare la nota. Riprova prima di proseguire.');
        } catch (error) {
          pending = { ...body, ...pending };
          throw error;
        }
      }
    })().finally(() => { running = null; });
    return running;
  }
  document.addEventListener('input', (event) => stage(event.target));
  document.addEventListener('change', (event) => stage(event.target));
  window.PeteliaCartNotes = { flush };
})();
