class CartRecommendations extends HTMLElement {
  connectedCallback() {
    this.desktop = window.matchMedia('(min-width: 750px)').matches;
    this.dataset.state = 'pending';
    // The desktop panel sits outside the drawer and can be clipped by its ancestors.
    if (this.desktop) this.loadRecommendations();
    else {
      this.observer = new IntersectionObserver((entries) => {
        if (entries.some((entry) => entry.isIntersecting)) {
          this.observer.disconnect();
          this.loadRecommendations();
        }
      });
      this.observer.observe(this);
    }
  }

  disconnectedCallback() {
    this.observer?.disconnect();
    this.controller?.abort();
    clearTimeout(this.timeout);
  }

  async loadRecommendations() {
    if (this.loading) return;
    this.loading = true;
    this.controller = new AbortController();
    this.timeout = setTimeout(() => this.controller.abort(), 10000);
    try {
      const url = window.PeteliaThemeContext?.url(this.dataset.url) || this.dataset.url;
      const response = await fetch(url, { signal: this.controller.signal });
      if (!response.ok) throw new Error('Caricamento consigliati non riuscito.');
      const html = document.createElement('div');
      html.innerHTML = await response.text();
      const recommendations = html.querySelector('cart-recommendations');
      if (!this.isConnected) return;
      if (recommendations?.querySelector('.mini-cart__navigation li')) {
        this.innerHTML = recommendations.innerHTML;
        this.dataset.state = 'ready';
      } else this.dataset.state = 'empty';
    } catch (error) {
      if (this.isConnected) this.dataset.state = 'empty';
      if (error.name !== 'AbortError') console.error(error);
    } finally {
      clearTimeout(this.timeout);
    }
  }
}
customElements.define('cart-recommendations', CartRecommendations);
