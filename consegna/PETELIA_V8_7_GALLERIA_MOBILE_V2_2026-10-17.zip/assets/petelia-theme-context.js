(() => {
  const current = new URL(window.location.href);
  // Shopify's preview hostname already selects the theme. Preserve only an explicit URL parameter.
  const previewId = current.searchParams.get('preview_theme_id') || '';
  window.PeteliaThemeContext = {
    url(value) {
      const url = new URL(value, window.location.origin);
      if (previewId && url.origin === window.location.origin) url.searchParams.set('preview_theme_id', previewId);
      return url.pathname + url.search + url.hash;
    },
    sectionPath() {
      return this.url(window.location.pathname);
    }
  };
})();
