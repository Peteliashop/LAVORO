class CookieBannerCustom extends HTMLElement {
  constructor() {
    super();

    this.classes = {
      activeClass: 'is-active',
      closingClass: 'is-closing'
    };
    
    this.scrollThreshold = 100;
    this.timeThreshold = 5000;
    this.hasInteracted = false;
    this.scrollTimer = null;
    this.timeTimer = null;
    this.initialized = false;
  }

  initEventListeners() {
    const acceptBtn = this.querySelector('button[name="accept"]');
    const settingsBtn = this.querySelector('button[name="settings"]');
    const closeModalBtn = this.querySelector('.cookie-settings__close');
    const overlay = this.querySelector('.cookie-settings__overlay');
    const acceptAllBtn = this.querySelector('button[name="accept-all"]');
    const rejectAllBtn = this.querySelector('button[name="reject-all"]');
    const savePreferencesBtn = this.querySelector('button[name="save-preferences"]');

    if (acceptBtn) acceptBtn.addEventListener('click', this.acceptAll.bind(this));
    if (settingsBtn) settingsBtn.addEventListener('click', this.openSettings.bind(this));
    if (closeModalBtn) closeModalBtn.addEventListener('click', this.closeSettings.bind(this));
    if (overlay) overlay.addEventListener('click', this.closeSettings.bind(this));
    if (acceptAllBtn) acceptAllBtn.addEventListener('click', this.acceptAllFromSettings.bind(this));
    if (rejectAllBtn) rejectAllBtn.addEventListener('click', this.rejectAllFromSettings.bind(this));
    if (savePreferencesBtn) savePreferencesBtn.addEventListener('click', this.savePreferences.bind(this));
  }

  connectedCallback() {
    if (this.initialized) return;
    this.initialized = true;

    this.banner = this.querySelector('.cookie-banner');
    this.modal = this.querySelector('.cookie-settings-modal');

    this.initEventListeners();

    if (window.Shopify && Shopify.designMode) {
      this.onShopifySectionLoad = this.onSectionLoad.bind(this);
      this.onShopifySectionSelect = this.onSectionSelect.bind(this);
      this.onShopifySectionDeselect = this.onSectionDeselect.bind(this);
      document.addEventListener('shopify:section:load', this.onShopifySectionLoad);
      document.addEventListener('shopify:section:select', this.onShopifySectionSelect);
      document.addEventListener('shopify:section:deselect', this.onShopifySectionDeselect);
    }

    if (this.dataset.testMode === 'true') {
      const savedConsent = this.getSavedConsent();
      if (!savedConsent) {
        this.init();
      } else {
        console.log('Consenso già salvato (modalità test):', savedConsent);
      }
    } else if (window.Shopify && window.Shopify.loadFeatures) {
      window.Shopify.loadFeatures([
        {
          name: 'consent-tracking-api',
          version: '0.1',
        }
      ],
      (error) => {
        if (error) {
          throw error;
        }
        this.beforeInit();
      });
    }
  }

  disconnectedCallback() {
    if (window.Shopify && Shopify.designMode) {
      document.removeEventListener('shopify:section:load', this.onShopifySectionLoad);
      document.removeEventListener('shopify:section:select', this.onShopifySectionSelect);
      document.removeEventListener('shopify:section:deselect', this.onShopifySectionDeselect);
    }
    this.removeAutoAcceptListeners();
  }

  onSectionLoad(event) {
    if (event.target.contains(this)) {
      this.open();
    }
  }

  onSectionSelect(event) {
    if (event.target.contains(this)) {
      this.open();
    }
  }

  onSectionDeselect(event) {
    if (event.target.contains(this)) {
      this.close();
    }
  }

  beforeInit() {
    const savedConsent = this.getSavedConsent();
    
    if (savedConsent) {
      const consentPayload = {
        analytics: savedConsent.analytics,
        marketing: savedConsent.marketing,
        preferences: true,
        sale_of_data: savedConsent.marketing
      };
      
      window.Shopify.customerPrivacy.setTrackingConsent(consentPayload, () => {
        console.log('Consenso precedente ripristinato:', consentPayload);
      });
      return;
    }

    if (!window.location.pathname.match(/^(\/[a-z]{2}(-[A-Z]{2})?)?\/cart$/)) {
      this.init();
    }
  }

  getSavedConsent() {
    try {
      const saved = localStorage.getItem('cookieConsent');
      if (saved) {
        const consent = JSON.parse(saved);
        const oneYear = 365 * 24 * 60 * 60 * 1000;
        if (Date.now() - consent.timestamp < oneYear) {
          return consent;
        }
      }
    } catch (e) {
      console.error('Errore lettura consenso salvato:', e);
    }
    return null;
  }

  init() {
    if (window.Shopify && Shopify.designMode) {
      return;
    }

    const savedConsent = this.getSavedConsent();
    if (savedConsent) {
      return;
    }

    setTimeout(() => {
      this.open();
     // this.startAutoAcceptListeners(); // per accettare automaticamente
    }, parseInt(this.dataset.delay) * 1000);
  }

  open() {
    this.banner.classList.add(this.classes.activeClass);
  }

  close() {
    this.banner.classList.add(this.classes.closingClass);
    this.removeAutoAcceptListeners();

    setTimeout(() => {
      this.banner.classList.remove(this.classes.activeClass);
      this.banner.classList.remove(this.classes.closingClass);
    }, 400);
  }

  openSettings() {
    this.hasInteracted = true;
    this.removeAutoAcceptListeners();
    this.modal.style.display = 'flex';
    setTimeout(() => {
      this.modal.classList.add(this.classes.activeClass);
    }, 10);
  }

  closeSettings() {
    this.modal.classList.add(this.classes.closingClass);
    setTimeout(() => {
      this.modal.classList.remove(this.classes.activeClass);
      this.modal.classList.remove(this.classes.closingClass);
      this.modal.style.display = 'none';
    }, 400);
  }

  acceptAll() {
    this.hasInteracted = true;
    this.removeAutoAcceptListeners();
    this.setConsent(true, true, true);
    this.close();
  }

  acceptAllFromSettings() {
    this.hasInteracted = true;
    this.querySelector('input[name="analytics"]').checked = true;
    this.querySelector('input[name="marketing"]').checked = true;
    this.setConsent(true, true, true);
    this.closeSettings();
    this.close();
  }

  rejectAllFromSettings() {
    this.hasInteracted = true;
    this.querySelector('input[name="analytics"]').checked = false;
    this.querySelector('input[name="marketing"]').checked = false;
    this.setConsent(true, false, false);
    this.closeSettings();
    this.close();
  }

  savePreferences() {
    this.hasInteracted = true;
    const analytics = this.querySelector('input[name="analytics"]').checked;
    const marketing = this.querySelector('input[name="marketing"]').checked;
    this.setConsent(true, analytics, marketing);
    this.closeSettings();
    this.close();
  }

  setConsent(essential, analytics, marketing) {
    if (this.dataset.testMode === 'true') {
      console.log('Consenso (modalità test):', { essential, analytics, marketing });
      localStorage.setItem('cookieConsent', JSON.stringify({
        essential,
        analytics,
        marketing,
        timestamp: Date.now()
      }));
      return;
    }
    
    if (window.Shopify && window.Shopify.customerPrivacy) {
      const consentPayload = {
        analytics: analytics,
        marketing: marketing,
        preferences: true,
        sale_of_data: marketing
      };

      window.Shopify.customerPrivacy.setTrackingConsent(consentPayload, () => {
        console.log('Consenso tracking impostato:', consentPayload);
      });

      localStorage.setItem('cookieConsent', JSON.stringify({
        essential,
        analytics,
        marketing,
        timestamp: Date.now()
      }));
    }
  }

  startAutoAcceptListeners() {
    this.onScroll = this.handleScroll.bind(this);
    this.onInteraction = this.handleInteraction.bind(this);
    
    window.addEventListener('scroll', this.onScroll, { passive: true });
    document.addEventListener('click', this.onInteraction);
    document.addEventListener('touchstart', this.onInteraction);

    this.timeTimer = setTimeout(() => {
      if (!this.hasInteracted) {
        this.autoAccept();
      }
    }, this.timeThreshold);
  }

  removeAutoAcceptListeners() {
    if (this.onScroll) {
      window.removeEventListener('scroll', this.onScroll);
    }
    if (this.onInteraction) {
      document.removeEventListener('click', this.onInteraction);
      document.removeEventListener('touchstart', this.onInteraction);
    }
    if (this.scrollTimer) {
      clearTimeout(this.scrollTimer);
    }
    if (this.timeTimer) {
      clearTimeout(this.timeTimer);
    }
  }

  handleScroll() {
    if (this.hasInteracted) return;

    if (window.scrollY > this.scrollThreshold) {
      if (this.scrollTimer) {
        clearTimeout(this.scrollTimer);
      }
      
      this.scrollTimer = setTimeout(() => {
        if (!this.hasInteracted) {
          this.autoAccept();
        }
      }, 1000);
    }
  }

  handleInteraction(event) {
    if (this.hasInteracted) return;
    
    if (!this.banner.contains(event.target) && !this.modal.contains(event.target)) {
      this.hasInteracted = true;
      setTimeout(() => {
        this.autoAccept();
      }, 2000);
    }
  }

  autoAccept() {
    console.log('Auto-accettazione cookie attivata');
    this.setConsent(true, true, true);
    this.close();
  }
}

customElements.define('cookie-banner-custom', CookieBannerCustom);
