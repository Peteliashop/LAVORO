from pathlib import Path
import json
import shutil

root = Path('/workspace/petelia/v3')
previous = Path('/workspace/petelia/v2/theme')
# Copy only the self-contained visual components. Never import assets or cart fixes.
for name in ['countdown-timer.liquid', 'petelia-automatico-strip.liquid']:
    shutil.copyfile(previous / 'sections' / name, root / 'theme/sections' / name)

source = (root / 'base/templates/index.json').read_text()
before = json.loads(source)
prior_home = json.loads((previous / 'templates/index.json').read_text())
key = 'petelia_automatico_strip_dJhXHr'
assert key not in before['sections']
section = prior_home['sections'][key]
needle = '"rich-text-1":'
assert source.count(needle) == 1
source = source.replace(needle, json.dumps(key) + ':' + json.dumps(section, ensure_ascii=False, separators=(',', ':')) + ',' + needle, 1)
needle = '"order":["countdown-timer",'
assert source.count(needle) == 1
source = source.replace(needle, needle + json.dumps(key) + ',', 1)
after = json.loads(source)
assert after['sections'].pop(key) == section
assert after['order'].pop(1) == key
assert after == before
(root / 'theme/templates/index.json').write_text(source)
(root / 'reports').mkdir(exist_ok=True)
(root / 'tools').mkdir(exist_ok=True)
print('Only homepage hero, identical Invektor strip, and homepage insertion written.')
