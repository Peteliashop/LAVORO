const fs=require('node:fs');
const http=require('node:http');
const assert=require('node:assert/strict');
const {chromium}=require('/workspace/petelia/tools/node_modules/playwright-core');
const {fixture}=require('./fixtures.cjs');
const base='/workspace/petelia/v3';
const results=[];
const server=http.createServer(async(req,res)=>{
  try{
    const u=new URL(req.url,'http://local');
    if(u.pathname==='/fixture'){
      res.setHeader('Content-Type','text/html');res.end(await fixture(u.searchParams.get('version')||'theme',u.searchParams.get('type')||'hero',u.searchParams));
    }else if(u.pathname.startsWith('/asset/')){
      const [, ,v,file]=u.pathname.split('/');assert(['theme','base'].includes(v));assert(!file.includes('..'));
      res.setHeader('Content-Type',file.endsWith('.js')?'text/javascript':'text/css');res.end(fs.readFileSync(`${base}/${v}/assets/${file}`));
    }else if(u.pathname.startsWith('/media/')){
      res.setHeader('Content-Type','video/mp4');res.end(fs.readFileSync('/workspace/petelia/tools/test-video.mp4'));
    }else if(u.pathname.startsWith('/image/')){
      if(u.pathname.includes('/hero.svg'))await new Promise(r=>setTimeout(r,300));
      res.setHeader('Content-Type','image/svg+xml');res.end('<svg xmlns="http://www.w3.org/2000/svg" width="941" height="1366"><rect width="941" height="1366" fill="#b39b79"/></svg>');
    }else{res.statusCode=404;res.end('not found');}
  }catch(e){res.statusCode=500;res.end(String(e.stack));}
});
(async()=>{
  await new Promise(r=>server.listen(0,'127.0.0.1',r));
  const origin=`http://127.0.0.1:${server.address().port}`;
  const browser=await chromium.launch({executablePath:'/usr/bin/chromium',headless:true,args:['--no-sandbox']});
  async function test(name,fn){
    try{await fn();results.push({name,status:'passed'});console.log('PASS',name);}
    catch(e){results.push({name,status:'failed',error:e.stack});console.error('FAIL',name,e.message);}
  }
  async function pageFor(type='hero',params='',version='theme',viewport={width:390,height:844},init){
    const p=await browser.newPage({viewport,isMobile:viewport.width<769,hasTouch:true});
    p.errors=[];p.media=[];
    p.on('pageerror',e=>p.errors.push(e.message));
    p.on('request',r=>{if(r.url().includes('/media/'))p.media.push(r.url());});
    await p.route('https://**/*',r=>r.fulfill({status:200,body:'',contentType:'text/css'}));
    if(init)await p.addInitScript(init);
    await p.goto(`${origin}/fixture?type=${type}&version=${version}&${params}`,{waitUntil:'load'});
    return p;
  }
  async function mobileHero(fn,params='',init){const p=await pageFor('hero',params,'theme',undefined,init);try{await fn(p);assert.deepEqual(p.errors,[]);}finally{await p.close();}}
  await test('Mobile: no MP4, no auto rotation through a complete former 12s cycle',()=>mobileHero(async p=>{
    assert.equal(await p.locator('[data-secondary-slot] video').count(),0);
    assert.equal(await p.locator('[data-gallery-controls]').isVisible(),true);
    assert.equal(await p.locator('.slide-1 img').getAttribute('fetchpriority'),'high');
    assert.equal(await p.locator('.slide-1 img').getAttribute('loading'),'eager');
    await p.waitForTimeout(12500);
    assert.equal(p.media.length,0);
    assert.equal(await p.locator('[data-petelia-hero]').getAttribute('data-gallery-index'),'0');
  }));
  await test('Mobile: second dot creates one 720p MP4; return pauses; reopening reuses player',()=>mobileHero(async p=>{
    await p.locator('[data-gallery-dot="1"]').click();
    await p.waitForFunction(()=>{const v=document.querySelector('[data-secondary-slot] video');return v&&!v.paused;});
    assert.equal(await p.locator('[data-secondary-slot] video').count(),1);
    assert(p.media.some(x=>x.endsWith('/media/mobile.mp4')));
    assert(!p.media.some(x=>x.endsWith('/media/desktop.mp4')||x.endsWith('/media/video.mp4')));
    assert.equal(await p.locator('[data-secondary-slot] video').evaluate(v=>v.muted&&v.playsInline&&v.loop),true);
    await p.locator('[data-secondary-slot] video').evaluate(v=>v.dataset.fixtureIdentity='same');
    await p.locator('[data-gallery-dot="0"]').click();
    assert.equal(await p.locator('[data-secondary-slot] video').evaluate(v=>v.paused),true);
    await p.locator('[data-gallery-next]').click();
    assert.equal(await p.locator('[data-secondary-slot] video').getAttribute('data-fixture-identity'),'same');
  }));
  await test('Mobile: real touch swipe changes slides; vertical pan scrolls without changing slide',()=>mobileHero(async p=>{
    const cdp=await p.context().newCDPSession(p);
    async function swipe(x1,y1,x2,y2){
      await cdp.send('Input.dispatchTouchEvent',{type:'touchStart',touchPoints:[{x:x1,y:y1}]});
      for(let i=1;i<=5;i++)await cdp.send('Input.dispatchTouchEvent',{type:'touchMove',touchPoints:[{x:x1+(x2-x1)*i/5,y:y1+(y2-y1)*i/5}]});
      await cdp.send('Input.dispatchTouchEvent',{type:'touchEnd',touchPoints:[]});
      await p.waitForTimeout(250);
    }
    await swipe(300,220,80,220);
    assert.equal(await p.locator('[data-petelia-hero]').getAttribute('data-gallery-index'),'1');
    await swipe(80,220,300,220);
    assert.equal(await p.locator('[data-petelia-hero]').getAttribute('data-gallery-index'),'0');
    await swipe(180,350,180,110);
    assert.equal(await p.locator('[data-petelia-hero]').getAttribute('data-gallery-index'),'0');
    assert(await p.evaluate(()=>window.scrollY>0));
  }));
  await test('Mobile: keyboard navigation and selected indicator stay in sync',()=>mobileHero(async p=>{
    await p.locator('[data-gallery-dot="0"]').focus();await p.keyboard.press('ArrowRight');
    assert.equal(await p.locator('[data-gallery-dot="1"]').getAttribute('aria-pressed'),'true');
    assert.equal(await p.locator('.slide-1').getAttribute('aria-hidden'),'true');
    await p.keyboard.press('ArrowLeft');
    assert.equal(await p.locator('[data-gallery-dot="0"]').getAttribute('aria-pressed'),'true');
  }));
  await test('Mobile: leaving viewport pauses video, returning resumes selected slide only',()=>mobileHero(async p=>{
    await p.locator('[data-gallery-dot="1"]').click();
    await p.waitForFunction(()=>!document.querySelector('video').paused);
    await p.evaluate(()=>window.scrollTo(0,2000));
    await p.waitForFunction(()=>document.querySelector('video').paused);
    await p.evaluate(()=>window.scrollTo(0,0));
    await p.waitForFunction(()=>!document.querySelector('video').paused);
    await p.locator('[data-gallery-dot="0"]').click();
    await p.evaluate(()=>{window.scrollTo(0,2000);});await p.waitForTimeout(100);
    await p.evaluate(()=>window.scrollTo(0,0));await p.waitForTimeout(100);
    assert.equal(await p.locator('video').evaluate(v=>v.paused),true);
  }));
  await test('Mobile: blocked playback exposes a working explicit play button',()=>mobileHero(async p=>{
    await p.locator('[data-gallery-dot="1"]').click();
    await p.waitForFunction(()=>!document.querySelector('[data-gallery-play]').hidden);
    await p.evaluate(()=>{HTMLMediaElement.prototype.play=window.fixtureOriginalPlay;});
    await p.locator('[data-gallery-play]').click();
    await p.waitForFunction(()=>!document.querySelector('video').paused && document.querySelector('[data-gallery-play]').hidden);
    assert.equal(await p.locator('[data-gallery-play]').isVisible(),false);
  },'',()=>{window.fixtureOriginalPlay=HTMLMediaElement.prototype.play;HTMLMediaElement.prototype.play=function(){return Promise.reject(new DOMException('Blocked in fixture','NotAllowedError'));};}));
  await test('Mobile: video error returns to first image without a blank slide',()=>mobileHero(async p=>{
    await p.locator('[data-gallery-dot="1"]').click();
    await p.locator('video').evaluate(v=>v.dispatchEvent(new Event('error')));
    assert.equal(await p.locator('[data-petelia-hero]').getAttribute('data-gallery-index'),'0');
    assert.equal(await p.locator('[data-gallery-controls]').isVisible(),false);
    assert.equal(await p.locator('.slide-1').getAttribute('aria-hidden'),'false');
  }));
  await test('Mobile: video error falls back to the configured second image',()=>mobileHero(async p=>{
    await p.locator('[data-gallery-dot="1"]').click();
    await p.locator('video').evaluate(v=>v.dispatchEvent(new Event('error')));
    assert.equal(await p.locator('[data-secondary-slot] video').count(),0);
    assert.equal(await p.locator('[data-secondary-slot] img').count(),1);
    assert.equal(await p.locator('[data-gallery-dot="1"]').getAttribute('aria-label'),'Mostra la seconda immagine');
    assert.equal(await p.locator('[data-gallery-status]').textContent(),'Immagine, 2 di 2');
  },'secondary=1'));
  await test('Mobile: no secondary media means no controls; image fallback needs no video',async()=>{
    for(const params of ['noVideo=1','mode=none','noVideo=1&secondary=1']){
      const p=await pageFor('hero',params);try{
        const secondary=params.includes('secondary');
        assert.equal(await p.locator('[data-gallery-controls]').isVisible(),secondary);
        if(secondary){await p.locator('[data-gallery-dot="1"]').click();assert.equal(await p.locator('[data-secondary-slot] img').count(),1);}
        assert.equal(p.media.length,0);assert.deepEqual(p.errors,[]);
      }finally{await p.close();}
    }
  });
  await test('Desktop: current mobile-only configuration stays static through breakpoint changes',async()=>{
    const p=await pageFor('hero','','theme',{width:1440,height:900});try{
      assert.equal(await p.locator('[data-gallery-controls]').isVisible(),false);assert.equal(p.media.length,0);
      assert((await p.locator('.slide-1 img').evaluate(i=>i.currentSrc)).includes('desktop.svg'));
      await p.setViewportSize({width:390,height:844});await p.waitForFunction(()=>document.querySelector('[data-petelia-hero]').dataset.mobileGallery==='true');
      assert.equal(p.media.length,0);await p.locator('[data-gallery-dot="1"]').click();
      await p.setViewportSize({width:1440,height:900});await p.waitForFunction(()=>!document.querySelector('[data-secondary-slot] video'));
      assert.equal(await p.locator('[data-gallery-controls]').isVisible(),false);assert.deepEqual(p.errors,[]);
    }finally{await p.close();}
  });
  await test('Desktop: explicitly configured desktop video still activates after first image',async()=>{
    const p=await pageFor('hero','mode=all','theme',{width:1440,height:900});try{
      await p.waitForFunction(()=>!!document.querySelector('[data-secondary-slot] video'));
      assert.equal(await p.locator('[data-petelia-hero]').getAttribute('data-second-active'),'true');
      assert.equal(await p.locator('[data-gallery-controls]').isVisible(),false);assert.deepEqual(p.errors,[]);
    }finally{await p.close();}
  });
  await test('Mobile: editor unload cleans handlers and pending playback',()=>mobileHero(async p=>{
    await p.locator('[data-gallery-dot="1"]').click();
    await p.evaluate(()=>document.getElementById('shopify-section-fixture').dispatchEvent(new CustomEvent('shopify:section:unload',{bubbles:true})));
    assert.equal(await p.locator('video').evaluate(v=>v.paused),true);
    await p.locator('[data-gallery-dot="0"]').click();
    assert.equal(await p.locator('[data-petelia-hero]').getAttribute('data-gallery-index'),'1');
  }));
  await test('Mobile: reduced motion disables gallery transitions',async()=>{
    const p=await pageFor();try{
      await p.emulateMedia({reducedMotion:'reduce'});
      assert.equal(await p.locator('.slide-1').evaluate(e=>getComputedStyle(e).transitionDuration),'0s');
    }finally{await p.close();}
  });
  await test('Mobile: hero dimensions and CTA links remain stable; controls do not overlap CTA',async()=>{
    for(const width of [320,390,430,768]){
      const p=await pageFor('hero','','theme',{width,height:900});const old=await pageFor('hero','','base',{width,height:900});
      try{
        const box=await p.locator('[data-petelia-hero]').boundingBox();const previous=await old.locator('[data-petelia-hero]').boundingBox();
        assert(Math.abs(box.height-previous.height)<1,`height ${width}: ${box.height} vs ${previous.height}`);
        assert.deepEqual(await p.locator('.shop-buttons-container a').evaluateAll(a=>a.map(x=>({text:x.textContent,href:x.getAttribute('href')}))),await old.locator('.shop-buttons-container a').evaluateAll(a=>a.map(x=>({text:x.textContent,href:x.getAttribute('href')}))));
        const cta=await p.locator('.shop-buttons-container').boundingBox();const dots=await p.locator('.petelia-gallery-dots').boundingBox();
        assert(cta.y+cta.height<=dots.y,`CTA overlaps dots at ${width}`);
        await p.locator('[data-gallery-dot="1"]').click();
        assert(Math.abs((await p.locator('[data-petelia-hero]').boundingBox()).height-box.height)<1);
        if(width===390){await p.locator('[data-gallery-dot="0"]').click();await p.waitForTimeout(250);await p.screenshot({path:base+'/reports/hero-local-mobile.png'});}
      }finally{await p.close();await old.close();}
    }
  });
  await test('Hero without JavaScript retains the first image and hides inactive navigation',async()=>{
    const p=await browser.newPage({viewport:{width:390,height:844},javaScriptEnabled:false});try{
      await p.route('https://**/*',r=>r.fulfill({status:200,body:'',contentType:'text/css'}));
      await p.goto(origin+'/fixture?type=hero&version=theme');
      assert.equal(await p.locator('.slide-1 img').isVisible(),true);
      assert.equal(await p.locator('[data-gallery-controls]').isVisible(),false);
      assert.equal(await p.locator('[data-secondary-slot] video').count(),0);
    }finally{await p.close();}
  });

  await test('Invektor: identical banner layout remains usable at mobile, tablet, desktop widths',async()=>{
    for(const width of [320,390,430,768,990,1440]){
      const p=await pageFor('strip','','theme',{width,height:900});
      try{
        const box=await p.locator('.pai-banner').boundingBox();
        assert.equal(Math.round(box.height),width<750?64:144);
        assert.equal(Math.round(box.width),width);
        assert.equal(await p.locator('a.pai-banner').getAttribute('href'),'https://peteliashop.com');
        assert.equal((await p.locator('.pai-cta').textContent()).trim().replace(/\s+/g,' '),'Il primo automatico');
        assert.equal(await p.locator('.pai-copy').isVisible(),width>=990);
        assert.equal(await p.locator('img.pai-image').getAttribute('loading'),'lazy');
        assert((await p.locator('img.pai-image').getAttribute('srcset')).includes('width=360'));
        const cta=await p.locator('.pai-cta').boundingBox();
        assert(cta.x>=box.x && cta.x+cta.width<=box.x+box.width);
        assert.equal(await p.evaluate(()=>document.documentElement.scrollWidth<=innerWidth),true);
        assert.deepEqual(p.errors,[]);
      }finally{await p.close();}
    }
  });
  await test('Invektor: editor-selected image retains responsive variants and same text/link',async()=>{
    const p=await pageFor('strip','image=1');
    try{
      assert((await p.locator('.pai-image').getAttribute('src')).includes('/image/strip.svg'));
      assert.equal(await p.locator('.pai-image').getAttribute('loading'),'lazy');
      assert.equal(await p.locator('.pai-banner').getAttribute('aria-label'),'Scopri Invektor, il modello automatico Petelia');
      assert.deepEqual(p.errors,[]);
    }finally{await p.close();}
  });
  await test('Homepage: actual countdown expiry and CTAs retained; banner makes no cart or checkout requests',async()=>{
    const p=await browser.newPage({viewport:{width:390,height:844},isMobile:true,hasTouch:true});
    const requests=[];
    p.on('request',r=>requests.push(new URL(r.url()).pathname));
    try{
      await p.route('https://**/*',r=>r.fulfill({status:200,body:'',contentType:'text/css'}));
      await p.goto(origin+'/fixture?type=hero&version=theme&realSettings=1');
      assert.equal(await p.locator('.autonomous-countdown').getAttribute('data-date'),'2026-10-18T23:59:59');
      assert.deepEqual(await p.locator('.shop-buttons-container a').evaluateAll(a=>a.map(x=>x.textContent.trim())),['PER LEI','PER LUI']);
      await p.locator('[data-gallery-dot="1"]').click();
      await p.locator('[data-gallery-dot="0"]').click();
      assert(!requests.some(u=>/\/(cart|checkout)(\/|\.|$)/.test(u)));
    }finally{await p.close();}
  });
  await browser.close();server.close();
  fs.writeFileSync(base+'/reports/browser-tests.json',JSON.stringify({scope:'Offline Chromium with synthetic media and Shopify response fixtures. No live Shopify/Meta/checkout certification.',results},null,2));
  console.log(JSON.stringify({passed:results.filter(x=>x.status==='passed').length,failed:results.filter(x=>x.status==='failed').length}));
  process.exitCode=results.some(x=>x.status==='failed')?1:0;
})().catch(e=>{console.error(e);server.close();process.exit(1);});
