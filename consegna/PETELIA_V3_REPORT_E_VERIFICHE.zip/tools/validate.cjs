const fs=require('node:fs');
const path=require('node:path');
const crypto=require('node:crypto');
const assert=require('node:assert/strict');
const cp=require('node:child_process');
const vm=require('node:vm');
const {parse:parseJsonc}=require('/workspace/petelia/tools/node_modules/jsonc-parser');
const {toLiquidHtmlAST}=require('/workspace/petelia/tools/node_modules/@shopify/liquid-html-parser');
const root='/workspace/petelia/v3';
const hash=b=>crypto.createHash('sha256').update(b).digest('hex');
function files(dir){return fs.readdirSync(dir,{withFileTypes:true}).flatMap(e=>e.isDirectory()?files(path.join(dir,e.name)):[path.join(dir,e.name)]);}
const beforeFiles=files(root+'/base').map(f=>path.relative(root+'/base',f)).sort();
const afterFiles=files(root+'/theme').map(f=>path.relative(root+'/theme',f)).sort();
const removed=beforeFiles.filter(f=>!afterFiles.includes(f));
const added=afterFiles.filter(f=>!beforeFiles.includes(f));
const changed=beforeFiles.filter(f=>!fs.readFileSync(root+'/base/'+f).equals(fs.readFileSync(root+'/theme/'+f)));
assert.deepEqual(removed,[]);
assert.deepEqual(added,['sections/petelia-automatico-strip.liquid']);
assert.deepEqual(changed,['sections/countdown-timer.liquid','templates/index.json']);
const protectedFiles=beforeFiles.filter(f=>!changed.includes(f));
assert(protectedFiles.filter(f=>f.startsWith('assets/')).length>0);
for(const f of protectedFiles)assert.equal(hash(fs.readFileSync(root+'/base/'+f)),hash(fs.readFileSync(root+'/theme/'+f)),f);
const before=JSON.parse(fs.readFileSync(root+'/base/templates/index.json'));
const after=JSON.parse(fs.readFileSync(root+'/theme/templates/index.json'));
const prior=JSON.parse(fs.readFileSync('/workspace/petelia/v2/theme/templates/index.json'));
const key='petelia_automatico_strip_dJhXHr';
assert.deepEqual(after.sections[key],prior.sections[key]);
assert.equal(after.order[1],key);
delete after.sections[key];after.order.splice(1,1);
assert.deepEqual(after,before);
assert.equal(after.sections['countdown-timer'].settings.countdown_expiry,'2026-10-18T23:59:59');
assert(fs.readFileSync(root+'/theme/sections/petelia-automatico-strip.liquid').equals(fs.readFileSync('/workspace/petelia/v2/theme/sections/petelia-automatico-strip.liquid')));
const hero=fs.readFileSync(root+'/theme/sections/countdown-timer.liquid','utf8');
const oldHero=fs.readFileSync(root+'/base/sections/countdown-timer.liquid','utf8');
const schema=s=>JSON.parse(s.match(/{%\s*schema\s*%}([\s\S]*?){%\s*endschema\s*%}/)[1]);
const oldSchema=schema(oldHero),newSchema=schema(hero);
newSchema.settings.find(s=>s.id==='video_display').info=oldSchema.settings.find(s=>s.id==='video_display').info;
assert.deepEqual(newSchema,oldSchema);
for(const f of [changed[0],added[0]])toLiquidHtmlAST(fs.readFileSync(root+'/theme/'+f,'utf8'),{mode:'strict'});
const scripts=[...hero.matchAll(/<script>([\s\S]*?)<\/script>/g)];
assert.equal(scripts.length,1);new vm.Script(scripts[0][1]);
assert(!/\b(fetch|XMLHttpRequest|localStorage|sessionStorage|PeteliaCartGuard|PeteliaCartNotes)\b/.test(scripts[0][1]));
assert(!scripts[0][1].includes('pageshow'));
const js=afterFiles.filter(f=>f.startsWith('assets/')&&f.endsWith('.js'));
for(const f of js){const result=cp.spawnSync('node',['--check',root+'/theme/'+f],{encoding:'utf8'});assert.equal(result.status,0,result.stderr);}
const json=afterFiles.filter(f=>f.endsWith('.json'));
for(const f of json)JSON.parse(fs.readFileSync(root+'/theme/'+f,'utf8'));
let schemas=0;
const unchangedSchemaTrailingCommas=[];
for(const f of afterFiles.filter(f=>f.endsWith('.liquid'))){
  for(const m of fs.readFileSync(root+'/theme/'+f,'utf8').matchAll(/{%-?\s*schema\s*-?%}([\s\S]*?){%-?\s*endschema\s*-?%}/g)){
    try{JSON.parse(m[1]);schemas++;}
    catch(error){
      assert(protectedFiles.includes(f),`Changed schema must parse strictly: ${f}`);
      const errors=[];parseJsonc(m[1],errors,{allowTrailingComma:true,disallowComments:true});
      assert.deepEqual(errors,[],f);
      unchangedSchemaTrailingCommas.push(f);
    }
  }
}
const oldDiagnostics=JSON.parse(fs.readFileSync(root+'/reports/theme-check-base.json'));
const newDiagnostics=JSON.parse(fs.readFileSync(root+'/reports/theme-check-v3.json'));
const keyOf=o=>JSON.stringify([o.uri.replace('/base/','/theme/'),o.check,o.message,o.severity]);
const oldSet=new Set(oldDiagnostics.map(keyOf));
const newErrors=newDiagnostics.filter(o=>o.severity===0&&!oldSet.has(keyOf(o)));
assert.equal(newErrors.length,0,JSON.stringify(newErrors));
const report={input_theme_files:beforeFiles.length,output_theme_files:afterFiles.length,changed_files:changed,added_files:added,removed_files:removed,
  byte_identical_original_files:protectedFiles.length,all_assets_byte_identical:true,all_other_sections_templates_snippets_layout_config_byte_identical:true,
  homepage_settings_except_added_invektor_identical:true,invektor_file_and_settings_identical_to_previous:true,
  countdown_expiry_preserved:'2026-10-18T23:59:59',all_hero_schema_setting_ids_types_defaults_preserved:true,
  hero_has_no_cart_requests_storage_or_pageshow_handlers:true,
  javascript_syntax_passed:js.length,json_parsed:json.length,embedded_schema_strict_json_parsed:schemas,
  unchanged_schemas_with_existing_trailing_commas:unchangedSchemaTrailingCommas,
  changed_and_added_liquid_parser:'strict passed',inline_hero_javascript:'passed',
  theme_check:{before:oldDiagnostics.length,after:newDiagnostics.length,new_errors:newErrors},
  limitations:['Only local component browser fixtures; no live Shopify checkout, PayPal, Meta WebView or PageSpeed measurements.',
    'Cart implementation is byte-identical to the newly uploaded theme. No pre-existing checkout return issue is claimed to be fixed.'],
  file_manifest:Object.fromEntries(afterFiles.map(f=>[f,{input_sha256:beforeFiles.includes(f)?hash(fs.readFileSync(root+'/base/'+f)):null,output_sha256:hash(fs.readFileSync(root+'/theme/'+f))}]))};
fs.writeFileSync(root+'/reports/validation.json',JSON.stringify(report,null,2));
console.log(JSON.stringify({...report,file_manifest:undefined},null,2));
