# Checklist di accettazione — solo sulla copia non pubblicata

Non completata da questa sessione: richiede la preview Shopify, il catalogo reale, dispositivi e integrazioni del negozio. Segnare ogni esito e conservare screenshot/errori. Non eseguire un ordine o un pagamento reale involontariamente: per il test di acquisto usare il metodo concordato dal proprietario e gli strumenti di prova disponibili, evitando modifiche alle impostazioni di pagamento del negozio operativo.

## Importazione e confronto visivo

- [ ] ZIP importato senza errori. Nessuna pubblicazione automatica.
- [ ] Editor carica homepage, header/footer e tutte le sezioni; app embeds Judge.me/Inbox presenti come nell'originale.
- [ ] Confronto originale/copia a 360, 390, 430, 768, 1024 e 1440 px, stesso zoom e stessa lingua.
- [ ] Logo, colori, font Poppins/Playfair, spaziature, promozione e countdown identici al comportamento atteso. La scadenza configurata è 10/10/2026: il messaggio alternativo è preesistente.
- [ ] Hero: stessa foto/ritaglio, CTA PER LEI/PER LUI corrette, video sui soli dispositivi configurati, dissolvenza e ciclo di 12 s dopo disponibilità dell'immagine. Nessun buco nero al primo cambio slide.
- [ ] Primo accesso con cache vuota e accesso con immagine in cache, orientamento ruotato e ridimensionamento mobile/desktop.
- [ ] Modalità risparmio energetico/autoplay impedito: la prima foto e il poster garantiscono una presentazione accettabile; CTA utilizzabili.
- [ ] Strip Invektor e destinazione petelishop.com verificate dal proprietario; nessuna destinazione è stata corretta automaticamente.
- [ ] Tre icone categoria nitide e proporzionate; collezioni a due righe con stesso numero/ordine prodotti, scorrimento, seconda immagine desktop, quick buy/quick view.
- [ ] Slideshow gioielli su Chrome, Safari iOS/macOS e nell'editor; trascinamento e CTA funzionanti.
- [ ] Video istituzionale visibile e riprodotto dopo scorrimento, anche rapido; GIF regalo animato; Trustpilot/WhatsApp e footer corretti.

## Mare Nostrum, Silva Viridis e altre pagine prodotto

- [ ] Confermati URL esatti e template assegnato; aprire i due prodotti conservando l'anteprima del nuovo tema. Provare anche prodotto senza varianti e prodotto con varianti.
- [ ] Foto iniziale corretta su accesso diretto, accesso con variante preselezionata e navigazione dalla homepage.
- [ ] Galleria completa: swipe rapido, miniature, variante disponibile/esaurita, zoom/modal, video prodotto e modelli 3D se presenti. Nessuna foto mancante dopo cambio variante.
- [ ] Ritorno con il tasto indietro ripristina pagina/galleria; quantità, prezzi, disponibilità e sconti non cambiano.
- [ ] Ricerca, menu, raccolte, visti di recente, raccomandazioni e quick view ancora utilizzabili.

## Personalizzazioni e carrello

- [ ] Acquisto semplice senza extra, aggiunta e rimozione.
- [ ] Confezione regalo e Shopper: ciascuno singolarmente e insieme.
- [ ] Incisione cassa: testo breve/lungo e testo vuoto secondo le regole preesistenti.
- [ ] Incisione box: testo breve/lungo e testo vuoto.
- [ ] Combo incisioni: entrambe le scelte e i testi, riepilogo e prezzo corretti; nessun doppio addebito.
- [ ] Dedica NFC: scelta, contenuto e prezzo; combinazione con gli altri extra.
- [ ] Due orologi diversi e due orologi uguali con personalizzazioni differenti: gruppi/servizi separati correttamente.
- [ ] Quantità 2, modifica quantità, eliminazione di un gruppo, svuotamento carrello e nuova aggiunta.
- [ ] Drawer e pagina carrello concordano su totali, servizi e testi; gestione note invariata.
- [ ] Le proprietà tecniche indesiderate _petelia_main_item e _petelia_requires_* non vengono reintrodotte. Gli identificativi bundle già previsti continuano a funzionare.
- [ ] Carrello con contenuto precedente all'importazione e nuova aggiunta: compatibilità del guard e nessuna duplicazione servizi.
- [ ] Redirect checkout, pagamento rapido/PayPal, annullamento e ritorno dal checkout. Nessun blocco nella navigazione indietro.
- [ ] Se effettuato un ordine di prova autorizzato: riepilogo e testi ricevuti corrispondono al carrello; verificare il flusso che gestisce “Da comunicare dopo l'ordine”.

## Consenso e Meta

- [ ] Nuova sessione: consenso accettato, rifiutato e successivamente modificato secondo il flusso Shopify esistente.
- [ ] Pixel ufficiale senza duplicazioni; PageView e ViewContent secondo il consenso e il comportamento atteso.
- [ ] AddToCart/InitiateCheckout corretti e non duplicati; Purchase solo con prova di acquisto autorizzata.
- [ ] Pixel Helper e Test Events confrontati prima/dopo. La preview può avere comportamento diverso e dati limitati: non interpretare l'assenza di eventi in preview come guasto certo.
- [ ] Conversions API e deduplicazione controllate negli strumenti del negozio senza aggiungere pixel, CAPI o nuovo consenso.
- [ ] UTM e fbclid rimangono nell'URL previsto e attribuzione campagne invariata. Non richiedere a una singola prova di produrre un aumento immediato della qualità di associazione.

## PageSpeed e misure comparabili

- [ ] Scegliere homepage, URL esatto Mare Nostrum e URL esatto Silva Viridis. Verificare che ogni URL stia rendendo il tema corretto.
- [ ] Stabilire condizioni identiche: stesso strumento/versione Chrome, viewport mobile, profilo CPU e rete, località, consenso, stato di login e carrello. Cache svuotata e nuovo contesto per il primo accesso; non falsare le richieste Meta/app.
- [ ] Eseguire almeno tre prove prima e tre dopo per URL; registrare mediana e variabilità. Non mescolare dati CrUX del negozio con quelli di laboratorio della preview.
- [ ] Annotare LCP/FCP/TBT/CLS, TTFB, peso trasferito, numero richieste, elemento e URL LCP, breakdown del suo tempo, long task e app responsabili.
- [ ] Nella scheda Network verificare che hero abbia priorità alta, video secondario inizi dopo la prima immagine e il video inferiore non parta al parsing. Registrare quanti media lazy vengono anticipati dal browser.
- [ ] Registrare shift causati da font, header, immagini, recensioni e consenso; non limitarsi al punteggio totale.
- [ ] Per preview protette da cookie o non raggiungibili da PageSpeed, usare Lighthouse/DevTools nel browser che sta visualizzando la preview. Il servizio PageSpeed remoto non eredita automaticamente i cookie della preview.
- [ ] Dopo pubblicazione eventualmente autorizzata, monitorare dati reali; CrUX aggrega periodi e potrebbe non avere dati sufficienti per singolo URL. Non promettere variazioni immediate del 75° percentile.

Tabella da compilare con misure reali, attualmente non disponibili:

| Pagina / tema | LCP | FCP | TBT | CLS | Elemento LCP / condizioni |
|---|---|---|---|---|---|
| Homepage originale | Da misurare | Da misurare | Da misurare | Da misurare | |
| Homepage copia | Da misurare | Da misurare | Da misurare | Da misurare | |
| Mare Nostrum originale | Da misurare | Da misurare | Da misurare | Da misurare | |
| Mare Nostrum copia | Da misurare | Da misurare | Da misurare | Da misurare | |
| Silva Viridis originale | Da misurare | Da misurare | Da misurare | Da misurare | |
| Silva Viridis copia | Da misurare | Da misurare | Da misurare | Da misurare | |

## Instagram/Facebook su dispositivi reali

- [ ] iPhone Safari/WebView Instagram e Facebook; Android Chrome/WebView Instagram e Facebook.
- [ ] Aprire il link di un annuncio reale verso homepage e prodotti; registrare video schermo e tempi con rete mobile, primo accesso e successivo ritorno.
- [ ] Provare risparmio dati/energia e autoplay limitato. Nessun trattamento speciale del punteggio o caricamento in base a user-agent è stato aggiunto.
- [ ] Personalizza, scrivi incisioni/NFC, aggiungi extra, apri drawer, procedi a checkout/PayPal e torna indietro.
- [ ] Controllare che consenso, link esterni e WhatsApp non lascino il negozio in una schermata di caricamento.

Se un controllo commerciale o visivo fallisce, mantenere la copia non pubblicata, conservare URL/dispositivo/passaggi e correggere il problema nella copia. Il tema originale rimane il riferimento di rollback.
