# Petelia — diagnosi prima delle modifiche

Analisi del 17 ottobre 2026. Fonte: ZIP `theme_export_peteliashop_com_copia_di_copia_di_petelia_tema_v8_7.zip`, brief letto integralmente e indicazioni dell'utente: homepage prioritaria, poi Mare Nostrum e Silva Viridis. Questo documento è stato preparato prima di modificare il tema. Nessun accesso amministrativo o modifica al negozio pubblicato.

## Cosa è accertato e cosa resta da misurare

Lo ZIP contiene 347 file, 5.541.087 byte non compressi; l'archivio pesa 1.074.211 byte. Questi numeri NON sono il peso di una pagina: traduzioni, schemi Liquid e modelli non vengono scaricati integralmente dal visitatore. Le foto e i video del catalogo sono risorse Shopify remote, non gli originali incorporati nello ZIP. Localmente sono presenti soltanto `cross.png` e `cross.svg` come immagini negli assets.

La verifica statica copre tutti i file: configurazioni, JSON dei template/gruppi, sezioni, snippet, CSS, JavaScript, riferimenti a media e asset. Il percorso critico è stato esaminato in dettaglio su layout, homepage, galleria prodotto, card prodotto, video, font, transizioni e caricamento app. I flussi commerciali sono stati identificati per preservarli, non riscritti.

La richiesta pubblica a `https://peteliashop.com/` è stata rifiutata dal proxy dell'ambiente con HTTP 403 al tunnel CONNECT. Non è una risposta del negozio né una prova di problemi del negozio. Anche PageSpeed è fuori dalla policy corrente. Non sono disponibili HTML vivo, waterfall, tempi reali, CrUX, URL esatti dei prodotti, varianti e originali CDN. Gli handle Mare Nostrum e Silva Viridis non vengono dati per verificati. Sono state salvate aggiunte di rete nella bozza dell'ambiente; il salvataggio non le applica alla macchina.

Il punteggio mobile circa 64 è un riferimento storico del brief/screenshot. Lo screenshot compresso non permette di confermare numeri precisi. Nessun LCP di 21 secondi viene assunto come misurato; nessun punteggio dopo l'intervento viene promesso.

## Mappa del caricamento

Homepage: gruppo header (strip scorrevole e header/logo), `countdown-timer` (immagine hero, seconda slide video solo mobile), strip Invektor, `rich-text` (tre immagini/categorie codificate nel file anche con titolo vuoto), collezione uomo, carosello Judge.me, collezione donna, carosello incisioni/confezioni, slideshow gioielli, video istituzionale, garanzie, blocco WhatsApp/Font Awesome, immagine Trustpilot, footer e dock mobile. `shop-the-look` è disabilitato.

Pagina prodotto standard: spazio iniziale, `main-product` (galleria, varianti, personalizzazioni, pulsanti e pagamento dinamico), raccomandazioni, visti di recente e Judge.me. I media del singolo prodotto e l'assegnazione effettiva del template ai due prodotti non sono inclusi nell'export. Gli altri template prodotto presenti sono gift-card, modal e pre-order.

App embeds attivi nella configurazione: Judge.me e Shopify Inbox. Ecomsend è disabilitato. Il cookie banner personalizzato del gruppo overlay è disabilitato: questo NON dimostra che manchi il consenso Shopify. Il blocco Clarity nel layout è commentato, quindi non va contato come script attivo. `content_for_header` e i blocchi app possono aggiungere codice in produzione non contenuto nello ZIP.

## Criticità ordinate per impatto

| Priorità | Evidenza nel tema originale | Effetto atteso / metrica | Intervento e limiti |
|---|---|---|---|
| P1 homepage | `countdown-timer.liquid`: l'immagine iniziale ha già `picture`, `srcset`, `sizes=100vw`, dimensioni, `loading=eager`, `fetchpriority=high`. Però `configureMedia()` viene chiamata subito, clona il video, imposta `preload=auto`, autoplay e chiama `play()` mentre la seconda slide è invisibile per circa metà del ciclo di 12 s. | La priorità alta dell'immagine non elimina la concorrenza video. Possibile ritardo del candidato LCP su rete mobile. Quantità di byte e tempo da misurare. | Dare precedenza al completamento della prima immagine prima di attivare i media secondari. Conservare video, dispositivi selezionati, audio disattivato, playsinline, fallback e durata delle animazioni. Non sostituire il video con un fermo immagine né introdurre attese arbitrarie. |
| P1 homepage | Entrambe le chiamate a `card-product` in `featured-collection.liquid` omettono `lazy_load`. Lo snippet assegna `eager` quando il parametro non è vero. Vale per le due collezioni homepage e anche per foto secondarie delle card. | Scaricamento immediato di immagini fuori schermo: banda sottratta al banner e lavoro di decodifica. | Passare esplicitamente `lazy_load: true` nelle collezioni sotto l'hero. Mantenere eager le prime card se la sezione viene usata in prima posizione in un altro template. Il lazy loading nativo può comunque anticipare immagini vicine: verificare waterfall. |
| P1 PDP | `main-product.liquid` passa `lazy_load:false` alla foto in evidenza, ma non passa il parametro alle altre foto. `product-image.liquid` usa eager come valore di fatto predefinito. Manca `fetchpriority` per la foto iniziale. | Galleria intera candidata al download iniziale; risorsa principale non distinta dalle secondarie. Possibile peggioramento LCP e traffico mobile. | Passare lazy alle immagini non iniziali, mantenendo eager la prima/selezionata e attribuendole priorità alta. Conservare associazioni variante, gallerie, zoom e media video/3D. Non ridurre le immagini dello zoom. |
| P1/P2 media | `rich-text.liquid` ha tre URL CDN originali senza varianti dimensionali; visualizzazione in contenitori di circa 110 px. Il GIF confezione in `image-with-text-overlay.liquid` è richiesto per una rappresentazione di 2em. | Possibile sovradimensionamento marcato; peso originale non misurabile con la rete corrente. | Per le tre icone usare varianti CDN 110/220/330 px, sizes coerente e lazy. Per il GIF mantenere l'animazione e richiedere lazy, senza conversione statica automatica. |
| P2 homepage | `video-hero.liquid` sotto varie sezioni emette direttamente un video con autoplay e poster richiesto a `3840px`. L'IntersectionObserver in `global.js` rimanda `play()` ma non impedisce il download anticipato di un video autoplay già nell'HTML. | Concorrenza iniziale evitabile per video lontano dallo schermo. | Lasciare il markup video in un template inerte fino alla prossimità del viewport; riusare il componente Be Yours e il suo margine di 600 px. Preservare il loop/autoplay una volta vicino alla sezione. Nessuna modifica ai player prodotto o YouTube/Vimeo. |
| P2 font/CSS | La prima riga di `countdown-timer.liquid` è un foglio Google Fonts sincrono. Playfair Display è usato nel countdown e nelle categorie. Poppins è già pre-caricato e usa font-display swap nel tema. | Richiesta esterna che può bloccare il rendering; dipende da DNS, TLS e risposta Google. | Rendere non bloccante il solo foglio Playfair, con fallback noscript, mantenendo famiglia, pesi e display=swap. Valutare il cambio font su rete lenta per CLS. Non cambiare i caratteri del brand. |
| P2/P3 risorse mancanti | `slideshow.liquid` richiede `component-slideshow.js`, assente. Il medesimo componente è già definito in `global.js` alle righe 1616–1821 e theme-editor lo usa. | Richiesta inutile/404 sul percorso homepage. | Rimuovere soltanto il tag dello script assente; mantenere la classe e la registrazione reali in global.js. La navigazione dello slideshow deve essere provata in preview. |
| P2 app / da misurare | Judge.me, Inbox, Shopify runtime, pagamenti e pixel possono aggiungere script tramite HTML generato e app embeds. I quattro script base sono già defer: vendor-v4 44 KB, pubsub 779 B, global 100 KB, modules-basis 4 KB non compressi. `apps.css` è già non bloccante. | Possibile TBT/INP da esecuzione JS o richieste terze. Non quantificabile dalla sola dimensione dei file. | Non rimuovere, ritardare fino all'interazione o duplicare pixel/app/pagamenti. Misurare task lunghi e attribuzione su preview reale prima di cambiare il codice globale. |
| P2/P3 CSS | base.css circa 70,8 KB; main-product.css circa 44 KB richiesto anche dalla homepage per quick view; componenti card/prezzo vengono inclusi più volte nel markup. Il browser può riusare URL uguali dalla cache. | Possibili blocchi di stile e ritardo JS defer. Non è dimostrato che gli stessi byte vengano riscaricati per ogni tag. | Conservare CSS critico, quick view e selettori. Non estrarre critical CSS né rimuovere regole in assenza di rendering/coverage reali. |
| P2 CLS / da verificare | Hero principale ha width/height e altezza desktop fissata. Le card hanno contenitori con rapporto, le tre icone hanno wrapper quadrato. Trustpilot nel custom Liquid non dichiara dimensioni intrinseche; countdown scaduto cambia il testo dopo parsing, app/font possono cambiare le misure. | Rischi distinti da un CLS misurato. La presenza del wrapper riduce già il rischio nelle icone. | Non inventare dimensioni originali Trustpilot. Mantenere layout/rapporti; verificare layout shift reali a viewport e consenso costanti. |

## Altri rilievi preesistenti, senza correzioni funzionali automatiche

- Theme Check 3.30.1 sull'originale: 83 segnalazioni. Tra queste: 3 errori del parser Liquid/HTML, 8 segnalazioni sugli schemi, 2 asset mancanti e un filtro sconosciuto. La lista grezza è in `theme-check-original.json`.
- Il filtro `collection.products | limit: products_to_show_limit` nella collezione non è un filtro Liquid Shopify documentato: la variabile 10 non garantisce il limite previsto. Cambiarlo in `slice` potrebbe diminuire il numero di prodotti attualmente mostrati. Non farlo silenziosamente per migliorare il punteggio; prima verificare il comportamento reale. Il lazy loading è indipendente da questa scelta.
- `assets/price-money.js` manca nel template gift card. È fuori dal percorso prioritario; non inventare un'implementazione per un flusso di pagamento.
- Il parser segnala chiusure label/span in `main-login` e `main-addresses`; in `js-variables` segnala il blocco script pur essendo presente un tag di chiusura. Distinguere i diagnostici del parser da errori runtime effettivamente riprodotti. Non riscrivere il polyfill o l'autenticazione nel contesto di un intervento prestazionale.
- Otto sezioni hanno la proprietà schema legacy `templates` segnalata dalla versione attuale del validatore. Non modificarle in massa per questa consegna: richiedono una verifica d'importazione Shopify e dell'editor.
- La strip Invektor codifica il link `https://petelishop.com` e non usa il campo link scelto nelle impostazioni. La destinazione differisce dal dominio dichiarato dall'utente. Segnalare per verifica editoriale, senza cambiare la navigazione senza una destinazione certa.
- Il countdown configurato scade il 10 ottobre 2026: il codice mostra già un messaggio alternativo dopo la scadenza. Non cambiare l'offerta o la data come ottimizzazione.

## Indicatori PageSpeed: interpretazione corretta

| Indicatore | Stato attuale | Obiettivo di riferimento e controllo |
|---|---|---|
| LCP | Non misurato qui. Candidato principale homepage: immagine della prima slide; video/poster/animazioni possono cambiare il candidato. PDP: media iniziale/selezionato. | Buono <=2,5 s al 75° percentile dei dati reali. In laboratorio estrarre esattamente elemento, URL, TTFB, ritardo di scoperta, download e render delay. |
| FCP | Non misurato; nessun valore dello screenshot adottato come certo. | Riferimento buono <=1,8 s. Verificare HTML iniziale, CSS bloccante, font e copertura di transizione. |
| TBT | Non misurato. La dimensione JS non basta a calcolarlo. | Riferimento Lighthouse mobile <=200 ms. Attribuire task >50 ms a file/app; TBT è di laboratorio, INP è la metrica di interazione dei Core Web Vitals reali. |
| CLS | Non misurato. | Buono <=0,1 al 75° percentile. Registrare shift di font, header, app, banner cookie, countdown e immagini. |

LCP/CLS/INP sono Core Web Vitals; FCP e TBT aiutano a diagnosticare ma non sono sostituti dei dati reali. Non attribuire a queste ottimizzazioni un aumento certo delle vendite o la differenza clic/landing-page-view delle campagne.

## Piano di esecuzione

1. Conservare originali immutati e hash, baseline Theme Check e inventario dei media. Preparare la diagnosi presente e comunicarla all'utente prima di scrivere nel tema.
2. Sulla sola copia locale correggere le priorità di download: immagini collezioni/PDP e icone categorie. Dimensioni e contenuti visualizzati rimangono gli stessi.
3. Dare precedenza all'immagine iniziale del banner mantenendo la seconda slide e le animazioni. Differire il video della sezione inferiore con template + inizializzazione nativa del tema.
4. Rendere non bloccante il foglio font e togliere la richiesta allo script slideshow assente di cui l'implementazione è già caricata. Nessuna rimozione di funzionalità per ottenere un punteggio.
5. Confrontare Theme Check prima/dopo; verificare JSON e schemi, parsing dei file cambiati, sintassi JS e dipendenze locali. Eseguire test browser locali mirati su gating video, viewport, immagini responsive e selezione iniziale della galleria. I test locali con dati simulati NON attestano funzionamento del negozio Shopify.
6. Preparare ZIP con le cartelle Shopify alla radice, diff, hash, inventario e checklist. Non incorporare il report nel tema come asset scaricabile dal cliente.
7. Importare come tema non pubblicato e confrontare homepage e i due prodotti con le stesse condizioni (tre run mobile a cache fredda, mediana, browser/CPU/rete identici). Prima della pubblicazione verificare tutti i percorsi commerciali e consenso/Meta. Servono il rendering Shopify e l'anteprima per un vero prima/dopo.

## Browser Instagram e Facebook

Ottimizzazioni valide senza riconoscere o discriminare user-agent: meno concorrenza iniziale, immagini responsive, lazy fuori schermo, `muted`/`playsinline`, gestione del rifiuto di autoplay, conservazione dei parametri URL e compatibilità ritorno dal checkout. Non rimuovere `fbclid`/UTM, non introdurre pixel o eventi, non aggirare il consenso, non modificare cart guard o bfcache per supposizione.

L'emulazione user-agent o del viewport non equivale al WebView Meta. Servono prove su iPhone/Android reali aprendo un annuncio Instagram/Facebook: primo accesso e ritorno, rete mobile, modalità risparmio energia, consenso accettato/rifiutato, apertura personalizzazioni, drawer, PayPal e ritorno dal checkout. Il video può essere impedito dall'OS anche con codice corretto; mantenere un'immagine visibile e verificare questa condizione.

## Media e interventi esterni allo ZIP

L'inventario CSV elencherà separatamente riferimenti configurati, URL scritti nel codice, media dinamici dei prodotti e file locali. Per i riferimenti `shopify://shop_images/...` il percorso CDN ricostruito è un candidato, non un URL verificato. Per `shopify://files/videos/...` non è possibile ricostruire il percorso di transcodifica del video dal solo nome.

Budget iniziali, da confermare visivamente: hero mobile 750–1080 px, 80–180 KB; desktop 1600–1920 px, 150–300 KB; foto PDP 750–1100 px mobile 80–180 KB e 1100–1500 px desktop 120–250 KB, zoom originale conservato; card 360–540 px mobile e 400–750 px desktop 30–80 KB; icone 220–330 px, 10–30 KB. Preferire formati negoziati Shopify WebP/AVIF quando supportati, senza forzare AVIF su browser vecchi. Non basta rinominare un PNG.

Video: MP4 H.264 per compatibilità, mantenendo rapporto e ritaglio; iniziare da 540–720 px di larghezza su mobile, 1280–1920 px desktop, 24–30 fps, mobile circa 0,6–1,2 Mbps (circa 0,75–1,5 MB ogni 10 secondi, più eventuale audio), desktop circa 1,5–3 Mbps. Sono budget, non misure dei file attuali. Verificare leggibilità quadranti e loghi; non modificare durata, ritmo, audio o autoplay del banner senza accordo. Gli originali vanno compressi e sostituiti dal pannello Shopify; non sono inclusi nell'export.
