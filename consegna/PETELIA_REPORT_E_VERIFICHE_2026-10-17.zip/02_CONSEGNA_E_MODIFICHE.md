# Petelia — copia del tema per test prestazioni

Data: 17 ottobre 2026. Tema di partenza: ZIP V8.7 fornito dall'utente; tema Be Yours personalizzato. Destinazione: importazione come **nuovo tema non pubblicato** nello stesso negozio. Nessun tema è stato caricato, modificato o pubblicato su Shopify da questa sessione.

## Risultato e limiti

Preparata una copia locale con dieci file modificati. Gli interventi riducono la concorrenza delle risorse al primo caricamento, conservando contenuti, layout, video, personalizzazioni e integrazioni. Non sono state eliminate funzionalità né modificate offerte, prodotti o preferenze delle app.

La diagnosi prioritaria è stata consegnata in chat prima di modificare il codice ed è conservata in `01_DIAGNOSI_E_PIANO.md`. Il diff completo è `MODIFICHE.diff`. I file del tema sono separati dalla documentazione: nello ZIP da importare sono presenti soltanto le cartelle Shopify alla radice.

**Non è stato misurato un miglioramento PageSpeed del negozio.** Il proxy dell'ambiente rifiuta le richieste verso peteliashop.com e Shopify CDN. Il controllo finale dello stato dell'ambiente conferma policy applicata senza questi domini. Le aggiunte sono salvate nella bozza dell'ambiente, non applicate. Non sono stati eseguiti Lighthouse/PageSpeed sul prima/dopo, test reali di checkout o prove nei WebView Instagram/Facebook. Il tema modificato non dispone ancora di un URL Shopify di anteprima.

Il punteggio storico circa 64/100 resta un riferimento del brief/screenshot, non una nuova misura; il valore LCP ipotizzato di circa 21 s non è confermato. Non viene dichiarato un aumento delle conversioni.

## Modifiche file per file

| File | Modifica | Motivo e rischio residuo |
|---|---|---|
| `sections/countdown-timer.liquid` | Il secondo media attende l'evento load/error dell'immagine iniziale; gestiti immagine già in cache, cambio breakpoint e pulizia degli eventi nell'editor. Il foglio Google Fonts diventa non bloccante con fallback noscript. | L'immagine hero mantiene picture/srcset/sizes, eager e priorità alta. La rotazione viene attivata dopo che la prima immagine termina il caricamento; il ciclo CSS rimane 12 s e il video resta mobile/autoplay/muted/playsinline come configurato. Su rete lenta il fermo iniziale può durare di più: verificare la transizione sul negozio. Il font può comparire dopo il primo paint, come già previsto da display=swap; controllare CLS. |
| `sections/featured-collection.liquid` | Passato esplicitamente lazy_load alle card in entrambe le righe. Se la sezione viene usata in prima posizione, le prime due card di ogni riga rimangono eager. | Homepage: foto fuori schermo non obbligate tutte all'avvio. Numero prodotti, ordine, layout a due righe, seconda immagine, quick buy e quick view invariati. Il lazy nativo può anticipare risorse vicine; controllare uno scorrimento veloce. Il filtro legacy limit rimane invariato per non cambiare il catalogo mostrato. |
| `sections/main-product.liquid` | Aggiunti parametri di caricamento alle chiamate della galleria: iniziale/selezionata eager, altre lazy, priorità alta al media iniziale. | Conservate selezioni variante e gruppi media. Tutto il codice dopo il primo elenco della galleria è identico all'originale, incluse le personalizzazioni. Verificare prima foto, varianti e galleria stacked/slider in Shopify. |
| `snippets/product-image.liquid` | Parametro high_priority, reso come fetchpriority high/auto nelle immagini e poster. | Non viene cambiato il comportamento predefinito delle altre chiamate allo snippet; la politica esplicita arriva dalla galleria principale. Tag e immagini zoom invariati. |
| `sections/rich-text.liquid` | Le tre icone categoria usano URL CDN con width 110/220/330, sizes 110px, lazy, decoding async e dimensioni 110×110. | Stesse immagini e ritagli CSS; niente download obbligatorio degli originali a piena risoluzione per icone piccole. I 110×110 descrivono il box esistente, non le dimensioni reali dei file remoti. Verificare nitidezza e CDN nella preview. |
| `sections/video-hero.liquid` | Il video Shopify inferiore è in un template inerte, con preload none e avvio demandato al componente del tema. Il fallback noscript conserva il video senza JavaScript. | Nessun download video imposto al parsing in una sezione molto sotto lo schermo. Il componente originale lo attiva entro il margine esistente di 600px. Restano immutati sorgente, poster, loop, audio e testo. Verificare scorrimento rapido e low power iOS. |
| `assets/global.js` | Solo sei righe in initMp4Video per materializzare il template marcato prima di chiamare il player già esistente. | Nessuna riscrittura di altre classi, eventi, pixel, cart guard, varianti o navigazione. Gli altri video e i player YouTube/Vimeo seguono il codice precedente. |
| `sections/slideshow.liquid` | Rimosso il riferimento a component-slideshow.js, inesistente nello ZIP. | La classe SlideshowComponent resta implementata e registrata in global.js. Si elimina la richiesta mancante; non viene rimosso il carosello. Da provare anche Safari e l'editor Shopify. |
| `sections/image-with-text-overlay.liquid` | Lazy/decoding async e dimensioni intrinseche al GIF decorativo Pacco Regalo. | Stesso GIF animato e stesso box CSS di 2em; nessuna conversione in immagine statica. |
| `sections/header.liquid` | Rimossa una sola virgola finale nell'array JSON dello schema. | Correzione sintattica preesistente emersa nella validazione: contenuto dello schema, markup, CSS e JavaScript invariati. |

Gli originali dei media remoti **non sono stati ricompressi o sostituiti**: non sono inclusi nello ZIP e non sono accessibili con la policy corrente. L'ottimizzazione delle tre icone riguarda le varianti CDN richieste dal browser. L'inventario contiene budget per gli altri interventi manuali.

## Verifiche eseguite

| Verifica | Esito |
|---|---|
| Originali confrontati byte per byte con lo ZIP caricato | Passata, 347 file conservati |
| File aggiunti/eliminati nel tema | Nessuno; 10 file cambiati |
| JSON standalone | 57/57 letti correttamente |
| JSON degli schemi incorporati nelle sezioni | 75/75 letti correttamente dopo la correzione della virgola header |
| Parser Shopify Liquid/HTML 2.10.2, modalità strict, file Liquid modificati | 9/9 passati |
| Sintassi Node.js degli asset JavaScript | 44/44 passati |
| Theme Check 3.30.1 | 83 segnalazioni originali → 79 nella copia; nessun nuovo errore. Non è un controllo integralmente verde: restano diagnostici preesistenti. |
| Test componenti in Chromium 154.0.8037.57 | 16/16 passati, nessuno saltato; media e oggetti Shopify sintetici, non storefront reale |
| Nuovi riferimenti ad asset locali mancanti nei file modificati | Nessuno |
| Hash di configurazioni, template, layout, traduzioni | Tutti invariati |
| Codice carrello, incisioni, NFC, extra, guard e consenso selezionato per confronto | Invariato byte per byte; elenco e SHA-256 in validation.json |
| Importazione effettiva Shopify, rendering di tutti i template, servizi app | Non eseguiti: richiedono l'anteprima Shopify |
| PageSpeed/Lighthouse, CrUX e confronto reale LCP/FCP/TBT/CLS | Non eseguiti: rete bloccata e preview non disponibile |
| Meta Pixel Helper, Conversions API, checkout/PayPal e browser in-app reali | Non eseguiti; nessuna modifica a tali integrazioni |

Le prove Chromium hanno verificato il codice effettivo dei componenti con filtri Shopify simulati per generare URL locali: immagine hero prioritaria, video secondario assente fino a load/error, video mobile non creato sul desktop e corretto cambio breakpoint, pulizia su unload, video inferiore assente finché fuori schermo e riproduzione all'avvicinamento, fallback senza JS, galleria con e senza media della variante e con show_featured_media, card/icone responsive.

Confronti su questi campioni sintetici: 3 foto PDP eager diventano 1 iniziale eager + 2 lazy; 10 card con foto secondarie passano da 20 immagini eager a 20 immagini lazy quando sotto l'hero; il video inferiore passa da presente nel DOM al parsing a inserito dall'osservatore. Sono verifiche di comportamento, **non tempi o conteggi del negozio reale**. I filtri simulati non validano la risposta Shopify CDN.

## Diagnostici residui da conoscere

Restano tre segnalazioni LiquidHTMLSyntaxError nei file originali main-addresses, main-login e js-variables; otto ValidSchema sulla proprietà legacy templates; quattordici ValidSchemaTranslations; un asset price-money.js mancante nel template gift card; il filtro limit non documentato della collezione; sette ImgWidthAndHeight in contenuti preesistenti. Altre segnalazioni riguardano naming, preload, assegnazioni e complessità.

L'avviso RemoteAsset aggiuntivo si riferisce alla copia del link Google Fonts nel fallback noscript. L'avviso di complessità già presente su main-product aggiorna valore e riga per le condizioni di caricamento aggiunte; non cambia il numero di avvisi di quella categoria. Non sono stati disabilitati controlli per nascondere risultati. Gli schemi sono JSON valido, ma le proprietà legacy devono ancora essere accettate dall'editor Shopify: **l'importazione non è certificata da una prova reale**. Se Shopify la rifiuta, conservare l'errore esatto e correggere quel requisito nella copia; non pubblicare la copia prima del collaudo.

## Come usare la consegna

1. Conservare il tema attuale e il suo ZIP come rollback.
2. Shopify → Negozio online → Temi → Aggiungi tema / Carica file ZIP. Selezionare esclusivamente `PETELIA_V8_7_PERFORMANCE_TEST_2026-10-17.zip`, non lo ZIP della documentazione.
3. Nominare la copia, per esempio “Petelia V8.7 — Test prestazioni”. Mantenerla non pubblicata e aprirne l'anteprima.
4. Seguire `03_CHECKLIST_PRIMA_DELLA_PUBBLICAZIONE.md`, mantenendo la preview attiva anche quando si aprono i prodotti. Verificare che Mare Nostrum e Silva Viridis usino il template atteso.
5. Misurare prima/dopo e collaudare i flussi sul negozio. Pubblicare soltanto dopo esito positivo; la pubblicazione è una decisione del proprietario del negozio.

Per consentire misure in questa sessione sono state salvate nella bozza di rete le aggiunte peteliashop.com, www.peteliashop.com, cdn.shopify.com, fonts.shopifycdn.com, www.googleapis.com, fonts.googleapis.com, fonts.gstatic.com e cdnjs.cloudflare.com. Servono applicazione nelle impostazioni dell'ambiente e nuova verifica di accesso; il salvataggio della bozza non ha aperto la rete. Per una sessione browser completa potrebbero servire ulteriori destinazioni app, da ricavare dall'HTML reale senza disattivare integrazioni.

## Riproducibilità

Documentazione tecnica: diff, inventario CSV/JSON, output Theme Check originale/copia, risultati parser e browser, validation.json con hash di tutti i file, script di modifica/verifica e package-lock degli strumenti. I percorsi /workspace nei risultati sono percorsi della sessione. Per rieseguire gli strumenti in un altro ambiente, usare una directory equivalente o aggiornare il prefisso negli script. `optimize.py` richiede una nuova copia dell'originale; non è progettato per essere riapplicato su file già modificati.

Il test video è un MP4 sintetico nero di un secondo, generato per i test: non è un video Petelia e non è incluso nel tema. Il codice dei test è consegnato come evidenza tecnica; non è un test automatico di Shopify o dei sistemi di pagamento.
