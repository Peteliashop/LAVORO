from pathlib import Path
import collections, hashlib, json, re, subprocess, zipfile

base=Path('/workspace/petelia')
original=base/'original'
optimized=base/'optimized'
report={}
sha=lambda data:hashlib.sha256(data).hexdigest()
inputs=Path('/workspace/attachments/b4d424ca-f580-4c46-9ded-025e9e2b4ff5/theme_export_peteliashop_com_copia_di_copia_di_petelia_tema_v8_7.zip')
with zipfile.ZipFile(inputs) as z:
    assert all((original/i.filename).read_bytes()==z.read(i) for i in z.infolist() if not i.is_dir())
report['original_matches_uploaded_zip']=True
files={str(p.relative_to(original)) for p in original.rglob('*') if p.is_file()}
assert files=={str(p.relative_to(optimized)) for p in optimized.rglob('*') if p.is_file()}
changed=sorted(name for name in files if (original/name).read_bytes()!=(optimized/name).read_bytes())
assert len(changed)==10,changed
report['changed_files']=changed
assert all((original/name).read_bytes()==(optimized/name).read_bytes() for name in files if name.startswith(('config/','templates/','locales/','layout/')))
report['all_config_templates_locales_layout_byte_identical']=True
protected=['assets/product-form.js','assets/petelia-cart-guard.js','assets/petelia-cart-notes.js','sections/mini-cart.liquid','sections/main-cart-items.liquid',
           'sections/cart-notification-product.liquid','sections/main-order.liquid','snippets/petelia-gift-options.liquid','snippets/petelia-cart-summary.liquid',
           'snippets/meta-tags.liquid','sections/cookie-banner.liquid','assets/cookie-banner-custom.js']
report['unchanged_commercial_and_consent_files']={name:sha((optimized/name).read_bytes()) for name in protected}
for name in protected:assert (original/name).read_bytes()==(optimized/name).read_bytes()
assert (original/'sections/main-product.liquid').read_bytes().split(b'</ul>',1)[1]==(optimized/'sections/main-product.liquid').read_bytes().split(b'</ul>',1)[1]
report['main_product_below_first_gallery_unchanged']=True
js=list((optimized/'assets').glob('*.js'))
failures=[]
for p in js:
    r=subprocess.run(['node','--check',str(p)],capture_output=True,text=True)
    if r.returncode:failures.append({'file':p.name,'error':r.stderr})
report['javascript']={'files_checked':len(js),'failures':failures}
assert not failures,failures
json_files=list(optimized.rglob('*.json'))
for p in json_files:json.loads(p.read_text())
schemas=[]
for p in optimized.rglob('*.liquid'):
    for content in re.findall(r'{%-?\s*schema\s*-?%}([\s\S]*?){%-?\s*endschema\s*-?%}',p.read_text()):
        json.loads(content);schemas.append(str(p.relative_to(optimized)))
report['json_parsed']=len(json_files)
report['embedded_schema_json_parsed']=len(schemas)
checks={name:json.loads((base/'reports'/f'theme-check-{name}.json').read_text()) for name in ['original','optimized']}
def diag(o):return (o['uri'].split('/'+('optimized' if '/optimized/' in o['uri'] else 'original')+'/')[1],o['check'],o['message'],o['severity'])
before=collections.Counter(diag(o) for o in checks['original'])
after=collections.Counter(diag(o) for o in checks['optimized'])
new=list((after-before).elements())
report['theme_check']={'version':'3.30.1','before':len(checks['original']),'after':len(checks['optimized']),'new_diagnostics':new,
                      'remaining_errors':[diag(o) for o in checks['optimized'] if o['severity']==0]}
assert not [o for o in new if o[3]==0],new
report['new_literal_asset_references_missing']=[]
for name in changed:
    for asset in re.findall(r'''['"]([^'"\n]+)['"]\s*\|\s*asset_url''',(optimized/name).read_text()):
        if not (optimized/'assets'/asset).is_file():report['new_literal_asset_references_missing'].append((name,asset))
assert not report['new_literal_asset_references_missing']
report['file_manifest']={name:{'original_sha256':sha((original/name).read_bytes()),'optimized_sha256':sha((optimized/name).read_bytes())} for name in sorted(files)}
(base/'reports'/'validation.json').write_text(json.dumps(report,ensure_ascii=False,indent=2))
print(json.dumps({k:v for k,v in report.items() if k not in ['file_manifest','theme_check','unchanged_commercial_and_consent_files']},ensure_ascii=False,indent=2))
print('Theme Check before/after:',report['theme_check']['before'],report['theme_check']['after'],'New errors: 0')
