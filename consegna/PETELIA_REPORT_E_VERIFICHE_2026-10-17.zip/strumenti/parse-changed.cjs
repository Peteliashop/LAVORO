const fs=require('node:fs');
const {toLiquidHtmlAST}=require('@shopify/liquid-html-parser');
const root='/workspace/petelia/';
const files=['sections/countdown-timer.liquid','sections/featured-collection.liquid','sections/main-product.liquid',
  'snippets/product-image.liquid','sections/rich-text.liquid','sections/video-hero.liquid',
  'sections/slideshow.liquid','sections/image-with-text-overlay.liquid','sections/header.liquid'];
const results=[];
for(const file of files){
  try{toLiquidHtmlAST(fs.readFileSync(root+'optimized/'+file,'utf8'),{mode:'strict'});results.push({file,status:'passed'});}
  catch(e){results.push({file,status:'failed',message:e.message});}
}
fs.writeFileSync(root+'reports/liquid-parser.json',JSON.stringify({parser:'@shopify/liquid-html-parser 2.10.2',mode:'strict',results},null,2));
console.log(JSON.stringify(results,null,2));
process.exitCode=results.some(r=>r.status==='failed')?1:0;
