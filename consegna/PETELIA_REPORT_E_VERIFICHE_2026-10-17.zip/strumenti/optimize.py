from pathlib import Path

root = Path('/workspace/petelia/optimized')

def edit(name, transform):
    p = root / name
    raw = p.read_bytes()
    crlf = b'\r\n' in raw
    old = raw.decode().replace('\r\n', '\n')
    new = transform(old)
    assert old != new, name
    p.write_bytes(new.replace('\n', '\r\n').encode() if crlf else new.encode())

def hero(s):
    s = s.replace('<link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@500;700&display=swap" rel="stylesheet">', '''{% comment %}Keep the same font without blocking the hero image's first paint.{% endcomment %}
<link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@500;700&display=swap" rel="stylesheet" media="print" onload="this.media='all'">
<noscript><link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@500;700&display=swap" rel="stylesheet"></noscript>''', 1)
    s = s.replace("    const mediaQuery = window.matchMedia('(min-width: 769px)');", """    const mediaQuery = window.matchMedia('(min-width: 769px)');
    const primaryImage = hero.querySelector('.slide-1 img');
    let primarySettled = !primaryImage || primaryImage.complete;""", 1)
    s = s.replace('    function configureMedia() {\n', '''    function configureMedia() {
      // Preserve the first slide while its image owns the initial connection.
      if (!primarySettled) return;
''', 1)
    s = s.replace('    function visibilityChanged() {', '''    function primaryMediaSettled() {
      primarySettled = true;
      configureMedia();
    }
    function visibilityChanged() {''', 1)
    s = s.replace('      clearInterval(countdownInterval);\n      stopVideo();', '''      clearInterval(countdownInterval);
      if (primaryImage) {
        primaryImage.removeEventListener('load', primaryMediaSettled);
        primaryImage.removeEventListener('error', primaryMediaSettled);
      }
      stopVideo();''', 1)
    s = s.replace('    configureMedia();\n    if (updateCountdown())', '''    if (!primarySettled) {
      primaryImage.addEventListener('load', primaryMediaSettled, { once: true });
      primaryImage.addEventListener('error', primaryMediaSettled, { once: true });
    }
    configureMedia();
    if (updateCountdown())''', 1)
    return s

edit('sections/countdown-timer.liquid', hero)

def collection(s):
    for loop in ['{%- for product in products limit: half -%}', '{%- for product in products offset: half -%}']:
        assert s.count(loop) == 1
        s = s.replace(loop, loop + '''
            {%- liquid
              assign card_lazy_load = true
              if section.index == 1 and forloop.index <= 2
                assign card_lazy_load = false
              endif
            -%}''', 1)
    old = '                enable_image_fill: section.settings.enable_image_fill\n'
    assert s.count(old) == 2
    return s.replace(old, '                enable_image_fill: section.settings.enable_image_fill,\n                lazy_load: card_lazy_load\n')

edit('sections/featured-collection.liquid', collection)

def product(s):
    old = 'mobile_image_ratio: mobile_image_ratio, lazy_load: false %}'
    assert s.count(old) == 1
    s = s.replace(old, 'mobile_image_ratio: mobile_image_ratio, lazy_load: false, high_priority: true %}', 1)
    old = "                  {% render 'product-image', media: media,"
    assert s.count(old) == 1
    s = s.replace(old, '''                  {%- liquid
                    assign media_lazy_load = true
                    assign media_high_priority = false
                    if media_active or media.id == first_image.id
                      assign media_lazy_load = false
                    endif
                    if featured_media == null and media.id == first_image.id
                      assign media_high_priority = true
                    endif
                  -%}
                  {% render 'product-image', media: media,''', 1)
    old = 'media: media, position: forloop.index, zoom: section.settings.enable_image_zoom, loop: section.settings.enable_video_looping, modal_id: section.id, xr_button: true, media_width: media_width, image_ratio: image_ratio, mobile_image_ratio: mobile_image_ratio %}'
    assert s.count(old) == 1
    return s.replace(old, old[:-3] + ', lazy_load: media_lazy_load, high_priority: media_high_priority %}', 1)

edit('sections/main-product.liquid', product)

def product_image(s):
    s = s.replace('  - lazy_load: {Boolean} Image should be lazy loaded. Default: true (optional)', '  - lazy_load: {Boolean} Explicit loading policy supplied by the gallery (optional)\n  - high_priority: {Boolean} Prioritize the initial visible product media (optional)', 1)
    s = s.replace("  assign image_loading = 'eager'", """  assign image_fetchpriority = 'auto'
  if high_priority
    assign image_fetchpriority = 'high'
  endif
  assign image_loading = 'eager'""", 1)
    assert s.count('loading: image_loading,') == 4
    return s.replace('loading: image_loading,', 'loading: image_loading,\n        fetchpriority: image_fetchpriority,')

edit('snippets/product-image.liquid', product_image)

def rich_text(s):
    import re
    def image(m):
        url = m[1]
        return f'<img src="{url}&amp;width=220" srcset="{url}&amp;width=110 110w, {url}&amp;width=220 220w, {url}&amp;width=330 330w" sizes="110px" width="110" height="110" loading="lazy" decoding="async"'
    new, count = re.subn(r'<img src="(https://cdn\.shopify\.com/[^"\n]+)"', image, s)
    assert count == 3
    return new

edit('sections/rich-text.liquid', rich_text)

def video_hero(s):
    start = s.index('                  {{ section.settings.video | video_tag:')
    end = s.index('                </video-section>', start)
    original = s[start:end]
    deferred = original.replace('autoplay: true,', 'autoplay: false,\n                    preload: \'none\',')
    return s[:start] + '                  <template data-petelia-video>\n' + deferred + '                  </template>\n                  <noscript>\n' + original + '                  </noscript>\n' + s[end:]

edit('sections/video-hero.liquid', video_hero)

def global_js(s):
    old = '  initMp4Video() {\n    const player = this.querySelector(\'video\');'
    new = '''  initMp4Video() {
    // The background video stays inert until the existing visibility observer fires.
    const template = this.querySelector('template[data-petelia-video]');
    if (template) {
      this.appendChild(template.content.cloneNode(true));
      template.remove();
    }
    const player = this.querySelector('video');'''
    assert s.count(old) == 1
    return s.replace(old, new, 1)

edit('assets/global.js', global_js)

def slideshow(s):
    old = '''{% comment %} Hack to deal with Safari {% endcomment %}
{% if section.blocks.size > 1 %}
  <script src="{{ 'component-slideshow.js' | asset_url }}" defer="defer"></script>
{% endif %}'''
    assert s.count(old) == 1
    return s.replace(old, "{% comment %}SlideshowComponent is already registered by global.js, including Safari support.{% endcomment %}", 1)

edit('sections/slideshow.liquid', slideshow)

def gift_gif(s):
    old = 'alt="Pacco Regalo" style="height: 2em; width: 2em;'
    assert s.count(old) == 1
    return s.replace(old, 'alt="Pacco Regalo" loading="lazy" decoding="async" width="32" height="32" style="height: 2em; width: 2em;', 1)

edit('sections/image-with-text-overlay.liquid', gift_gif)

def header_schema(s):
    old = '          "unit": "t:sections.all.colors.overlay_opacity.unit"\n        },\n      ]'
    assert s.count(old) == 1
    return s.replace(old, '          "unit": "t:sections.all.colors.overlay_opacity.unit"\n        }\n      ]', 1)

edit('sections/header.liquid', header_schema)
print('Optimized 10 files; original remains unchanged.')
