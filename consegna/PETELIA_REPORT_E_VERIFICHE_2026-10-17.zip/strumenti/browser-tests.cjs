// Offline component checks using actual theme markup/JS and synthetic Shopify data.
// These are not a Shopify preview, Lighthouse, a Meta WebView or a checkout test.
const fs = require('node:fs');
const path = require('node:path');
const http = require('node:http');
const assert = require('node:assert/strict');
const {Liquid} = require('liquidjs');
const {chromium} = require('playwright-core');
const base = '/workspace/petelia';
const results = [];
const records = new Map();
const esc = s => String(s ?? '').replaceAll('&', '&amp;').replaceAll('"','&quot;');
function clean(s) {
  return s.replace(/{%-?\s*schema\s*-?%}[\s\S]*?{%-?\s*endschema\s*-?%}/g,'')
    .replace(/{%-?\s*style\s*-?%}/g,'<style>').replace(/{%-?\s*endstyle\s*-?%}/g,'</style>');
}
function hash(args) {return Object.fromEntries(args.filter(a => Array.isArray(a)));}
function engine(version) {
  const e = new Liquid({root:path.join(base,version,'snippets'),extname:'.liquid',strictFilters:false});
  e.registerFilter('image_url', (image, ...args) => {
    const h = hash(args); return `/image/${image?.id || 'mock'}.svg?width=${h.width || image?.width || 900}`;
  });
  e.registerFilter('image_tag', (url,...args) => {
    const h=hash(args); const width=Number(new URL(url,'http://local').searchParams.get('width')) || 900;
    const attrs={src:url,width,height:width,...h}; delete attrs.widths;
    if(h.widths) attrs.srcset=h.widths.split(',').map(w=>`${url.replace(/width=\d+/,`width=${w.trim()}`)} ${w.trim()}w`).join(', ');
    return '<img '+Object.entries(attrs).filter(([,v])=>v!==undefined).map(([k,v])=>`${k}="${esc(v)}"`).join(' ')+'>';
  });
  e.registerFilter('video_tag',(video,...args)=>{
    const h=hash(args);
    const attrs={src:'/media/video.mp4',poster:'/image/poster.svg',playsinline:true,...h};
    delete attrs.image_size;
    return '<video '+Object.entries(attrs).filter(([,v])=>v!==false&&v!==null).map(([k,v])=>v===true?k:`${k}="${esc(v)}"`).join(' ')+'></video>';
  });
  e.registerFilter('asset_url',x=>`/asset/${version}/${x}`);
  e.registerFilter('stylesheet_tag',url=>`<link rel="stylesheet" href="${url}">`);
  e.registerFilter('t',x=>x);
  e.registerFilter('money',x=>`€${Number(x||0)/100}`);
  e.registerFilter('money_with_currency',x=>`€${Number(x||0)/100} EUR`);
  return e;
}
const img = id => ({id,alt:id,width:900,height:900,aspect_ratio:1,src:`/image/${id}.svg`});
const media = id => ({...img(id),media_type:'image',preview_image:img(id),position:Number(id.replace(/\D/g,''))||1});
function sectionSettings(version,file, overrides={}) {
  const source=fs.readFileSync(`${base}/${version}/sections/${file}.liquid`,'utf8');
  const schema=JSON.parse(source.match(/{%\s*schema\s*%}([\s\S]*?){%\s*endschema\s*%}/)[1]);
  return Object.assign(Object.fromEntries(schema.settings.filter(x=>x.id&&x.default!==undefined).map(x=>[x.id,x.default])), overrides);
}
const cssColor={red:0,green:0,blue:0};
async function fixture(version, type, params) {
  const e=engine(version);
  const source=file=>clean(fs.readFileSync(`${base}/${version}/${file}`,'utf8'));
  let body, global=false;
  if (type==='hero') {
    const settings=sectionSettings(version,'countdown-timer',{
      banner_image:img('hero'),banner_image_desktop:img('desktop'),banner_video:{id:'video'},
      video_display:params.get('mode')||'mobile',countdown_expiry:'2030-10-10T23:59:59',
      banner_image_2:params.has('secondary')?img('secondary'):null
    });
    body=await e.parseAndRender(source('sections/countdown-timer.liquid'),{section:{id:'fixture',settings}});
  } else if (type==='lower') {
    global=true;
    const settings=sectionSettings(version,'video-hero',{
      video:{aspect_ratio:1,id:'video'},video_url:'',image_ratio:'400px',mobile_image_ratio:'400px',
      colors_overlay:cssColor,colors_text:cssColor,colors_button_background:cssColor,colors_button_label:cssColor
    });
    body='<div style="height:5000px"></div>'+await e.parseAndRender(source('sections/video-hero.liquid'),{section:{id:'fixture',settings,blocks:[]}});
  } else if(type==='gallery') {
    const main=fs.readFileSync(`${base}/${version}/sections/main-product.liquid`,'utf8');
    const assign=main.match(/{%- liquid\s+assign first_image = product.media.first[\s\S]*?-%}/)[0];
    const ul=main.slice(main.indexOf('<ul id="Slider-Gallery-'),main.indexOf('</ul>')+5);
    const product={id:1,title:'Synthetic product',media:[media('p1'),media('p2'),media('p3')],images:[],options_with_values:[],selected_or_first_available_variant:{}};
    if(params.has('variant')) product.selected_or_first_available_variant.featured_media=product.media[1];
    const settings=sectionSettings(version,'main-product',{
      show_featured_media:params.has('showFeatured'),enable_image_zoom:false,
      hide_variants:true,media_size:'medium',gallery_layout:'thumbnail_slider',image_ratio:'adapt',mobile_image_ratio:'square'
    });
    body=await e.parseAndRender(assign+ul,{product,section:{id:'fixture',settings},settings:{page_width:1000}});
  } else if(type==='collection') {
    const products=Array.from({length:10},(_,i)=>({id:i+1,title:`Product ${i+1}`,url:`/products/p${i+1}`,available:true,
      featured_media:media('c'+(i+1)),media:[media('c'+(i+1)),media('second'+(i+1))],images:[],options:[],options_with_values:[],metafields:{},price:10000,has_only_default_variant:true}));
    const settings=sectionSettings(version,'featured-collection',{
      collection:{products,all_products_count:10},heading_tag:'h2',enable_double_row:true,
      show_quick_buy:false,enable_quick_view:false,enable_color_swatches:false,enable_countdown:false,
      show_secondary_image:true,show_rating:false,image_ratio:'square'
    });
    body=await e.parseAndRender(source('sections/featured-collection.liquid'),{
      section:{id:'fixture',index:Number(params.get('index')||4),settings},settings:{page_width:1000,color_swatches_enabled:false}
    });
  } else if(type==='icons') {
    body=await e.parseAndRender(source('sections/rich-text.liquid'),{section:{id:'fixture',settings:{full_width:true}}});
    body=body.replaceAll('https://cdn.shopify.com/s/files/1/0818/9847/1758/files/','/image/');
  }
  const setup=`<script>window.theme={settings:{themeName:'Be Yours',themeVersion:'fixture'},shopSettings:{moneyFormat:'{{amount}}',isoCode:'EUR'},routes:{}};</script>`;
  const script=global?setup+`<script src="/asset/${version}/global.js" defer></script>`:'';
  return '<!doctype html><html><head><meta name="viewport" content="width=device-width,initial-scale=1"><style>body{margin:0} video-section{display:block;height:400px} video{width:100%;height:400px} .media{position:relative} .no-js-hidden{display:block}</style>'+script+'</head><body><div id="shopify-section-fixture">'+body+'</div></body></html>';
}
const server=http.createServer(async(req,res)=>{
  try{
    const url=new URL(req.url,'http://local');
    const id=url.searchParams.get('test')||'';
    if(!records.has(id)) records.set(id,[]);
    records.get(id).push({url:url.pathname+url.search,timestamp:Date.now()});
    if(url.pathname==='/fixture'){
      res.setHeader('Content-Type','text/html');res.end(await fixture(url.searchParams.get('version'),url.searchParams.get('type'),url.searchParams));
    } else if(url.pathname.startsWith('/asset/')){
      const [, ,version,file]=url.pathname.split('/');
      assert(['original','optimized'].includes(version));assert(!file.includes('..'));
      res.setHeader('Content-Type',file.endsWith('.js')?'text/javascript':'text/css');res.end(fs.readFileSync(`${base}/${version}/assets/${file}`));
    } else if(url.pathname==='/media/video.mp4'){
      res.setHeader('Content-Type','video/mp4');res.end(fs.readFileSync(__dirname+'/test-video.mp4'));
    } else if(url.pathname.startsWith('/image/')){
      if(url.pathname.includes('hero.svg')&&!url.pathname.includes('desktop'))await new Promise(r=>setTimeout(r,1200));
      res.setHeader('Content-Type','image/svg+xml');res.end('<svg xmlns="http://www.w3.org/2000/svg" width="900" height="900"><rect width="900" height="900" fill="#b39b79"/></svg>');
    }else{res.statusCode=404;res.end();}
  }catch(e){res.statusCode=500;res.end(String(e));}
});
(async()=>{
  await new Promise(r=>server.listen(0,'127.0.0.1',r));
  const origin=`http://127.0.0.1:${server.address().port}`;
  const browser=await chromium.launch({executablePath:'/usr/bin/chromium',headless:true,args:['--no-sandbox']});
  async function test(name,fn){
    try{await fn();results.push({name,status:'passed'});console.log('PASS',name);}
    catch(e){results.push({name,status:'failed',error:String(e.stack)});console.error('FAIL',name,e.message);}
  }
  async function pageFor(version,type,params='',viewport={width:390,height:844},javaScriptEnabled=true){
    const page=await browser.newPage({viewport,javaScriptEnabled});
    page.fixtureErrors=[];
    page.on('pageerror',e=>page.fixtureErrors.push(e.message));
    await page.route('https://**/*',r=>r.fulfill({status:200,body:'',contentType:'text/css'}));
    await page.goto(`${origin}/fixture?version=${version}&type=${type}&${params}`,{waitUntil:'domcontentloaded'});
    return page;
  }
  for(const version of ['original','optimized']){
    await test(`${version}: mobile hero resource ordering`,async()=>{
      const p=await pageFor(version,'hero');
      try{
        assert.equal(await p.locator('.slide-1 img').getAttribute('loading'),'eager');
        assert.equal(await p.locator('.slide-1 img').getAttribute('fetchpriority'),'high');
        assert.equal(await p.locator('[data-secondary-slot] video').count(),version==='original'?1:0);
        assert.equal(await p.locator('[data-petelia-hero]').getAttribute('data-second-active'),version==='original'?'true':'false');
        await p.waitForFunction(()=>document.querySelector('.slide-1 img').complete);
        await p.waitForFunction(()=>!!document.querySelector('[data-secondary-slot] video'));
        assert.equal(await p.locator('[data-secondary-slot] video').evaluate(v=>v.muted&&v.playsInline&&v.loop),true);
        assert.deepEqual(p.fixtureErrors,[]);
      }finally{await p.close();}
    });
    await test(`${version}: offscreen video activation`,async()=>{
      const p=await pageFor(version,'lower');
      try{
        await p.waitForFunction(()=>!!customElements.get('video-section'));
        assert.equal(await p.locator('video-section > video').count(),version==='original'?1:0);
        await p.locator('video-section').scrollIntoViewIfNeeded();
        await p.waitForFunction(()=>!!document.querySelector('video-section > video'));
        await p.waitForFunction(()=>!document.querySelector('video-section > video').paused);
        assert.equal(await p.locator('video-section > video').evaluate(v=>v.muted&&v.playsInline&&v.loop),true);
        assert.deepEqual(p.fixtureErrors,[]);
      }finally{await p.close();}
    });
  }
  await test('optimized: desktop does not create mobile-only hero video; resize activates it',async()=>{
    const p=await pageFor('optimized','hero','',{width:1440,height:900});
    try{
      await p.waitForFunction(()=>document.querySelector('.slide-1 img').complete);
      assert.equal(await p.locator('[data-secondary-slot] video').count(),0);
      const current=await p.locator('.slide-1 img').evaluate(i=>i.currentSrc);
      assert(current.includes('desktop.svg'));
      await p.setViewportSize({width:390,height:844});
      await p.waitForFunction(()=>!!document.querySelector('[data-secondary-slot] video'));
      await p.setViewportSize({width:1440,height:900});
      await p.waitForFunction(()=>!document.querySelector('[data-secondary-slot] video'));
      assert.deepEqual(p.fixtureErrors,[]);
    }finally{await p.close();}
  });
  await test('optimized: primary image error releases secondary media',async()=>{
    const p=await browser.newPage({viewport:{width:390,height:844}});
    await p.route('**/image/hero.svg*',r=>r.fulfill({status:404,body:''}));
    await p.route('https://**/*',r=>r.fulfill({body:'',contentType:'text/css'}));
    try{
      await p.goto(`${origin}/fixture?version=optimized&type=hero`,{waitUntil:'domcontentloaded'});
      await p.waitForFunction(()=>!!document.querySelector('[data-secondary-slot] video'));
    }finally{await p.close();}
  });
  await test('optimized: section unload removes pending primary image handlers',async()=>{
    const p=await pageFor('optimized','hero');
    try{
      await p.evaluate(()=>document.getElementById('shopify-section-fixture').dispatchEvent(new CustomEvent('shopify:section:unload',{bubbles:true})));
      await p.waitForFunction(()=>document.querySelector('.slide-1 img').complete);
      assert.equal(await p.locator('[data-secondary-slot] video').count(),0);
    }finally{await p.close();}
  });
  await test('optimized: background video fallback without JavaScript',async()=>{
    const p=await pageFor('optimized','lower','',{width:390,height:844},false);
    try{assert.equal(await p.locator('noscript video').count(),1);}finally{await p.close();}
  });
  for(const params of ['', 'variant=1', 'variant=1&showFeatured=1']){
    await test(`optimized: gallery loading and priority (${params||'first image'})`,async()=>{
      const p=await pageFor('optimized','gallery',params);
      try{
        const images=await p.locator('modal-opener img').evaluateAll(imgs=>imgs.map(i=>({src:i.getAttribute('src'),loading:i.loading,priority:i.fetchPriority})));
        assert.equal(images.length,3);
        assert.equal(images.filter(i=>i.loading==='eager').length,1);
        assert.equal(images.filter(i=>i.priority==='high').length,1);
        const initial=images.find(i=>i.priority==='high');
        assert(initial.src.includes(params==='variant=1'?'p2.svg':'p1.svg'));
        assert.equal(initial.loading,'eager');
      }finally{await p.close();}
    });
  }
  await test('original: all gallery images are eager (baseline reproduced)',async()=>{
    const p=await pageFor('original','gallery');
    try{assert.deepEqual(await p.locator('modal-opener img').evaluateAll(a=>a.map(i=>i.loading)),['eager','eager','eager']);}finally{await p.close();}
  });
  for(const version of ['original','optimized']){
    await test(`${version}: homepage collection loading policy`,async()=>{
      const p=await pageFor(version,'collection');
      try{
        const images=await p.locator('.card__media img').evaluateAll(a=>a.map(i=>i.loading));
        assert.equal(images.length,20);
        assert(images.every(x=>x===(version==='original'?'eager':'lazy')));
        assert.equal(await p.locator('.card-wrapper').count(),10);
      }finally{await p.close();}
    });
  }
  await test('optimized: collection in first position retains eager first cards',async()=>{
    const p=await pageFor('optimized','collection','index=1');
    try{
      const policy=await p.locator('.card-wrapper').evaluateAll(cards=>cards.map(c=>c.querySelector('img').loading));
      assert.equal(policy.filter(x=>x==='eager').length,4);
      assert.equal(policy.filter(x=>x==='lazy').length,6);
    }finally{await p.close();}
  });
  await test('optimized: category icons use responsive CDN width parameters and keep layout',async()=>{
    const p=await pageFor('optimized','icons');
    try{
      const images=await p.locator('.product-icon img').evaluateAll(a=>a.map(i=>({src:i.currentSrc,loading:i.loading,width:i.getBoundingClientRect().width,height:i.getBoundingClientRect().height,srcset:i.srcset})));
      assert.equal(images.length,3);
      assert(images.every(i=>i.loading==='lazy'&&i.width===110&&i.height===110&&i.srcset.includes('width=330')));
    }finally{await p.close();}
  });
  await browser.close();
  server.close();
  fs.writeFileSync(`${base}/reports/browser-tests.json`,JSON.stringify({scope:'Offline Chromium component tests, synthetic media/Shopify objects, no production/checkout/Lighthouse claims',browser:'system Chromium',results},null,2));
  console.log(JSON.stringify({passed:results.filter(r=>r.status==='passed').length,failed:results.filter(r=>r.status==='failed').length}));
  process.exitCode=results.some(r=>r.status==='failed')?1:0;
})().catch(e=>{console.error(e);server.close();process.exit(1);});
