from pathlib import Path
from urllib.parse import urlsplit, quote
import collections, csv, json, re, struct

root = Path('/workspace/petelia/original')
out = Path('/workspace/petelia/reports')
media = collections.defaultdict(set)

def add(value, where):
    if not isinstance(value, str):
        return
    value = value.replace('\\/', '/')
    for ref in re.findall(r'''(?:shopify://(?:shop_images|files/videos)/|https?://)[^\s<>"'\\)]+''', value):
        ref = ref.replace('&amp;', '&').rstrip('.,;')
        if re.search(r'\.(png|jpe?g|gif|webp|avif|svg|mp4|mov)(?:\?|$)', ref, re.I) or 'youtube.com/watch' in ref:
            media[ref].add(where)

def walk(value, where):
    if isinstance(value, dict):
        for k, v in value.items(): walk(v, where + '/' + k)
    elif isinstance(value, list):
        for i, v in enumerate(value): walk(v, where + '/' + str(i))
    else: add(value, where)

for p in sorted(root.rglob('*')):
    if not p.is_file(): continue
    if p.suffix == '.json':
        walk(json.loads(p.read_text()), str(p.relative_to(root)))
    elif p.suffix == '.liquid':
        for n, line in enumerate(p.read_text().splitlines(), 1):
            add(line, f'{p.relative_to(root)}:{n}')

rows = []
for ref, contexts in sorted(media.items()):
    where = ' | '.join(sorted(contexts))
    candidate = ''
    if ref.startswith('shopify://shop_images/'):
        candidate = 'https://cdn.shopify.com/s/files/1/0818/9847/1758/files/' + quote(ref.split('/shop_images/', 1)[1])
    elif ref.startswith('https://'):
        candidate = ref
    impact, target, mobile, desktop, budget_mobile, budget_desktop = ('Basso/da confermare', 'WebP/AVIF negoziato da Shopify; fallback JPEG/PNG', '750–1100 px', '1100–1600 px', '80–180 KB', '120–250 KB')
    if any(w in where for w in ['banner_image', 'countdown-timer']):
        impact, mobile, desktop, budget_mobile, budget_desktop = ('Alto: hero homepage', '750–1080 px', '1600–1920 px', '80–180 KB', '150–300 KB')
    if any(w in where for w in ['rich-text.liquid:', 'automatico-strip']):
        impact, mobile, desktop, budget_mobile, budget_desktop = ('Medio: categorie/strip homepage', '220–330 px categorie; 540–750 px strip', '220–330 px categorie; 750–1440 px strip', '10–30 KB categorie; 30–80 KB strip', '10–30 KB categorie; 50–120 KB strip')
    if 'image-with-text-overlay' in where:
        impact, mobile, desktop, budget_mobile, budget_desktop = ('Medio: carosello sotto le collezioni', '750–1080 px', '1500–1920 px', '80–180 KB', '150–300 KB')
    if any(w in where for w in ['slideshow', 'image_687iEY', 'image_WX6kjq']):
        impact, mobile, desktop, budget_mobile, budget_desktop = ('Medio: slideshow gioielli fuori schermo', '750–1080 px', '1500–1920 px', '80–180 KB', '150–300 KB')
    if 'header-group' in where or 'logo' in where:
        impact, target, mobile, desktop, budget_mobile, budget_desktop = ('Medio: logo/header se attivo', 'PNG/WebP trasparente, SVG solo se originale affidabile', 'larghezza CSS ×2, max 600 px', 'larghezza CSS ×2, max 600 px', '10–40 KB', '10–40 KB')
    if 'Cattura3.jpg' in ref:
        impact, mobile, desktop, budget_mobile, budget_desktop = ('Basso: badge Trustpilot in fondo pagina', '300 px per resa a 150 px CSS', '300 px', '10–25 KB', '10–25 KB')
    if '.gif' in ref:
        impact, target, mobile, desktop, budget_mobile, budget_desktop = ('Medio se GIF originale pesante; fuori schermo', 'Mantenere GIF animato; eventuale WebP animato dopo verifica compatibilità', '64–96 px per icona 2em', '64–96 px', '<50 KB indicativi', '<50 KB indicativi')
    if re.search(r'\.(mp4|mov)(?:\?|$)', ref) or 'youtube.com' in ref:
        impact = 'Alto: secondo media hero mobile' if 'banner_video' in where else 'Medio: video inferiore o template alternativo'
        target, mobile, desktop, budget_mobile, budget_desktop = ('MP4 H.264; rapporto e contenuto conservati', '540–720 px larghezza; 24–30 fps', '1280–1920 px larghezza; 24–30 fps', '0,6–1,2 Mbps (~0,75–1,5 MB/10 s)', '1,5–3 Mbps (~1,9–3,75 MB/10 s)')
    action = 'Sostituzione/compressione originale dal pannello Shopify; i parametri CDN non riscrivono il file originale'
    if 'youtube.com' in ref: action = 'Video esterno: verificare solo se effettivamente usato; il video Shopify ha precedenza quando configurato'
    if ref.startswith('shopify://files/videos/'): candidate = 'URL di transcodifica non ricostruibile dal nome; recuperare video.sources nell’HTML Shopify'
    rows.append(dict(riferimento=ref, dove=where, url_candidato_non_verificato=candidate,
                     dimensioni_reali='Non misurate: originale remoto non accessibile', peso_reale_byte='Non misurato',
                     impatto=impact, formato_consigliato=target, larghezza_mobile=mobile, larghezza_desktop=desktop,
                     budget_mobile=budget_mobile, budget_desktop=budget_desktop, intervento_manuale=action))

for p in sorted((root/'assets').glob('*')):
    if p.suffix not in ['.png', '.svg']: continue
    dims = 'Non rilevate'
    if p.suffix == '.png': dims = '%s × %s' % struct.unpack('>II', p.read_bytes()[16:24])
    if p.suffix == '.svg':
        m = re.search(r'viewBox="([^"]+)"', p.read_text())
        dims = 'viewBox ' + m[1] if m else 'Vettoriale'
    rows.append(dict(riferimento='assets/'+p.name, dove='Asset locale; uso da verificare per componente',
                     url_candidato_non_verificato='', dimensioni_reali=dims,peso_reale_byte=str(p.stat().st_size),
                     impatto='Trascurabile',formato_consigliato='Conservare',larghezza_mobile='Invariata',larghezza_desktop='Invariata',
                     budget_mobile='Invariato',budget_desktop='Invariato',intervento_manuale='No'))

for name in ['Mare Nostrum','Silva Viridis','Prodotti delle collezioni frontpage e orologi-donna']:
    rows.append(dict(riferimento='Dinamico Shopify: '+name,dove='product.media / card_product.featured_media; dati catalogo esclusi dallo ZIP',
                     url_candidato_non_verificato='Da estrarre dalla pagina reale: non assumere handle o assegnazione template',
                     dimensioni_reali='Non disponibili nello ZIP',peso_reale_byte='Non misurato',impatto='Alto: foto iniziale PDP; medio: card',
                     formato_consigliato='WebP/AVIF tramite Shopify CDN; originale dettagliato conservato per zoom',
                     larghezza_mobile='PDP 750–1100 px; card 360–540 px',larghezza_desktop='PDP 1100–1500 px; card 400–750 px',
                     budget_mobile='PDP 80–180 KB; card 30–80 KB',budget_desktop='PDP 120–250 KB; card 40–100 KB',
                     intervento_manuale='Verificare tutte le foto reali del prodotto; comprimere originali solo se necessario, preservare varianti/zoom'))

with (out/'INVENTARIO_MEDIA.csv').open('w',newline='',encoding='utf-8-sig') as f:
    w=csv.DictWriter(f,fieldnames=list(rows[0]),delimiter=';');w.writeheader();w.writerows(rows)
(out/'inventario-media.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2))
print('Inventario:',len(rows),'righe,',len(media),'riferimenti remoti distinti. Dimensioni e budget raccomandati non sono misure.')
