from pathlib import Path
import re

root=Path('/workspace/petelia/v2/theme')
p=root/'sections/countdown-timer.liquid'
source=p.read_text()
assert source.count('<script>')==1
source=re.sub(r'<script>[\s\S]*?</script>',lambda m:'<script>\n'+Path('/workspace/petelia/v2/tools/hero-controller.js').read_text()+'\n</script>',source,count=1)
source=source.replace('  assign video_display = section.settings.video_display | default: \'mobile\'\n', '''  assign video_display = section.settings.video_display | default: 'mobile'
  assign mobile_video_url = ''
  assign mobile_video_pixels = 0
  for source in section.settings.banner_video.sources
    if source.format == 'mp4' and source.height > 0 and source.width > 0
      if source.height <= 720 and source.width <= 1280
        assign source_pixels = source.height | times: source.width
        if source_pixels > mobile_video_pixels
          assign mobile_video_pixels = source_pixels
          assign mobile_video_url = source.url
        endif
      endif
    endif
  endfor
''',1)
source=source.replace('data-desktop-second="{{ section.settings.desktop_second_image }}">','data-desktop-second="{{ section.settings.desktop_second_image }}" data-mobile-video-src="{{ mobile_video_url | escape }}" role="region" aria-roledescription="carosello" aria-label="Banner Petelia">',1)
needle='    <div class="overlay-content-bottom">'
controls='''    <div class="petelia-gallery-controls" data-gallery-controls hidden>
      <button type="button" class="petelia-gallery-arrow petelia-gallery-arrow--previous" data-gallery-previous aria-label="Slide precedente">
        <svg viewBox="0 0 24 24" width="22" height="22" fill="none" aria-hidden="true" focusable="false"><path d="m15 5-7 7 7 7" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>
      </button>
      <div class="petelia-gallery-dots" role="group" aria-label="Scegli il contenuto del banner">
        <button type="button" class="petelia-gallery-dot" data-gallery-dot="0" aria-label="Mostra l'immagine" aria-pressed="true"></button>
        <button type="button" class="petelia-gallery-dot" data-gallery-dot="1" aria-label="Mostra il video" aria-pressed="false"></button>
      </div>
      <button type="button" class="petelia-gallery-arrow petelia-gallery-arrow--next" data-gallery-next aria-label="Slide successiva">
        <svg viewBox="0 0 24 24" width="22" height="22" fill="none" aria-hidden="true" focusable="false"><path d="m9 5 7 7-7 7" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>
      </button>
    </div>
    <button type="button" class="petelia-gallery-play" data-gallery-play hidden>Riproduci il video</button>
    <span class="visually-hidden" data-gallery-status aria-live="polite" aria-atomic="true"></span>

'''
assert source.count(needle)==1
source=source.replace(needle,controls+needle,1)
css='''
  /* Mobile gallery: the original first image still reserves the entire banner. */
  #shopify-section-{{ section.id }} .petelia-gallery-controls { display: contents; }
  #shopify-section-{{ section.id }} .petelia-gallery-controls[hidden],
  #shopify-section-{{ section.id }} .petelia-gallery-play[hidden] { display: none; }
  #shopify-section-{{ section.id }} .petelia-gallery-arrow,
  #shopify-section-{{ section.id }} .petelia-gallery-play {
    position: absolute; z-index: 12; display: inline-flex;
    align-items: center; justify-content: center;
    border: 1px solid rgba(255,255,255,.65); color: #fff;
    background: rgba(0,0,0,.35); cursor: pointer;
  }
  #shopify-section-{{ section.id }} .petelia-gallery-arrow {
    top: 50%; transform: translateY(-50%); width: 42px; height: 42px;
    padding: 0; border-radius: 50%;
  }
  #shopify-section-{{ section.id }} .petelia-gallery-arrow:disabled { opacity: .35; cursor: default; }
  #shopify-section-{{ section.id }} .petelia-gallery-arrow--previous { left: 10px; }
  #shopify-section-{{ section.id }} .petelia-gallery-arrow--next { right: 10px; }
  #shopify-section-{{ section.id }} .petelia-gallery-play {
    top: 50%; left: 50%; transform: translate(-50%,-50%);
    padding: 10px 16px; border-radius: 4px; font: inherit;
  }
  #shopify-section-{{ section.id }} .petelia-gallery-dots {
    position: absolute; z-index: 12; bottom: 4px; left: 50%;
    transform: translateX(-50%); display: flex; gap: 2px;
    border-radius: 20px; background: rgba(0,0,0,.3); padding: 0 6px;
  }
  #shopify-section-{{ section.id }} .petelia-gallery-dot {
    display: flex; align-items: center; justify-content: center;
    width: 28px; height: 28px; margin: 0; padding: 0;
    border: 0; border-radius: 50%; background: transparent; cursor: pointer;
  }
  #shopify-section-{{ section.id }} .petelia-gallery-dot::before {
    content: ''; width: 8px; height: 8px; border-radius: 50%;
    background: #fff; opacity: .55;
  }
  #shopify-section-{{ section.id }} .petelia-gallery-dot[aria-pressed="true"]::before { opacity: 1; }
  #shopify-section-{{ section.id }} .petelia-gallery-controls button:focus-visible,
  #shopify-section-{{ section.id }} .petelia-gallery-play:focus-visible { outline: 2px solid #fff; outline-offset: 2px; }
  @media (max-width: 768px) {
    #shopify-section-{{ section.id }} [data-mobile-gallery="true"] { touch-action: pan-y pinch-zoom; }
    #shopify-section-{{ section.id }} [data-mobile-gallery="true"] .slide-1,
    #shopify-section-{{ section.id }} [data-mobile-gallery="true"] .slide-2 {
      animation: none; transform: translateX(0); opacity: 1;
      transition: transform .22s ease;
    }
    #shopify-section-{{ section.id }} [data-mobile-gallery="true"][data-gallery-index="1"] .slide-1 {
      transform: translateX(-100%); pointer-events: none;
    }
    #shopify-section-{{ section.id }} [data-mobile-gallery="true"] .slide-2[hidden] {
      display: block; visibility: hidden; transform: translateX(100%); pointer-events: none;
    }
    #shopify-section-{{ section.id }} [data-mobile-gallery="true"] .overlay-content-bottom {
      padding-bottom: calc(clamp(14px, 4vw, 22px) + 22px);
    }
  }
  @media (prefers-reduced-motion: reduce) {
    #shopify-section-{{ section.id }} [data-mobile-gallery="true"] .banner-slide { transition: none; }
  }
'''
assert source.count('</style>')==1
source=source.replace('</style>',css+'\n</style>',1)
source=source.replace('Il video viene caricato soltanto sul dispositivo selezionato.','Su mobile il video si carica solo aprendo la seconda slide. Su desktop resta il comportamento configurato.',1)
p.write_text(source)
print('Gallery implemented; media selections and copy preserved.')
