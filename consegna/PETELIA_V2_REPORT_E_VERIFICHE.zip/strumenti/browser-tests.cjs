const fs=require('node:fs');
const http=require('node:http');
const assert=require('node:assert/strict');
const {chromium}=require('/workspace/petelia/tools/node_modules/playwright-core');
const {fixture}=require('./fixtures.cjs');
const base='/workspace/petelia/v2';
const results=[];
const server=http.createServer(async(req,res)=>{
  try{
    const u=new URL(req.url,'http://local');
    if(u.pathname==='/fixture'){
      res.setHeader('Content-Type','text/html');res.end(await fixture(u.searchParams.get('version')||'theme',u.searchParams.get('type')||'hero',u.searchParams));
    }else if(u.pathname.startsWith('/asset/')){
      const [, ,v,file]=u.pathname.split('/');assert(['theme','base'].includes(v));assert(!file.includes('..'));
      res.setHeader('Content-Type',file.endsWith('.js')?'text/javascript':'text/css');res.end(fs.readFileSync(`${base}/${v}/assets/${file}`));
    }else if(u.pathname.startsWith('/media/')){
      res.setHeader('Content-Type','video/mp4');res.end(fs.readFileSync('/workspace/petelia/tools/test-video.mp4'));
    }else if(u.pathname.startsWith('/image/')){
      if(u.pathname.includes('/hero.svg'))await new Promise(r=>setTimeout(r,300));
      res.setHeader('Content-Type','image/svg+xml');res.end('<svg xmlns="http://www.w3.org/2000/svg" width="941" height="1366"><rect width="941" height="1366" fill="#b39b79"/></svg>');
    }else if(u.pathname==='/cart-fixture'){
      res.setHeader('Content-Type','text/html');res.end('<!doctype html><meta name="viewport" content="width=device-width,initial-scale=1"><mini-cart id="mini-cart" data-url="/?section_id=mini-cart"><p id="retained">Carrello precedente</p></mini-cart><span id="cart-icon-bubble">0</span><span id="mobile-cart-icon-bubble">0</span><form id="cart" action="/cart" method="post"><button name="checkout">Checkout simulato</button></form>');
    }else if(u.pathname==='/checkout'){
      res.setHeader('Content-Type','text/html');res.end('<h1>Checkout locale simulato: nessun ordine</h1>');
    }else{res.statusCode=404;res.end('not found');}
  }catch(e){res.statusCode=500;res.end(String(e.stack));}
});
(async()=>{
  await new Promise(r=>server.listen(0,'127.0.0.1',r));
  const origin=`http://127.0.0.1:${server.address().port}`;
  const browser=await chromium.launch({executablePath:'/usr/bin/chromium',headless:true,args:['--no-sandbox']});
  async function test(name,fn){
    try{await fn();results.push({name,status:'passed'});console.log('PASS',name);}
    catch(e){results.push({name,status:'failed',error:e.stack});console.error('FAIL',name,e.message);}
  }
  async function pageFor(type='hero',params='',version='theme',viewport={width:390,height:844},init){
    const p=await browser.newPage({viewport,isMobile:viewport.width<769,hasTouch:true});
    p.errors=[];p.media=[];
    p.on('pageerror',e=>p.errors.push(e.message));
    p.on('request',r=>{if(r.url().includes('/media/'))p.media.push(r.url());});
    await p.route('https://**/*',r=>r.fulfill({status:200,body:'',contentType:'text/css'}));
    if(init)await p.addInitScript(init);
    await p.goto(`${origin}/fixture?type=${type}&version=${version}&${params}`,{waitUntil:'load'});
    return p;
  }
  async function mobileHero(fn,params='',init){const p=await pageFor('hero',params,'theme',undefined,init);try{await fn(p);assert.deepEqual(p.errors,[]);}finally{await p.close();}}
  await test('Mobile: no MP4, no auto rotation through a complete former 12s cycle',()=>mobileHero(async p=>{
    assert.equal(await p.locator('[data-secondary-slot] video').count(),0);
    assert.equal(await p.locator('[data-gallery-controls]').isVisible(),true);
    assert.equal(await p.locator('.slide-1 img').getAttribute('fetchpriority'),'high');
    assert.equal(await p.locator('.slide-1 img').getAttribute('loading'),'eager');
    await p.waitForTimeout(12500);
    assert.equal(p.media.length,0);
    assert.equal(await p.locator('[data-petelia-hero]').getAttribute('data-gallery-index'),'0');
  }));
  await test('Mobile: second dot creates one 720p MP4; return pauses; reopening reuses player',()=>mobileHero(async p=>{
    await p.locator('[data-gallery-dot="1"]').click();
    await p.waitForFunction(()=>{const v=document.querySelector('[data-secondary-slot] video');return v&&!v.paused;});
    assert.equal(await p.locator('[data-secondary-slot] video').count(),1);
    assert(p.media.some(x=>x.endsWith('/media/mobile.mp4')));
    assert(!p.media.some(x=>x.endsWith('/media/desktop.mp4')||x.endsWith('/media/video.mp4')));
    assert.equal(await p.locator('[data-secondary-slot] video').evaluate(v=>v.muted&&v.playsInline&&v.loop),true);
    await p.locator('[data-secondary-slot] video').evaluate(v=>v.dataset.fixtureIdentity='same');
    await p.locator('[data-gallery-dot="0"]').click();
    assert.equal(await p.locator('[data-secondary-slot] video').evaluate(v=>v.paused),true);
    await p.locator('[data-gallery-next]').click();
    assert.equal(await p.locator('[data-secondary-slot] video').getAttribute('data-fixture-identity'),'same');
  }));
  await test('Mobile: real touch swipe changes slides; vertical pan scrolls without changing slide',()=>mobileHero(async p=>{
    const cdp=await p.context().newCDPSession(p);
    async function swipe(x1,y1,x2,y2){
      await cdp.send('Input.dispatchTouchEvent',{type:'touchStart',touchPoints:[{x:x1,y:y1}]});
      for(let i=1;i<=5;i++)await cdp.send('Input.dispatchTouchEvent',{type:'touchMove',touchPoints:[{x:x1+(x2-x1)*i/5,y:y1+(y2-y1)*i/5}]});
      await cdp.send('Input.dispatchTouchEvent',{type:'touchEnd',touchPoints:[]});
      await p.waitForTimeout(250);
    }
    await swipe(300,220,80,220);
    assert.equal(await p.locator('[data-petelia-hero]').getAttribute('data-gallery-index'),'1');
    await swipe(80,220,300,220);
    assert.equal(await p.locator('[data-petelia-hero]').getAttribute('data-gallery-index'),'0');
    await swipe(180,350,180,110);
    assert.equal(await p.locator('[data-petelia-hero]').getAttribute('data-gallery-index'),'0');
    assert(await p.evaluate(()=>window.scrollY>0));
  }));
  await test('Mobile: keyboard navigation and selected indicator stay in sync',()=>mobileHero(async p=>{
    await p.locator('[data-gallery-dot="0"]').focus();await p.keyboard.press('ArrowRight');
    assert.equal(await p.locator('[data-gallery-dot="1"]').getAttribute('aria-pressed'),'true');
    assert.equal(await p.locator('.slide-1').getAttribute('aria-hidden'),'true');
    await p.keyboard.press('ArrowLeft');
    assert.equal(await p.locator('[data-gallery-dot="0"]').getAttribute('aria-pressed'),'true');
  }));
  await test('Mobile: leaving viewport pauses video, returning resumes selected slide only',()=>mobileHero(async p=>{
    await p.locator('[data-gallery-dot="1"]').click();
    await p.waitForFunction(()=>!document.querySelector('video').paused);
    await p.evaluate(()=>window.scrollTo(0,2000));
    await p.waitForFunction(()=>document.querySelector('video').paused);
    await p.evaluate(()=>window.scrollTo(0,0));
    await p.waitForFunction(()=>!document.querySelector('video').paused);
    await p.locator('[data-gallery-dot="0"]').click();
    await p.evaluate(()=>{window.scrollTo(0,2000);});await p.waitForTimeout(100);
    await p.evaluate(()=>window.scrollTo(0,0));await p.waitForTimeout(100);
    assert.equal(await p.locator('video').evaluate(v=>v.paused),true);
  }));
  await test('Mobile: blocked playback exposes a working explicit play button',()=>mobileHero(async p=>{
    await p.locator('[data-gallery-dot="1"]').click();
    await p.waitForFunction(()=>!document.querySelector('[data-gallery-play]').hidden);
    await p.evaluate(()=>{HTMLMediaElement.prototype.play=window.fixtureOriginalPlay;});
    await p.locator('[data-gallery-play]').click();
    await p.waitForFunction(()=>!document.querySelector('video').paused && document.querySelector('[data-gallery-play]').hidden);
    assert.equal(await p.locator('[data-gallery-play]').isVisible(),false);
  },'',()=>{window.fixtureOriginalPlay=HTMLMediaElement.prototype.play;HTMLMediaElement.prototype.play=function(){return Promise.reject(new DOMException('Blocked in fixture','NotAllowedError'));};}));
  await test('Mobile: video error returns to first image without a blank slide',()=>mobileHero(async p=>{
    await p.locator('[data-gallery-dot="1"]').click();
    await p.locator('video').evaluate(v=>v.dispatchEvent(new Event('error')));
    assert.equal(await p.locator('[data-petelia-hero]').getAttribute('data-gallery-index'),'0');
    assert.equal(await p.locator('[data-gallery-controls]').isVisible(),false);
    assert.equal(await p.locator('.slide-1').getAttribute('aria-hidden'),'false');
  }));
  await test('Mobile: video error falls back to the configured second image',()=>mobileHero(async p=>{
    await p.locator('[data-gallery-dot="1"]').click();
    await p.locator('video').evaluate(v=>v.dispatchEvent(new Event('error')));
    assert.equal(await p.locator('[data-secondary-slot] video').count(),0);
    assert.equal(await p.locator('[data-secondary-slot] img').count(),1);
    assert.equal(await p.locator('[data-gallery-dot="1"]').getAttribute('aria-label'),'Mostra la seconda immagine');
    assert.equal(await p.locator('[data-gallery-status]').textContent(),'Immagine, 2 di 2');
  },'secondary=1'));
  await test('Mobile: no secondary media means no controls; image fallback needs no video',async()=>{
    for(const params of ['noVideo=1','mode=none','noVideo=1&secondary=1']){
      const p=await pageFor('hero',params);try{
        const secondary=params.includes('secondary');
        assert.equal(await p.locator('[data-gallery-controls]').isVisible(),secondary);
        if(secondary){await p.locator('[data-gallery-dot="1"]').click();assert.equal(await p.locator('[data-secondary-slot] img').count(),1);}
        assert.equal(p.media.length,0);assert.deepEqual(p.errors,[]);
      }finally{await p.close();}
    }
  });
  await test('Desktop: current mobile-only configuration stays static through breakpoint changes',async()=>{
    const p=await pageFor('hero','','theme',{width:1440,height:900});try{
      assert.equal(await p.locator('[data-gallery-controls]').isVisible(),false);assert.equal(p.media.length,0);
      assert((await p.locator('.slide-1 img').evaluate(i=>i.currentSrc)).includes('desktop.svg'));
      await p.setViewportSize({width:390,height:844});await p.waitForFunction(()=>document.querySelector('[data-petelia-hero]').dataset.mobileGallery==='true');
      assert.equal(p.media.length,0);await p.locator('[data-gallery-dot="1"]').click();
      await p.setViewportSize({width:1440,height:900});await p.waitForFunction(()=>!document.querySelector('[data-secondary-slot] video'));
      assert.equal(await p.locator('[data-gallery-controls]').isVisible(),false);assert.deepEqual(p.errors,[]);
    }finally{await p.close();}
  });
  await test('Desktop: explicitly configured desktop video still activates after first image',async()=>{
    const p=await pageFor('hero','mode=all','theme',{width:1440,height:900});try{
      await p.waitForFunction(()=>!!document.querySelector('[data-secondary-slot] video'));
      assert.equal(await p.locator('[data-petelia-hero]').getAttribute('data-second-active'),'true');
      assert.equal(await p.locator('[data-gallery-controls]').isVisible(),false);assert.deepEqual(p.errors,[]);
    }finally{await p.close();}
  });
  await test('Mobile: editor unload cleans handlers and pending playback',()=>mobileHero(async p=>{
    await p.locator('[data-gallery-dot="1"]').click();
    await p.evaluate(()=>document.getElementById('shopify-section-fixture').dispatchEvent(new CustomEvent('shopify:section:unload',{bubbles:true})));
    assert.equal(await p.locator('video').evaluate(v=>v.paused),true);
    await p.locator('[data-gallery-dot="0"]').click();
    assert.equal(await p.locator('[data-petelia-hero]').getAttribute('data-gallery-index'),'1');
  }));
  await test('Mobile: reduced motion disables gallery transitions',async()=>{
    const p=await pageFor();try{
      await p.emulateMedia({reducedMotion:'reduce'});
      assert.equal(await p.locator('.slide-1').evaluate(e=>getComputedStyle(e).transitionDuration),'0s');
    }finally{await p.close();}
  });
  await test('Mobile: hero dimensions and CTA links remain stable; controls do not overlap CTA',async()=>{
    for(const width of [320,390,430,768]){
      const p=await pageFor('hero','','theme',{width,height:900});const old=await pageFor('hero','','base',{width,height:900});
      try{
        const box=await p.locator('[data-petelia-hero]').boundingBox();const previous=await old.locator('[data-petelia-hero]').boundingBox();
        assert(Math.abs(box.height-previous.height)<1,`height ${width}: ${box.height} vs ${previous.height}`);
        assert.deepEqual(await p.locator('.shop-buttons-container a').evaluateAll(a=>a.map(x=>({text:x.textContent,href:x.getAttribute('href')}))),await old.locator('.shop-buttons-container a').evaluateAll(a=>a.map(x=>({text:x.textContent,href:x.getAttribute('href')}))));
        const cta=await p.locator('.shop-buttons-container').boundingBox();const dots=await p.locator('.petelia-gallery-dots').boundingBox();
        assert(cta.y+cta.height<=dots.y,`CTA overlaps dots at ${width}`);
        await p.locator('[data-gallery-dot="1"]').click();
        assert(Math.abs((await p.locator('[data-petelia-hero]').boundingBox()).height-box.height)<1);
        if(width===390){await p.locator('[data-gallery-dot="0"]').click();await p.waitForTimeout(250);await p.screenshot({path:base+'/reports/hero-local-mobile.png'});}
      }finally{await p.close();await old.close();}
    }
  });
  for(const params of ['', 'variant=1','variant=1&showFeatured=1']){
    await test('PDP preserved: initial media eager/high and remaining media lazy '+params,async()=>{
      const p=await pageFor('gallery',params);try{
        const a=await p.locator('modal-opener img').evaluateAll(xs=>xs.map(x=>({loading:x.loading,p:x.fetchPriority})));
        assert.equal(a.length,3);assert.equal(a.filter(x=>x.loading==='eager').length,1);assert.equal(a.filter(x=>x.p==='high').length,1);
      }finally{await p.close();}
    });
  }
  await test('Collections preserved: all ten cards retained and twenty offscreen images lazy',async()=>{
    const p=await pageFor('collection');try{assert.equal(await p.locator('.card-wrapper').count(),10);assert.equal(await p.locator('.card__media img').count(),20);assert((await p.locator('.card__media img').evaluateAll(a=>a.map(i=>i.loading))).every(x=>x==='lazy'));}finally{await p.close();}
  });
  await test('Lower video preserved: no player until section nears viewport',async()=>{
    const p=await pageFor('lower');try{
      assert.equal(await p.locator('video-section > video').count(),0);
      await p.locator('video-section').scrollIntoViewIfNeeded();await p.waitForFunction(()=>!!document.querySelector('video-section > video'));
    }finally{await p.close();}
  });
  await test('Hero without JavaScript retains the first image and hides inactive navigation',async()=>{
    const p=await browser.newPage({viewport:{width:390,height:844},javaScriptEnabled:false});try{
      await p.route('https://**/*',r=>r.fulfill({status:200,body:'',contentType:'text/css'}));
      await p.goto(origin+'/fixture?type=hero&version=theme');
      assert.equal(await p.locator('.slide-1 img').isVisible(),true);
      assert.equal(await p.locator('[data-gallery-controls]').isVisible(),false);
      assert.equal(await p.locator('[data-secondary-slot] video').count(),0);
    }finally{await p.close();}
  });
  await test('WhatsApp icon preserves text/link and has no external stylesheet or icon font',async()=>{
    const p=await browser.newPage();const requests=[];p.on('request',r=>requests.push(r.url()));try{
      const json=JSON.parse(fs.readFileSync(base+'/theme/templates/index.json','utf8'));
      const markup=json.sections.custom_liquid_mUBFxE.settings.custom_liquid;
      await p.setContent(markup);
      assert.equal(await p.locator('svg').count(),1);
      assert.equal(await p.locator('svg').getAttribute('viewBox'),'0 0 448 512');
      assert.equal(await p.locator('a').getAttribute('href'),'whatsapp://send?phone=393348926797');
      assert((await p.locator('body').textContent()).includes('Assistenza WhatsApp:'));
      assert.equal(await p.locator('link[rel=stylesheet]').count(),0);assert.equal(requests.length,0);
    }finally{await p.close();}
  });
  // Real cart guard with simulated Shopify responses; no connection to Shopify.
  async function cartPage(config={}){
    const p=await browser.newPage();p.alerts=[];p.on('dialog',d=>{p.alerts.push(d.message());d.dismiss();});
    await p.goto(origin+'/cart-fixture');
    await p.evaluate(config=>{
      const wrapped='<div class="shopify-section"><form class="mini-cart" id="cart"><p id="fresh">Carrello aggiornato</p></form></div>';
      const raw='<form class="mini-cart" id="cart"><p id="fresh">Carrello aggiornato</p></form>';
      window.fixtureCart={items:[],calls:[],config,wrapped,raw};
      window.theme={routes:{cart_url:'/cart',cart_add_url:'/cart/add',cart_update_url:'/cart/update'}};
      window.PeteliaThemeContext={url:input=>{
        const u=new URL(input,location.href);u.searchParams.set('preview_theme_id','88');return u.pathname+u.search;
      }};
      window.fetch=async(input,options={})=>{
        const m=window.fixtureCart,u=new URL(input,location.href),method=options.method||'GET';
        m.calls.push({url:u.pathname+u.search,method,body:options.body?JSON.parse(options.body):null});
        const respond=(obj,status=200,type='application/json')=>new Response(type==='application/json'?JSON.stringify(obj):obj,{status,headers:{'Content-Type':type}});
        const cart=()=>({items:structuredClone(m.items),item_count:m.items.reduce((n,i)=>n+i.quantity,0)});
        if(u.pathname==='/cart.js')return respond(cart());
        if(u.searchParams.has('sections')){
          const html=m.config.bundle==='null'?null:m.config.bundle==='raw'?raw:wrapped;
          return respond({'mini-cart':html,'cart-icon-bubble':'<div class="shopify-section">2</div>','mobile-cart-icon-bubble':'<div class="shopify-section">2</div>'});
        }
        if(u.searchParams.has('section_id')){
          if(m.config.fallback==='404')return respond('missing',404,'text/html');
          if(m.config.fallback==='page')return respond('<!doctype html><html><body><form class="mini-cart">Unexpected error page</form></body></html>',200,'text/html');
          return respond(m.config.fallback==='raw'?raw:wrapped,200,'text/html');
        }
        if(u.pathname==='/cart/add'&&method==='POST'){
          if(m.config.failWrites)return respond({description:'Scrittura simulata rifiutata'},422);
          const body=JSON.parse(options.body);
          body.items.forEach((i,n)=>m.items.push({key:'added-'+m.calls.length+'-'+n,variant_id:i.id,quantity:i.quantity,properties:i.properties}));
          return respond({items:body.items});
        }
        if(u.pathname==='/cart/update'&&method==='POST'){
          if(m.config.failWrites)return respond({description:'Scrittura simulata rifiutata'},422);
          const body=JSON.parse(options.body);
          m.items=m.items.filter(i=>body.updates[i.key]!==0).map(i=>({...i,quantity:body.updates[i.key]??i.quantity}));return respond(cart());
        }
        throw Error('Unexpected fixture endpoint: '+u.pathname);
      };
    },config);
    await p.addScriptTag({path:base+'/theme/assets/petelia-cart-guard.js'});return p;
  }
  for(const config of [{bundle:'wrapped'},{bundle:'raw'},{bundle:'null',fallback:'wrapped'},{bundle:'null',fallback:'raw'}]){
    await test('Cart refresh: validated markup '+JSON.stringify(config),async()=>{
      const p=await cartPage(config);try{
        await p.evaluate(()=>window.PeteliaCartGuard.refreshCartView());
        assert.equal(await p.locator('#mini-cart #fresh').count(),1);
        const calls=await p.evaluate(()=>fixtureCart.calls);assert(calls.every(c=>c.method==='GET'));
        const fallback=calls.filter(c=>new URL(c.url,origin).searchParams.has('section_id'));
        assert.equal(fallback.length,config.bundle==='null'?1:0);
        assert(calls.filter(c=>c.url.includes('sections=')||c.url.includes('section_id=')).every(c=>c.url.includes('preview_theme_id=88')));
      }finally{await p.close();}
    });
  }
  for(const failure of ['404','page']){
    await test('Cart refresh: invalid fallback keeps prior drawer and reports failure '+failure,async()=>{
      const p=await cartPage({bundle:'null',fallback:failure});try{
        const outcome=await p.evaluate(()=>window.PeteliaCartGuard.refreshCartView().then(()=>'',e=>e.message));
        assert(outcome.length>0);assert.equal(await p.locator('#retained').count(),1);assert.equal(await p.locator('#fresh').count(),0);
        assert((await p.evaluate(()=>fixtureCart.calls)).every(c=>c.method==='GET'));
      }finally{await p.close();}
    });
  }
  await test('Cart refresh: concurrent callers share one request sequence',async()=>{
    const p=await cartPage({bundle:'null'});try{
      assert.equal(await p.evaluate(()=>{const a=PeteliaCartGuard.refreshCartView(),b=PeteliaCartGuard.refreshCartView();return a===b;}),true);
      await p.waitForFunction(()=>!!document.querySelector('#fresh'));
      assert.equal((await p.evaluate(()=>fixtureCart.calls)).length,3);
    }finally{await p.close();}
  });
  await test('Commercial regression: all 32 extra combinations with text/pending values and quantity 2',async()=>{
    const p=await cartPage();try{
      const outcome=await p.evaluate(async()=>{
        const ids={gift:60042356359502,shopper:60043439178062,box:60042425958734,case:60043114021198,combo:60043135844686,nfc:60043171135822};
        let checked=0;
        for(let bits=0;bits<32;bits++)for(const text of ['Testo personalizzato','Da comunicare dopo l’ordine']){
          const [gift,shopper,box,engraving,nfc]=[0,1,2,3,4].map(i=>!!(bits&(1<<i)));
          const properties={_petelia_bundle_id:'watch-A'};
          if(gift)properties['Confezione regalo']='Sì';if(shopper)properties['Shopper Petelia']='Sì';
          if(box)properties['Incisione box']=text;if(engraving)properties['Incisione cassa']=text;if(nfc)properties['Dedica NFC']=text;
          fixtureCart.items=[{key:'watch',variant_id:111,quantity:2,properties}];fixtureCart.calls=[];
          const result=await PeteliaCartGuard.repairPeteliaCart();
          const expected=[...(gift?[ids.gift]:[]),...(shopper?[ids.shopper]:[]),...(box&&engraving?[ids.combo]:box?[ids.box]:engraving?[ids.case]:[]),...(nfc?[ids.nfc]:[])].sort();
          const extras=result.items.filter(i=>i.key!=='watch');
          if(JSON.stringify(extras.map(i=>i.variant_id).sort())!==JSON.stringify(expected))throw Error('Missing/extra service for combination '+bits);
          if(extras.some(i=>i.quantity!==2||i.properties._petelia_bundle_id!=='watch-A'))throw Error('Incorrect group/quantity');
          if(extras.some(i=>Object.keys(i.properties).some(k=>!['_petelia_bundle_id','_petelia_extra_item','_petelia_service_type'].includes(k))))throw Error('Unwanted technical property');
          if(JSON.stringify(result.items.find(i=>i.key==='watch').properties)!==JSON.stringify(properties))throw Error('Main properties changed');
          checked++;
        }
        return checked;
      });
      assert.equal(outcome,64);
    }finally{await p.close();}
  });
  await test('Commercial regression: grouped removal preserves a different customized watch',async()=>{
    const p=await cartPage();try{
      await p.evaluate(async()=>{
        fixtureCart.items=[{key:'A',variant_id:111,quantity:1,properties:{_petelia_bundle_id:'A'}},{key:'serviceA',variant_id:60042356359502,quantity:1,properties:{_petelia_bundle_id:'A',_petelia_extra_item:'true'}},{key:'B',variant_id:111,quantity:1,properties:{_petelia_bundle_id:'B'}}];
        await PeteliaCartGuard.removeGroup('A');
      });
      assert.deepEqual(await p.evaluate(()=>fixtureCart.items.map(i=>i.key)),['B']);
    }finally{await p.close();}
  });
  await test('Checkout regression: successful repair navigates; rejected writes prevent navigation',async()=>{
    for(const failWrites of [false,true]){
      const p=await cartPage({failWrites});try{
        await p.evaluate(()=>{fixtureCart.items=[{key:'watch',variant_id:111,quantity:1,properties:{_petelia_bundle_id:'A','Confezione regalo':'Sì'}}];});
        await p.locator('[name="checkout"]').click();
        if(failWrites){await p.waitForTimeout(100);assert(p.url().includes('/cart-fixture'));assert.equal(p.alerts.length,1);assert.equal(await p.locator('[name="checkout"]').isDisabled(),false);}
        else{await p.waitForURL('**/checkout');assert.equal(await p.locator('h1').textContent(),'Checkout locale simulato: nessun ordine');}
      }finally{await p.close();}
    }
  });
  await browser.close();server.close();
  fs.writeFileSync(base+'/reports/browser-tests.json',JSON.stringify({scope:'Offline Chromium with synthetic media and Shopify response fixtures. No live Shopify/Meta/checkout certification.',results},null,2));
  console.log(JSON.stringify({passed:results.filter(x=>x.status==='passed').length,failed:results.filter(x=>x.status==='failed').length}));
  process.exitCode=results.some(x=>x.status==='failed')?1:0;
})().catch(e=>{console.error(e);server.close();process.exit(1);});
