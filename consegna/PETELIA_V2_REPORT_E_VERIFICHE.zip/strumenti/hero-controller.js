(function() {
  const sectionRoot = document.getElementById('shopify-section-{{ section.id }}');
  if (!sectionRoot) return;
  if (sectionRoot.peteliaHeroCleanup) sectionRoot.peteliaHeroCleanup();
  const hero = sectionRoot.querySelector('[data-petelia-hero]');
  if (!hero) return;
  const mediaQuery = window.matchMedia('(min-width: 769px)');
  const primaryImage = hero.querySelector('.slide-1 img');
  const firstSlide = hero.querySelector('.slide-1');
  const secondSlide = hero.querySelector('.slide-2');
  const slot = hero.querySelector('[data-secondary-slot]');
  const videoTemplate = hero.querySelector('[data-video-template]');
  const imageTemplate = hero.querySelector('[data-image-template]');
  const controls = hero.querySelector('[data-gallery-controls]');
  const playButton = hero.querySelector('[data-gallery-play]');
  const status = hero.querySelector('[data-gallery-status]');
  const dots = [...hero.querySelectorAll('[data-gallery-dot]')];
  const bar = hero.querySelector('.autonomous-countdown');
  const heading = hero.querySelector('[data-countdown-heading]');
  let primarySettled = !primaryImage || primaryImage.complete;
  let desktop = mediaQuery.matches;
  let index = 0;
  let video = null;
  let activeMedia = '';
  let videoFailed = false;
  let inView = true;
  let startPoint = null;
  let countdownInterval;
  let observer;
  let disposed = false;

  function videoAllowed() {
    const mode = hero.dataset.videoDisplay;
    return !!videoTemplate && !videoFailed && (mode === 'all' || (mode === 'mobile' && !desktop) || (mode === 'desktop' && desktop));
  }
  function imageAllowed() {
    return !!imageTemplate && (!desktop || hero.dataset.desktopSecond === 'true');
  }
  function stopVideo() {
    if (!video) return;
    video.removeEventListener('error', mediaError);
    video.pause();
    video.removeAttribute('src');
    video.querySelectorAll('source').forEach(source => source.removeAttribute('src'));
    video.load();
    video = null;
  }
  function pauseVideo() {
    if (video) video.pause();
    playButton.hidden = true;
  }
  function playVideo() {
    if (!video || document.hidden || !inView || (!desktop && index !== 1)) return;
    const player = video;
    const promise = player.play();
    if (promise && promise.then) promise.then(() => {
      if (disposed || video !== player) return;
      if ((!desktop && index !== 1) || document.hidden || !inView) player.pause();
      else playButton.hidden = true;
    }).catch(() => {
      if (!disposed && video === player && (desktop || index === 1) && inView && !document.hidden) playButton.hidden = false;
    });
  }
  function mediaError() {
    videoFailed = true;
    stopVideo();
    slot.replaceChildren();
    activeMedia = '';
    if (!imageAllowed()) index = 0;
    configureMedia();
    status.textContent = imageAllowed() ? 'Immagine, 2 di 2' : 'Immagine, 1 di 1';
  }
  function activateSecondary() {
    const type = videoAllowed() ? 'video' : imageAllowed() ? 'image' : '';
    if (!type) return false;
    if (activeMedia !== type) {
      stopVideo();
      const fragment = (type === 'video' ? videoTemplate : imageTemplate).content.cloneNode(true);
      if (type === 'video') {
        video = fragment.querySelector('video');
        if (!video) { videoFailed = true; return activateSecondary(); }
        video.muted = true;
        video.defaultMuted = true;
        video.autoplay = false;
        video.playsInline = true;
        video.preload = 'none';
        // Choose a bounded Shopify MP4 variant before attaching or playing it.
        if (!desktop && hero.dataset.mobileVideoSrc) {
          video.querySelectorAll('source').forEach(source => source.remove());
          video.src = hero.dataset.mobileVideoSrc;
        }
        video.addEventListener('error', mediaError, { once: true });
      }
      slot.replaceChildren(fragment);
      activeMedia = type;
    }
    return true;
  }
  function configureMedia() {
    if (disposed) return;
    if (desktop !== mediaQuery.matches) {
      desktop = mediaQuery.matches;
      index = 0;
      pauseVideo();
      stopVideo();
      slot.replaceChildren();
      activeMedia = '';
      videoFailed = false;
    }
    const hasSecond = videoAllowed() || imageAllowed();
    controls.hidden = desktop || !hasSecond;
    hero.dataset.mobileGallery = !desktop && hasSecond ? 'true' : 'false';
    if (!hasSecond) index = 0;
    if (!desktop) {
      hero.dataset.secondActive = 'false';
      hero.dataset.galleryIndex = String(index);
      firstSlide.setAttribute('aria-hidden', index === 1 ? 'true' : 'false');
      secondSlide.setAttribute('aria-hidden', index === 1 ? 'false' : 'true');
      secondSlide.hidden = index !== 1;
      if (index === 1 && activateSecondary()) playVideo();
      else pauseVideo();
      dots.forEach((dot, i) => dot.setAttribute('aria-pressed', i === index ? 'true' : 'false'));
      hero.querySelector('[data-gallery-previous]').disabled = index === 0;
      hero.querySelector('[data-gallery-next]').disabled = index === 1;
      dots[1].setAttribute('aria-label', videoAllowed() ? 'Mostra il video' : 'Mostra la seconda immagine');
    } else {
      firstSlide.removeAttribute('aria-hidden');
      secondSlide.removeAttribute('aria-hidden');
      playButton.hidden = true;
      if (primarySettled && hasSecond && activateSecondary()) {
        secondSlide.hidden = false;
        hero.dataset.secondActive = 'true';
        playVideo();
      } else {
        secondSlide.hidden = true;
        hero.dataset.secondActive = 'false';
      }
    }
  }
  function selectSlide(nextIndex) {
    if (desktop || !(videoAllowed() || imageAllowed())) return;
    index = Math.max(0, Math.min(1, nextIndex));
    configureMedia();
    status.textContent = index === 0 ? 'Immagine, 1 di 2' : videoAllowed() ? 'Video, 2 di 2' : 'Immagine, 2 di 2';
  }
  function click(event) {
    const dot = event.target.closest('[data-gallery-dot]');
    if (dot) selectSlide(Number(dot.dataset.galleryDot));
    else if (event.target.closest('[data-gallery-previous]')) selectSlide(index - 1);
    else if (event.target.closest('[data-gallery-next]')) selectSlide(index + 1);
    else if (event.target.closest('[data-gallery-play]')) playVideo();
  }
  function keydown(event) {
    if (desktop || event.target.closest('a, input, textarea, select, [contenteditable]')) return;
    if (event.key === 'ArrowLeft' || event.key === 'ArrowRight') {
      event.preventDefault();
      selectSlide(index + (event.key === 'ArrowLeft' ? -1 : 1));
    }
  }
  function pointerDown(event) {
    startPoint = null;
    if (desktop || event.isPrimary === false || (event.button !== undefined && event.button !== 0)) return;
    if (event.target.closest('a, button, input, textarea, select')) return;
    startPoint = { x: event.clientX, y: event.clientY, id: event.pointerId };
  }
  function pointerUp(event) {
    if (!startPoint || event.pointerId !== startPoint.id) return;
    const dx = event.clientX - startPoint.x;
    const dy = event.clientY - startPoint.y;
    startPoint = null;
    if (Math.abs(dx) >= 48 && Math.abs(dx) > Math.abs(dy) * 1.25) selectSlide(index + (dx < 0 ? 1 : -1));
  }
  function pointerCancel() { startPoint = null; }
  function visibilityChanged() {
    if (document.hidden) pauseVideo(); else playVideo();
  }
  function primaryMediaSettled() { primarySettled = true; configureMedia(); }
  function updateCountdown() {
    if (!bar) return false;
    const target = new Date(bar.getAttribute('data-date')).getTime();
    if (!Number.isFinite(target)) return false;
    const diff = target - Date.now();
    if (heading) heading.hidden = diff <= 0;
    if (diff <= 0) {
      clearInterval(countdownInterval);
      bar.innerHTML = '<div style="color:white; font-weight:bold; width:100%; text-align:center;">CONOSCI MEGLIO I NOSTRI PRODOTTI</div>';
      return false;
    }
    const values = [Math.floor(diff / 86400000), Math.floor((diff % 86400000) / 3600000), Math.floor((diff % 3600000) / 60000), Math.floor((diff % 60000) / 1000)];
    const items = bar.querySelectorAll('.countdown__item span');
    values.forEach((value, i) => { if (items[i]) items[i].textContent = String(value).padStart(2, '0'); });
    return true;
  }
  function unload(event) { if (event.target === sectionRoot) cleanup(); }
  function cleanup() {
    disposed = true;
    clearInterval(countdownInterval);
    stopVideo();
    if (observer) observer.disconnect();
    if (primaryImage) {
      primaryImage.removeEventListener('load', primaryMediaSettled);
      primaryImage.removeEventListener('error', primaryMediaSettled);
    }
    if (mediaQuery.removeEventListener) mediaQuery.removeEventListener('change', configureMedia);
    else mediaQuery.removeListener(configureMedia);
    hero.removeEventListener('click', click);
    hero.removeEventListener('keydown', keydown);
    hero.removeEventListener('pointerdown', pointerDown);
    hero.removeEventListener('pointerup', pointerUp);
    hero.removeEventListener('pointercancel', pointerCancel);
    document.removeEventListener('visibilitychange', visibilityChanged);
    document.removeEventListener('shopify:section:unload', unload);
    delete sectionRoot.peteliaHeroCleanup;
  }
  sectionRoot.peteliaHeroCleanup = cleanup;
  if (mediaQuery.addEventListener) mediaQuery.addEventListener('change', configureMedia);
  else mediaQuery.addListener(configureMedia);
  hero.addEventListener('click', click);
  hero.addEventListener('keydown', keydown);
  hero.addEventListener('pointerdown', pointerDown, { passive: true });
  hero.addEventListener('pointerup', pointerUp, { passive: true });
  hero.addEventListener('pointercancel', pointerCancel, { passive: true });
  document.addEventListener('visibilitychange', visibilityChanged);
  document.addEventListener('shopify:section:unload', unload);
  if (!primarySettled) {
    primaryImage.addEventListener('load', primaryMediaSettled, { once: true });
    primaryImage.addEventListener('error', primaryMediaSettled, { once: true });
  }
  if ('IntersectionObserver' in window) {
    observer = new IntersectionObserver(entries => {
      inView = entries[0].isIntersecting;
      if (inView) playVideo(); else pauseVideo();
    });
    observer.observe(hero);
  }
  configureMedia();
  if (updateCountdown()) countdownInterval = setInterval(updateCountdown, 1000);
})();
