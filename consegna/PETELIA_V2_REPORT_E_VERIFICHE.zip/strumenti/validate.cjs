const fs=require('node:fs');
const path=require('node:path');
const crypto=require('node:crypto');
const assert=require('node:assert/strict');
const cp=require('node:child_process');
const vm=require('node:vm');
const {toLiquidHtmlAST}=require('/workspace/petelia/tools/node_modules/@shopify/liquid-html-parser');
const root='/workspace/petelia/v2';
const hash=b=>crypto.createHash('sha256').update(b).digest('hex');
function files(dir){return fs.readdirSync(dir,{withFileTypes:true}).flatMap(e=>e.isDirectory()?files(path.join(dir,e.name)):[path.join(dir,e.name)]);}
const beforeFiles=files(root+'/base').map(f=>path.relative(root+'/base',f)).sort();
const afterFiles=files(root+'/theme').map(f=>path.relative(root+'/theme',f)).sort();
assert.deepEqual(beforeFiles,afterFiles);assert.equal(afterFiles.length,347);
const changed=afterFiles.filter(f=>!fs.readFileSync(root+'/base/'+f).equals(fs.readFileSync(root+'/theme/'+f)));
assert.deepEqual(changed,['assets/petelia-cart-guard.js','sections/countdown-timer.liquid','templates/index.json']);
const before=JSON.parse(fs.readFileSync(root+'/base/templates/index.json'));
const after=JSON.parse(fs.readFileSync(root+'/theme/templates/index.json'));
assert.equal(after.sections['countdown-timer'].settings.banner_video,'shopify://files/videos/VID-20261010_151241.mp4');
const newMarkup=after.sections.custom_liquid_mUBFxE.settings.custom_liquid;
assert(newMarkup.includes('viewBox="0 0 448 512"'));assert(!newMarkup.includes('font-awesome/'));
after.sections.custom_liquid_mUBFxE.settings.custom_liquid=before.sections.custom_liquid_mUBFxE.settings.custom_liquid;
assert.deepEqual(after,before);
assert(fs.readFileSync(root+'/theme/sections/petelia-automatico-strip.liquid','utf8').includes('assign banner_link = "https://peteliashop.com"'));
const oldGuard=fs.readFileSync(root+'/base/assets/petelia-cart-guard.js','utf8');
const guard=fs.readFileSync(root+'/theme/assets/petelia-cart-guard.js','utf8');
assert.equal(guard.slice(guard.indexOf('  let mutationQueue')),oldGuard.slice(oldGuard.indexOf('  let mutationQueue')));
assert.equal(guard.slice(0,guard.indexOf('  const getSectionInnerHTML')),oldGuard.slice(0,oldGuard.indexOf('  const getSectionInnerHTML')));
const hero=fs.readFileSync(root+'/theme/sections/countdown-timer.liquid','utf8');
toLiquidHtmlAST(hero,{mode:'strict'});
const scripts=[...hero.matchAll(/<script>([\s\S]*?)<\/script>/g)];
assert.equal(scripts.length,1);new vm.Script(scripts[0][1]);
const js=afterFiles.filter(f=>f.startsWith('assets/')&&f.endsWith('.js'));
for(const f of js){const result=cp.spawnSync('node',['--check',root+'/theme/'+f],{encoding:'utf8'});assert.equal(result.status,0,result.stderr);}
const json=afterFiles.filter(f=>f.endsWith('.json'));
for(const f of json)JSON.parse(fs.readFileSync(root+'/theme/'+f,'utf8'));
let schemas=0;
for(const f of afterFiles.filter(f=>f.endsWith('.liquid'))){
  for(const m of fs.readFileSync(root+'/theme/'+f,'utf8').matchAll(/{%-?\s*schema\s*-?%}([\s\S]*?){%-?\s*endschema\s*-?%}/g)){JSON.parse(m[1]);schemas++;}
}
const oldDiagnostics=JSON.parse(fs.readFileSync(root+'/reports/theme-check-base.json'));
const newDiagnostics=JSON.parse(fs.readFileSync(root+'/reports/theme-check-v2.json'));
const key=o=>JSON.stringify([o.uri.replace('/base/','/theme/'),o.check,o.message,o.severity]);
const oldSet=new Set(oldDiagnostics.map(key));
const newErrors=newDiagnostics.filter(o=>o.severity===0&&!oldSet.has(key(o)));
assert.equal(newErrors.length,0,JSON.stringify(newErrors));
const report={files:afterFiles.length,changed_files:changed,javascript_syntax_passed:js.length,json_parsed:json.length,embedded_schema_json_parsed:schemas,
  liquid_parser:'strict passed',inline_hero_javascript:'passed',updated_video_preserved:true,user_invektor_link_preserved:true,
  all_other_homepage_settings_preserved:true,commercial_mutation_checkout_logic_byte_identical:true,
  unchanged_configs_layout_and_other_files:afterFiles.length-changed.length,theme_check:{before:oldDiagnostics.length,after:newDiagnostics.length,new_errors:newErrors},
  file_manifest:Object.fromEntries(afterFiles.map(f=>[f,{base_sha256:hash(fs.readFileSync(root+'/base/'+f)),v2_sha256:hash(fs.readFileSync(root+'/theme/'+f))}]))};
fs.writeFileSync(root+'/reports/validation.json',JSON.stringify(report,null,2));
console.log(JSON.stringify({...report,file_manifest:undefined},null,2));
