from pathlib import Path

p=Path('/workspace/petelia/v2/theme/assets/petelia-cart-guard.js')
s=p.read_text()
needle='  const renderSections = (parsedState) => {'
helper='''  // Accept a Shopify section wrapper or its validated mini-cart fragment.
  // Never replace the drawer with an error page or an empty/null section.
  const miniCartContents = (html) => {
    if (typeof html !== 'string' || /<!doctype|<html[\\s>]|<body[\\s>]/i.test(html)) return null;
    const parsedDocument = new DOMParser().parseFromString(html, 'text/html');
    const form = parsedDocument.querySelector('form.mini-cart');
    if (!form) return null;
    const wrapper = form.closest('.shopify-section');
    return wrapper ? wrapper.innerHTML : html;
  };

  const ensureMiniCartSection = async (sections) => {
    const miniCart = document.getElementById('mini-cart');
    if (!miniCart || miniCartContents(sections?.['mini-cart']) != null) return sections;
    // The individual section endpoint is already declared by the theme's drawer.
    const url = new URL(miniCart.dataset.url || cartUrl(), window.location.href);
    if (url.origin !== window.location.origin) throw new Error('Destinazione mini-cart non valida.');
    url.searchParams.set('section_id', 'mini-cart');
    url.searchParams.delete('sections');
    url.searchParams.set('_petelia', Date.now());
    const response = await fetch(window.PeteliaThemeContext?.url(url.pathname + url.search) || url.pathname + url.search, {
      credentials: 'same-origin', cache: 'no-store', headers: { Accept: 'text/html' },
    });
    if (!response.ok) throw new Error('Fallback mini-cart non disponibile.');
    const html = await response.text();
    if (miniCartContents(html) == null) throw new Error('Markup del carrello non disponibile.');
    return { ...sections, 'mini-cart': html };
  };

'''
assert s.count(needle)==1
s=s.replace(needle,helper+needle,1)
old="      const replacement = typeof html === 'string' ? getSectionInnerHTML(html, '.shopify-section') : null;"
assert s.count(old)==1
s=s.replace(old,'      const replacement = miniCartContents(html);',1)
old='''      .then(([cart, sections]) => {
        renderSections({ ...cart, sections });
        return cart;
      })'''
new='''      .then(async ([cart, sections]) => {
        const completeSections = await ensureMiniCartSection(sections);
        renderSections({ ...cart, sections: completeSections });
        return cart;
      })'''
assert s.count(old)==1
s=s.replace(old,new,1)
p.write_text(s)
print('Added validated read-only mini-cart section fallback; mutation and checkout logic unchanged.')
