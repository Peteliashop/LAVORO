const fs = require('node:fs');
const {check} = require('@shopify/theme-check-node');
const root = process.argv[2];
const output = process.argv[3];
(async () => {
  const offenses = await check(root);
  fs.writeFileSync(output, JSON.stringify(offenses, null, 2));
  const counts = {};
  for (const o of offenses) counts[o.check] = (counts[o.check] || 0) + 1;
  console.log(JSON.stringify({root, total: offenses.length, counts}, null, 2));
})().catch(e => {console.error(e); process.exit(1);});
