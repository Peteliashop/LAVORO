// Offline component checks using actual theme markup/JS and synthetic Shopify data.
// These are not a Shopify preview, Lighthouse, a Meta WebView or a checkout test.
const fs = require('node:fs');
const path = require('node:path');
const http = require('node:http');
const assert = require('node:assert/strict');
const {Liquid} = require('/workspace/petelia/tools/node_modules/liquidjs');
const {chromium} = require('/workspace/petelia/tools/node_modules/playwright-core');
const base = '/workspace/petelia/v2';
const results = [];
const records = new Map();
const esc = s => String(s ?? '').replaceAll('&', '&amp;').replaceAll('"','&quot;');
function clean(s) {
  return s.replace(/{%-?\s*schema\s*-?%}[\s\S]*?{%-?\s*endschema\s*-?%}/g,'')
    .replace(/{%-?\s*style\s*-?%}/g,'<style>').replace(/{%-?\s*endstyle\s*-?%}/g,'</style>');
}
function hash(args) {return Object.fromEntries(args.filter(a => Array.isArray(a)));}
function engine(version) {
  const e = new Liquid({root:path.join(base,version,'snippets'),extname:'.liquid',strictFilters:false});
  e.registerFilter('image_url', (image, ...args) => {
    const h = hash(args); return `/image/${image?.id || 'mock'}.svg?width=${h.width || image?.width || 900}`;
  });
  e.registerFilter('image_tag', (url,...args) => {
    const h=hash(args); const width=Number(new URL(url,'http://local').searchParams.get('width')) || 900;
    const attrs={src:url,width,height:width,...h}; delete attrs.widths;
    if(h.widths) attrs.srcset=h.widths.split(',').map(w=>`${url.replace(/width=\d+/,`width=${w.trim()}`)} ${w.trim()}w`).join(', ');
    return '<img '+Object.entries(attrs).filter(([,v])=>v!==undefined).map(([k,v])=>`${k}="${esc(v)}"`).join(' ')+'>';
  });
  e.registerFilter('video_tag',(video,...args)=>{
    const h=hash(args);
    const attrs={src:'/media/video.mp4',poster:'/image/poster.svg',playsinline:true,...h};
    delete attrs.image_size;
    return '<video '+Object.entries(attrs).filter(([,v])=>v!==false&&v!==null).map(([k,v])=>v===true?k:`${k}="${esc(v)}"`).join(' ')+'></video>';
  });
  e.registerFilter('asset_url',x=>`/asset/${version}/${x}`);
  e.registerFilter('stylesheet_tag',url=>`<link rel="stylesheet" href="${url}">`);
  e.registerFilter('t',x=>x);
  e.registerFilter('money',x=>`€${Number(x||0)/100}`);
  e.registerFilter('money_with_currency',x=>`€${Number(x||0)/100} EUR`);
  return e;
}
const img = id => ({id,alt:id,width:900,height:900,aspect_ratio:1,src:`/image/${id}.svg`});
const media = id => ({...img(id),media_type:'image',preview_image:img(id),position:Number(id.replace(/\D/g,''))||1});
function sectionSettings(version,file, overrides={}) {
  const source=fs.readFileSync(`${base}/${version}/sections/${file}.liquid`,'utf8');
  const schema=JSON.parse(source.match(/{%\s*schema\s*%}([\s\S]*?){%\s*endschema\s*%}/)[1]);
  return Object.assign(Object.fromEntries(schema.settings.filter(x=>x.id&&x.default!==undefined).map(x=>[x.id,x.default])), overrides);
}
const cssColor={red:0,green:0,blue:0};
async function fixture(version, type, params) {
  const e=engine(version);
  const source=file=>clean(fs.readFileSync(`${base}/${version}/${file}`,'utf8'));
  let body, global=false;
  if (type==='hero') {
    const settings=sectionSettings(version,'countdown-timer',{
      banner_image:img('hero'),banner_image_desktop:img('desktop'),banner_video:params.has('noVideo') ? null : {id:'video',sources:[{format:'mp4',width:1920,height:1080,url:'/media/desktop.mp4'},{format:'mp4',width:1280,height:720,url:'/media/mobile.mp4'},{format:'mp4',width:854,height:480,url:'/media/small.mp4'}]},
      video_display:params.get('mode')||'mobile',countdown_expiry:'2030-10-10T23:59:59',
      banner_image_2:params.has('secondary')?img('secondary'):null
    });
    settings.desktop_second_image=params.has('desktopSecond');
    body=await e.parseAndRender(source('sections/countdown-timer.liquid'),{section:{id:'fixture',settings}})+'<div style="height:5000px"></div>';
  } else if (type==='lower') {
    global=true;
    const settings=sectionSettings(version,'video-hero',{
      video:{aspect_ratio:1,id:'video'},video_url:'',image_ratio:'400px',mobile_image_ratio:'400px',
      colors_overlay:cssColor,colors_text:cssColor,colors_button_background:cssColor,colors_button_label:cssColor
    });
    body='<div style="height:5000px"></div>'+await e.parseAndRender(source('sections/video-hero.liquid'),{section:{id:'fixture',settings,blocks:[]}});
  } else if(type==='gallery') {
    const main=fs.readFileSync(`${base}/${version}/sections/main-product.liquid`,'utf8');
    const assign=main.match(/{%- liquid\s+assign first_image = product.media.first[\s\S]*?-%}/)[0];
    const ul=main.slice(main.indexOf('<ul id="Slider-Gallery-'),main.indexOf('</ul>')+5);
    const product={id:1,title:'Synthetic product',media:[media('p1'),media('p2'),media('p3')],images:[],options_with_values:[],selected_or_first_available_variant:{}};
    if(params.has('variant')) product.selected_or_first_available_variant.featured_media=product.media[1];
    const settings=sectionSettings(version,'main-product',{
      show_featured_media:params.has('showFeatured'),enable_image_zoom:false,
      hide_variants:true,media_size:'medium',gallery_layout:'thumbnail_slider',image_ratio:'adapt',mobile_image_ratio:'square'
    });
    body=await e.parseAndRender(assign+ul,{product,section:{id:'fixture',settings},settings:{page_width:1000}});
  } else if(type==='collection') {
    const products=Array.from({length:10},(_,i)=>({id:i+1,title:`Product ${i+1}`,url:`/products/p${i+1}`,available:true,
      featured_media:media('c'+(i+1)),media:[media('c'+(i+1)),media('second'+(i+1))],images:[],options:[],options_with_values:[],metafields:{},price:10000,has_only_default_variant:true}));
    const settings=sectionSettings(version,'featured-collection',{
      collection:{products,all_products_count:10},heading_tag:'h2',enable_double_row:true,
      show_quick_buy:false,enable_quick_view:false,enable_color_swatches:false,enable_countdown:false,
      show_secondary_image:true,show_rating:false,image_ratio:'square'
    });
    body=await e.parseAndRender(source('sections/featured-collection.liquid'),{
      section:{id:'fixture',index:Number(params.get('index')||4),settings},settings:{page_width:1000,color_swatches_enabled:false}
    });
  } else if(type==='icons') {
    body=await e.parseAndRender(source('sections/rich-text.liquid'),{section:{id:'fixture',settings:{full_width:true}}});
    body=body.replaceAll('https://cdn.shopify.com/s/files/1/0818/9847/1758/files/','/image/');
  }
  const setup=`<script>window.theme={settings:{themeName:'Be Yours',themeVersion:'fixture'},shopSettings:{moneyFormat:'{{amount}}',isoCode:'EUR'},routes:{}};</script>`;
  const script=global?setup+`<script src="/asset/${version}/global.js" defer></script>`:'';
  return '<!doctype html><html><head><meta name="viewport" content="width=device-width,initial-scale=1"><style>body{margin:0} video-section{display:block;height:400px} video{width:100%;height:400px} .media{position:relative} .no-js-hidden{display:block}.visually-hidden{position:absolute!important;overflow:hidden;width:1px;height:1px;margin:-1px;padding:0;border:0;clip:rect(0,0,0,0);white-space:nowrap}</style>'+script+'</head><body><div id="shopify-section-fixture">'+body+'</div></body></html>';
}

module.exports={fixture,engine,clean};
